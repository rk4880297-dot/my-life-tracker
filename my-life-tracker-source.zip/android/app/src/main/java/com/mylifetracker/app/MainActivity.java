package com.mylifetracker.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
