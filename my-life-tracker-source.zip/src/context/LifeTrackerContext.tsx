import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useMemo,
  useCallback,
  useRef,
} from 'react';
import confetti from 'canvas-confetti';
import {
  Activity,
  Habit,
  HabitLog,
  Task,
  Goal,
  WaterLog,
  WorkoutLog,
  SleepLog,
  WeightLog,
  FinanceTransaction,
  JournalEntry,
  UserProfile,
  OverdueTaskInfo,
  TaskNotificationSettings,
} from '../types';
import {
  storage,
  AppStateData,
  getTodayDateString,
  exportDataAsJSON,
  exportActivitiesCSV,
  exportTasksCSV,
  exportFinancesCSV,
  DEFAULT_TASK_NOTIFICATIONS,
} from '../services/storage';
import {
  calculateDayProductivity,
  calculateStreaks,
  generateSmartSuggestions,
  getDailyQuote,
  ProductivityBreakdown,
} from '../services/analytics';
import {
  NotificationService,
  getTaskDueDateTime,
  isTaskOverdue,
  getOverdueDurationText,
} from '../services/notifications';

interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'error';
  text: string;
}

interface LifeTrackerContextType {
  data: AppStateData;
  isLoading: boolean;
  selectedDate: string;
  setSelectedDate: (date: string) => void;
  currentTime: Date;
  activeNavTab: string;
  setActiveNavTab: (tab: string) => void;
  // Computed for selected date
  breakdown: ProductivityBreakdown;
  streaks: { currentStreak: number; longestStreak: number };
  quote: { text: string; author: string };
  suggestions: string[];
  // Smart Task Alerts
  overdueTasks: OverdueTaskInfo[];
  pendingTasksCount: number;
  todayIncompleteTasks: Task[];
  // Toast notifications
  toasts: ToastMessage[];
  addToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  removeToast: (id: string) => void;
  // Actions
  addActivity: (act: Omit<Activity, 'id' | 'createdAt'>) => void;
  updateActivity: (act: Activity) => void;
  deleteActivity: (id: string) => void;

  addHabit: (habit: Omit<Habit, 'id' | 'createdAt'>) => void;
  updateHabit: (habit: Habit) => void;
  deleteHabit: (id: string) => void;
  toggleHabit: (habitId: string, date?: string) => void;

  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  toggleTask: (taskId: string) => void;
  rescheduleTask: (taskId: string, newDueDate: string, newDueTime?: string) => void;
  snoozeTask: (taskId: string, minutes: number) => void;
  sendTestNotification: () => Promise<void>;
  updateTaskNotificationSettings: (settings: Partial<TaskNotificationSettings>) => void;

  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  updateGoal: (goal: Goal) => void;
  deleteGoal: (id: string) => void;
  updateGoalProgress: (goalId: string, newProgress: number) => void;

  addWaterLog: (amountMl: number, date?: string) => void;
  addWorkoutLog: (workout: Omit<WorkoutLog, 'id'>) => void;
  deleteWorkoutLog: (id: string) => void;
  saveSleepLog: (sleep: Omit<SleepLog, 'id'>) => void;
  addWeightLog: (weight: Omit<WeightLog, 'id'>) => void;
  deleteWeightLog: (id: string) => void;

  addTransaction: (tx: Omit<FinanceTransaction, 'id' | 'createdAt'>) => void;
  deleteTransaction: (id: string) => void;

  saveJournalEntry: (entry: Omit<JournalEntry, 'id' | 'updatedAt'>) => void;

  updateProfile: (profile: Partial<UserProfile>) => void;
  resetAllData: () => Promise<void>;
  importDataFromJSON: (jsonData: AppStateData) => Promise<boolean>;
  exportDataJSON: () => void;
  exportCSVReport: (type: 'activities' | 'tasks' | 'finances') => void;
  triggerCelebration: () => void;
}

const LifeTrackerContext = createContext<LifeTrackerContextType | null>(null);

export const LifeTrackerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<AppStateData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [activeNavTab, setActiveNavTab] = useState<string>('home');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Track notified task milestones to prevent duplicate web notifications
  const firedNotificationsRef = useRef<Set<string>>(new Set());
  const dailySummaryFiredDateRef = useRef<string>('');

  // Clock tick every second
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Initial load from IndexedDB
  useEffect(() => {
    storage.loadAllData().then(async (loaded) => {
      setData(loaded);
      setIsLoading(false);

      // Sync theme on load
      if (loaded.profile.theme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        document.documentElement.classList.add('dark');
      }

      // Initialize Android Notification Channels & schedule background reminders
      await NotificationService.initializeChannels();
      const settings = loaded.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      if (settings.enabled) {
        for (const t of loaded.tasks) {
          if (!t.completed) {
            await NotificationService.scheduleTaskReminders(t, settings);
          }
        }
        await NotificationService.scheduleDailySummary(loaded.tasks, settings);
      }
    });
  }, []);

  // Web in-app & browser notification monitor (runs every 15 seconds)
  useEffect(() => {
    if (!data) return;
    const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
    if (!settings.enabled) return;

    const interval = setInterval(() => {
      const now = new Date();
      const nowMs = now.getTime();
      const todayStr = getTodayDateString();

      // 1. Task Reminders check
      data.tasks.forEach((task) => {
        if (task.completed) return;
        if (task.snoozedUntil && new Date(task.snoozedUntil) > now) return;

        const dueDateTime = getTaskDueDateTime(task);
        const dueMs = dueDateTime.getTime();
        const diffMs = dueMs - nowMs;

        // 15-minute reminder (between 14 and 16 minutes before deadline)
        if (settings.reminder15Min) {
          const key15 = `${task.id}_15min`;
          if (diffMs > 0 && diffMs <= 15 * 60 * 1000 && !firedNotificationsRef.current.has(key15)) {
            firedNotificationsRef.current.add(key15);
            NotificationService.sendImmediate(
              `⏰ 15-Min Reminder: "${task.title}"`,
              `Due in 15 minutes at ${task.dueTime || 'today'}. Priority: ${task.priority.toUpperCase()}`,
              'task-reminders'
            );
            addToast(`⏰ Reminder: "${task.title}" is due in 15 minutes!`, 'info');
          }
        }

        // Deadline reminder (reached within last 60 seconds)
        if (settings.deadlineReminder) {
          const keyDead = `${task.id}_deadline`;
          if (nowMs >= dueMs && nowMs - dueMs < 60 * 1000 && !firedNotificationsRef.current.has(keyDead)) {
            firedNotificationsRef.current.add(keyDead);
            NotificationService.sendImmediate(
              `🎯 Deadline Reached: "${task.title}"`,
              `This task is due right now. Mark as complete or reschedule!`,
              'task-reminders'
            );
            addToast(`🎯 Task Due Now: "${task.title}"`, 'info');
          }
        }

        // Overdue reminder (15 minutes after deadline)
        if (settings.overdueReminder) {
          const keyOver = `${task.id}_overdue`;
          if (nowMs >= dueMs + 15 * 60 * 1000 && !firedNotificationsRef.current.has(keyOver)) {
            firedNotificationsRef.current.add(keyOver);
            const durationText = getOverdueDurationText(dueDateTime, now);
            NotificationService.sendImmediate(
              `⚠️ Overdue Task Alert: "${task.title}"`,
              `Task is now ${durationText}. Please review and update immediately.`,
              'overdue-alerts'
            );
            addToast(`⚠️ Overdue Task: "${task.title}" (${durationText})`, 'error');
          }
        }
      });

      // 2. Daily Summary check at configured time (default 21:00)
      if (settings.dailySummary && dailySummaryFiredDateRef.current !== todayStr) {
        const [targetH, targetM] = (settings.dailySummaryTime || '21:00').split(':').map(Number);
        if (now.getHours() === targetH && now.getMinutes() >= targetM) {
          dailySummaryFiredDateRef.current = todayStr;
          const todayTasks = data.tasks.filter((t) => t.dueDate === todayStr);
          const comp = todayTasks.filter((t) => t.completed).length;
          const pend = todayTasks.filter((t) => !t.completed).length;
          const over = data.tasks.filter((t) => isTaskOverdue(t, now)).length;

          const msg = `Completed: ${comp} Tasks | Pending: ${pend} Tasks | Overdue: ${over} Task${
            over !== 1 ? 's' : ''
          }\nDon't forget to complete your remaining tasks!`;

          NotificationService.sendImmediate('📊 Your Daily Progress Report', msg, 'daily-summary');
          addToast('📊 Daily Progress Report: Review your remaining tasks for today!', 'info');
        }
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [data]);

  // Save changes to storage whenever data changes
  const persist = useCallback((newData: AppStateData) => {
    setData(newData);
    storage.saveAllData(newData);
  }, []);

  const addToast = useCallback((text: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const triggerCelebration = useCallback(() => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#10b981', '#38bdf8', '#f59e0b', '#ec4899'],
      });
    } catch {
      // ignore
    }
  }, []);

  // Computed properties
  const breakdown = useMemo(() => {
    if (!data) {
      return {
        score: 0,
        taskScore: 0,
        habitScore: 0,
        timeScore: 0,
        healthScore: 0,
        tasksCompleted: 0,
        tasksTotal: 0,
        habitsCompleted: 0,
        habitsTotal: 0,
        productiveMinutes: 0,
        unproductiveMinutes: 0,
        neutralMinutes: 0,
        totalTrackedMinutes: 0,
        waterIntakeMl: 0,
        exerciseMinutes: 0,
        studyMinutes: 0,
        sleepHours: 0,
      };
    }
    return calculateDayProductivity(selectedDate, data);
  }, [data, selectedDate]);

  const streaks = useMemo(() => {
    if (!data) return { currentStreak: 0, longestStreak: 0 };
    return calculateStreaks(data);
  }, [data]);

  const quote = useMemo(() => getDailyQuote(), []);

  const suggestions = useMemo(() => {
    if (!data) return [];
    return generateSmartSuggestions(data, selectedDate);
  }, [data, selectedDate]);

  // SMART TASK ALERTS COMPUTED
  const overdueTasks = useMemo<OverdueTaskInfo[]>(() => {
    if (!data) return [];
    const list: OverdueTaskInfo[] = [];
    data.tasks.forEach((t) => {
      if (!t.completed && isTaskOverdue(t, currentTime)) {
        const dueDateTime = getTaskDueDateTime(t);
        list.push({
          task: t,
          dueDateTime,
          overdueDurationText: getOverdueDurationText(dueDateTime, currentTime),
          isOverdue: true,
          isPending: true,
        });
      }
    });
    // Sort oldest due date first (most overdue on top)
    return list.sort((a, b) => a.dueDateTime.getTime() - b.dueDateTime.getTime());
  }, [data, currentTime]);

  const pendingTasksCount = useMemo(() => {
    if (!data) return 0;
    return data.tasks.filter((t) => !t.completed).length;
  }, [data]);

  const todayIncompleteTasks = useMemo(() => {
    if (!data) return [];
    const todayStr = getTodayDateString();
    return data.tasks.filter((t) => !t.completed && t.dueDate === todayStr);
  }, [data]);

  // Activity handlers
  const addActivity = useCallback(
    (act: Omit<Activity, 'id' | 'createdAt'>) => {
      if (!data) return;
      const newAct: Activity = {
        ...act,
        id: `act-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      persist({ ...data, activities: [newAct, ...data.activities] });
      addToast(`Activity "${act.name}" recorded!`, 'success');
    },
    [data, persist, addToast]
  );

  const updateActivity = useCallback(
    (act: Activity) => {
      if (!data) return;
      persist({
        ...data,
        activities: data.activities.map((a) => (a.id === act.id ? act : a)),
      });
      addToast('Activity updated successfully', 'success');
    },
    [data, persist, addToast]
  );

  const deleteActivity = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        activities: data.activities.filter((a) => a.id !== id),
      });
      addToast('Activity deleted', 'info');
    },
    [data, persist, addToast]
  );

  // Habit handlers
  const addHabit = useCallback(
    (habit: Omit<Habit, 'id' | 'createdAt'>) => {
      if (!data) return;
      const newHabit: Habit = {
        ...habit,
        id: `habit-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      persist({ ...data, habits: [...data.habits, newHabit] });
      addToast(`Habit "${habit.name}" created!`, 'success');
    },
    [data, persist, addToast]
  );

  const updateHabit = useCallback(
    (habit: Habit) => {
      if (!data) return;
      persist({
        ...data,
        habits: data.habits.map((h) => (h.id === habit.id ? habit : h)),
      });
      addToast('Habit updated', 'success');
    },
    [data, persist, addToast]
  );

  const deleteHabit = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        habits: data.habits.filter((h) => h.id !== id),
        habitLogs: data.habitLogs.filter((l) => l.habitId !== id),
      });
      addToast('Habit deleted', 'info');
    },
    [data, persist, addToast]
  );

  const toggleHabit = useCallback(
    (habitId: string, date: string = selectedDate) => {
      if (!data) return;
      const existing = data.habitLogs.find((l) => l.habitId === habitId && l.date === date);
      let updatedLogs: HabitLog[];
      let isNowCompleted = true;

      if (existing) {
        isNowCompleted = !existing.completed;
        updatedLogs = data.habitLogs.map((l) =>
          l.habitId === habitId && l.date === date
            ? { ...l, completed: isNowCompleted, completedAt: isNowCompleted ? new Date().toISOString() : undefined }
            : l
        );
      } else {
        updatedLogs = [
          ...data.habitLogs,
          {
            id: `hlog-${habitId}-${date}`,
            habitId,
            date,
            completed: true,
            completedAt: new Date().toISOString(),
          },
        ];
      }

      persist({ ...data, habitLogs: updatedLogs });

      if (isNowCompleted) {
        addToast('Habit completed! Keep up the momentum 🔥', 'success');
        triggerCelebration();
      } else {
        addToast('Habit marked as incomplete', 'info');
      }
    },
    [data, selectedDate, persist, addToast, triggerCelebration]
  );

  // TASK OPERATIONS WITH SMART NOTIFICATION SCHEDULING
  const addTask = useCallback(
    async (task: Omit<Task, 'id' | 'createdAt'>) => {
      if (!data) return;
      const newTask: Task = {
        ...task,
        id: `task-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      const updatedTasks = [newTask, ...data.tasks];
      persist({ ...data, tasks: updatedTasks });
      addToast(`Task "${task.title}" created with smart reminders!`, 'success');

      // Schedule Android Capacitor Local Notifications & update Daily Summary
      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      await NotificationService.scheduleTaskReminders(newTask, settings);
      await NotificationService.scheduleDailySummary(updatedTasks, settings);
    },
    [data, persist, addToast]
  );

  const updateTask = useCallback(
    async (task: Task) => {
      if (!data) return;
      const updatedTasks = data.tasks.map((t) => (t.id === task.id ? task : t));
      persist({ ...data, tasks: updatedTasks });
      addToast('Task updated and reminders rescheduled', 'success');

      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      await NotificationService.scheduleTaskReminders(task, settings);
      await NotificationService.scheduleDailySummary(updatedTasks, settings);
    },
    [data, persist, addToast]
  );

  const deleteTask = useCallback(
    async (id: string) => {
      if (!data) return;
      const updatedTasks = data.tasks.filter((t) => t.id !== id);
      persist({ ...data, tasks: updatedTasks });
      addToast('Task removed', 'info');

      // Cancel scheduled notifications for this deleted task
      await NotificationService.cancelTaskReminders(id);
      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      await NotificationService.scheduleDailySummary(updatedTasks, settings);
    },
    [data, persist, addToast]
  );

  const toggleTask = useCallback(
    async (taskId: string) => {
      if (!data) return;
      const target = data.tasks.find((t) => t.id === taskId);
      if (!target) return;
      const willBeCompleted = !target.completed;

      const updatedTasks = data.tasks.map((t) =>
        t.id === taskId
          ? {
              ...t,
              completed: willBeCompleted,
              completedAt: willBeCompleted ? new Date().toISOString() : undefined,
              snoozedUntil: undefined,
            }
          : t
      );

      persist({ ...data, tasks: updatedTasks });

      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;

      if (willBeCompleted) {
        addToast(`Task completed: "${target.title}" ✅`, 'success');
        triggerCelebration();
        // Cancel any pending alerts for this completed task
        await NotificationService.cancelTaskReminders(taskId);
      } else {
        addToast('Task marked incomplete — reminders restored', 'info');
        const restoredTask = updatedTasks.find((t) => t.id === taskId);
        if (restoredTask) {
          await NotificationService.scheduleTaskReminders(restoredTask, settings);
        }
      }

      await NotificationService.scheduleDailySummary(updatedTasks, settings);
    },
    [data, persist, addToast, triggerCelebration]
  );

  const rescheduleTask = useCallback(
    async (taskId: string, newDueDate: string, newDueTime?: string) => {
      if (!data) return;
      const target = data.tasks.find((t) => t.id === taskId);
      if (!target) return;

      const updatedTask: Task = {
        ...target,
        dueDate: newDueDate,
        dueTime: newDueTime || target.dueTime || '18:00',
        snoozedUntil: undefined,
      };

      const updatedTasks = data.tasks.map((t) => (t.id === taskId ? updatedTask : t));
      persist({ ...data, tasks: updatedTasks });
      addToast(`Task rescheduled to ${newDueDate} ${newDueTime || ''}`, 'success');

      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      await NotificationService.scheduleTaskReminders(updatedTask, settings);
      await NotificationService.scheduleDailySummary(updatedTasks, settings);
    },
    [data, persist, addToast]
  );

  const snoozeTask = useCallback(
    async (taskId: string, minutes: number) => {
      if (!data) return;
      const target = data.tasks.find((t) => t.id === taskId);
      if (!target) return;

      const snoozeDate = new Date(Date.now() + minutes * 60 * 1000);
      const snoozeIso = snoozeDate.toISOString();

      const updatedTask: Task = {
        ...target,
        snoozedUntil: snoozeIso,
      };

      const updatedTasks = data.tasks.map((t) => (t.id === taskId ? updatedTask : t));
      persist({ ...data, tasks: updatedTasks });
      addToast(`Task snoozed for ${minutes} minutes. We will remind you at ${snoozeDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`, 'info');

      // Schedule instant snooze notification on Android
      const settings = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      await NotificationService.scheduleTaskReminders(updatedTask, settings);
    },
    [data, persist, addToast]
  );

  const sendTestNotification = useCallback(async () => {
    const success = await NotificationService.sendImmediate(
      '🔔 Test Reminder: My Life Tracker',
      'Smart Task Notifications and Reminders are working perfectly on this device!',
      'task-reminders'
    );
    if (success) {
      addToast('Test notification sent! Check your notification tray.', 'success');
    } else {
      addToast('Notification permission needed. Please tap "Enable Notifications" first.', 'info');
    }
  }, [addToast]);

  const updateTaskNotificationSettings = useCallback(
    async (settingsUpdate: Partial<TaskNotificationSettings>) => {
      if (!data) return;
      const current = data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS;
      const merged: TaskNotificationSettings = { ...current, ...settingsUpdate };

      const newProfile: UserProfile = {
        ...data.profile,
        taskNotifications: merged,
      };

      persist({ ...data, profile: newProfile });
      addToast('Notification settings updated', 'success');

      // Reschedule or cancel all tasks based on new settings
      if (merged.enabled) {
        for (const t of data.tasks) {
          if (!t.completed) {
            await NotificationService.scheduleTaskReminders(t, merged);
          }
        }
        await NotificationService.scheduleDailySummary(data.tasks, merged);
      } else {
        for (const t of data.tasks) {
          await NotificationService.cancelTaskReminders(t.id);
        }
      }
    },
    [data, persist, addToast]
  );

  // Goals
  const addGoal = useCallback(
    (goal: Omit<Goal, 'id' | 'createdAt'>) => {
      if (!data) return;
      const newGoal: Goal = {
        ...goal,
        id: `goal-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      persist({ ...data, goals: [...data.goals, newGoal] });
      addToast(`Goal "${goal.name}" created!`, 'success');
    },
    [data, persist, addToast]
  );

  const updateGoal = useCallback(
    (goal: Goal) => {
      if (!data) return;
      persist({
        ...data,
        goals: data.goals.map((g) => (g.id === goal.id ? goal : g)),
      });
      addToast('Goal updated', 'success');
    },
    [data, persist, addToast]
  );

  const deleteGoal = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        goals: data.goals.filter((g) => g.id !== id),
      });
      addToast('Goal deleted', 'info');
    },
    [data, persist, addToast]
  );

  const updateGoalProgress = useCallback(
    (goalId: string, newProgress: number) => {
      if (!data) return;
      const target = data.goals.find((g) => g.id === goalId);
      if (!target) return;
      const isCompleted = newProgress >= target.targetValue;
      persist({
        ...data,
        goals: data.goals.map((g) =>
          g.id === goalId
            ? {
                ...g,
                currentProgress: newProgress,
                status: isCompleted ? 'completed' : 'active',
              }
            : g
        ),
      });
      if (isCompleted && target.status !== 'completed') {
        addToast(`🎉 Milestone Reached: Goal "${target.name}" Accomplished!`, 'success');
        triggerCelebration();
      } else {
        addToast('Goal progress updated', 'success');
      }
    },
    [data, persist, addToast, triggerCelebration]
  );

  // Health
  const addWaterLog = useCallback(
    (amountMl: number, date: string = selectedDate) => {
      if (!data) return;
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const log: WaterLog = {
        id: `w-${Date.now()}`,
        date,
        amountMl,
        timestamp: timeStr,
      };
      persist({ ...data, waterLogs: [...data.waterLogs, log] });
      addToast(`+${amountMl} ml water logged 💧`, 'success');
    },
    [data, selectedDate, persist, addToast]
  );

  const addWorkoutLog = useCallback(
    (workout: Omit<WorkoutLog, 'id'>) => {
      if (!data) return;
      const newWorkout: WorkoutLog = {
        ...workout,
        id: `wo-${Date.now()}`,
      };
      persist({ ...data, workoutLogs: [newWorkout, ...data.workoutLogs] });
      addToast(`Workout "${workout.exerciseName}" logged! ⚡`, 'success');
      triggerCelebration();
    },
    [data, persist, addToast, triggerCelebration]
  );

  const deleteWorkoutLog = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        workoutLogs: data.workoutLogs.filter((w) => w.id !== id),
      });
      addToast('Workout entry removed', 'info');
    },
    [data, persist, addToast]
  );

  const saveSleepLog = useCallback(
    (sleep: Omit<SleepLog, 'id'>) => {
      if (!data) return;
      const filtered = data.sleepLogs.filter((s) => s.date !== sleep.date);
      const newSleep: SleepLog = {
        ...sleep,
        id: `sl-${Date.now()}`,
      };
      persist({ ...data, sleepLogs: [newSleep, ...filtered] });
      addToast('Sleep log saved 🌙', 'success');
    },
    [data, persist, addToast]
  );

  const addWeightLog = useCallback(
    (weight: Omit<WeightLog, 'id'>) => {
      if (!data) return;
      const filtered = data.weightLogs.filter((w) => w.date !== weight.date);
      const newWeight: WeightLog = {
        ...weight,
        id: `wt-${Date.now()}`,
      };
      persist({ ...data, weightLogs: [...filtered, newWeight] });
      addToast(`Weight logged: ${weight.weight} ${weight.unit}`, 'success');
    },
    [data, persist, addToast]
  );

  const deleteWeightLog = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        weightLogs: data.weightLogs.filter((w) => w.id !== id),
      });
      addToast('Weight entry removed', 'info');
    },
    [data, persist, addToast]
  );

  // Finance
  const addTransaction = useCallback(
    (tx: Omit<FinanceTransaction, 'id' | 'createdAt'>) => {
      if (!data) return;
      const newTx: FinanceTransaction = {
        ...tx,
        id: `tx-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      persist({ ...data, transactions: [newTx, ...data.transactions] });
      addToast(
        `${tx.type === 'income' ? 'Income' : 'Expense'} of $${tx.amount.toFixed(2)} recorded`,
        'success'
      );
    },
    [data, persist, addToast]
  );

  const deleteTransaction = useCallback(
    (id: string) => {
      if (!data) return;
      persist({
        ...data,
        transactions: data.transactions.filter((t) => t.id !== id),
      });
      addToast('Transaction removed', 'info');
    },
    [data, persist, addToast]
  );

  // Journal
  const saveJournalEntry = useCallback(
    (entry: Omit<JournalEntry, 'id' | 'updatedAt'>) => {
      if (!data) return;
      const filtered = data.journalEntries.filter((j) => j.date !== entry.date);
      const newEntry: JournalEntry = {
        ...entry,
        id: `jn-${Date.now()}`,
        updatedAt: new Date().toISOString(),
      };
      persist({ ...data, journalEntries: [newEntry, ...filtered] });
      addToast('Journal entry saved for ' + entry.date, 'success');
    },
    [data, persist, addToast]
  );

  // Profile & Settings
  const updateProfile = useCallback(
    (profileUpdate: Partial<UserProfile>) => {
      if (!data) return;
      const newProfile = { ...data.profile, ...profileUpdate };
      if (profileUpdate.theme) {
        if (profileUpdate.theme === 'light') {
          document.documentElement.classList.remove('dark');
        } else {
          document.documentElement.classList.add('dark');
        }
      }
      persist({ ...data, profile: newProfile });
      addToast('Profile and settings updated', 'success');
    },
    [data, persist, addToast]
  );

  // Reset and Backup
  const resetAllData = useCallback(async () => {
    const cleared = await storage.clearAllData();
    setData(cleared);
    setSelectedDate(getTodayDateString());
    addToast('All data has been reset to defaults', 'info');
  }, [addToast]);

  const importDataFromJSON = useCallback(
    async (imported: AppStateData): Promise<boolean> => {
      if (
        !imported ||
        !Array.isArray(imported.activities) ||
        !Array.isArray(imported.habits) ||
        !Array.isArray(imported.tasks)
      ) {
        addToast('Invalid backup file format', 'error');
        return false;
      }
      await storage.saveAllData(imported);
      setData(imported);
      addToast('Backup restored successfully!', 'success');
      return true;
    },
    [addToast]
  );

  const exportDataJSON = useCallback(() => {
    if (!data) return;
    exportDataAsJSON(data);
    addToast('Backup file downloaded', 'success');
  }, [data, addToast]);

  const exportCSVReport = useCallback(
    (type: 'activities' | 'tasks' | 'finances') => {
      if (!data) return;
      if (type === 'activities') exportActivitiesCSV(data.activities);
      if (type === 'tasks') exportTasksCSV(data.tasks);
      if (type === 'finances') exportFinancesCSV(data.transactions);
      addToast(`${type.toUpperCase()} CSV report generated`, 'success');
    },
    [data, addToast]
  );

  const contextValue = useMemo(
    () => ({
      data: data!,
      isLoading,
      selectedDate,
      setSelectedDate,
      currentTime,
      activeNavTab,
      setActiveNavTab,
      breakdown,
      streaks,
      quote,
      suggestions,
      overdueTasks,
      pendingTasksCount,
      todayIncompleteTasks,
      toasts,
      addToast,
      removeToast,
      addActivity,
      updateActivity,
      deleteActivity,
      addHabit,
      updateHabit,
      deleteHabit,
      toggleHabit,
      addTask,
      updateTask,
      deleteTask,
      toggleTask,
      rescheduleTask,
      snoozeTask,
      sendTestNotification,
      updateTaskNotificationSettings,
      addGoal,
      updateGoal,
      deleteGoal,
      updateGoalProgress,
      addWaterLog,
      addWorkoutLog,
      deleteWorkoutLog,
      saveSleepLog,
      addWeightLog,
      deleteWeightLog,
      addTransaction,
      deleteTransaction,
      saveJournalEntry,
      updateProfile,
      resetAllData,
      importDataFromJSON,
      exportDataJSON,
      exportCSVReport,
      triggerCelebration,
    }),
    [
      data,
      isLoading,
      selectedDate,
      currentTime,
      activeNavTab,
      breakdown,
      streaks,
      quote,
      suggestions,
      overdueTasks,
      pendingTasksCount,
      todayIncompleteTasks,
      toasts,
      addToast,
      removeToast,
      addActivity,
      updateActivity,
      deleteActivity,
      addHabit,
      updateHabit,
      deleteHabit,
      toggleHabit,
      addTask,
      updateTask,
      deleteTask,
      toggleTask,
      rescheduleTask,
      snoozeTask,
      sendTestNotification,
      updateTaskNotificationSettings,
      addGoal,
      updateGoal,
      deleteGoal,
      updateGoalProgress,
      addWaterLog,
      addWorkoutLog,
      deleteWorkoutLog,
      saveSleepLog,
      addWeightLog,
      deleteWeightLog,
      addTransaction,
      deleteTransaction,
      saveJournalEntry,
      updateProfile,
      resetAllData,
      importDataFromJSON,
      exportDataJSON,
      exportCSVReport,
      triggerCelebration,
    ]
  );

  return (
    <LifeTrackerContext.Provider value={contextValue}>
      {children}
    </LifeTrackerContext.Provider>
  );
};

export const useLifeTracker = () => {
  const context = useContext(LifeTrackerContext);
  if (!context) {
    throw new Error('useLifeTracker must be used within a LifeTrackerProvider');
  }
  return context;
};
