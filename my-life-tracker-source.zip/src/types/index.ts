export type ActivityCategory =
  | 'Personal Development'
  | 'Business'
  | 'Study'
  | 'Exercise'
  | 'Health'
  | 'Family'
  | 'Entertainment'
  | 'Social Media'
  | 'Sleep'
  | 'Other';

export type ProductivityRating = 'productive' | 'neutral' | 'unproductive';

export interface Activity {
  id: string;
  name: string;
  category: ActivityCategory;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  durationMinutes: number;
  date: string;      // YYYY-MM-DD
  description?: string;
  productivityRating: ProductivityRating;
  status: 'completed' | 'pending';
  createdAt: string;
}

export type HabitFrequency = 'daily' | 'weekdays' | 'weekends';

export interface Habit {
  id: string;
  name: string;
  icon: string;
  category: string;
  dailyTarget: string;
  reminderTime?: string;
  frequency: HabitFrequency;
  startDate: string;
  archived?: boolean;
  createdAt: string;
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
  completedAt?: string;
}

export type TaskPriority = 'high' | 'medium' | 'low';

export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: TaskPriority;
  category: string;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  snoozedUntil?: string; // ISO timestamp
}

export interface OverdueTaskInfo {
  task: Task;
  dueDateTime: Date;
  overdueDurationText: string;
  isOverdue: boolean;
  isPending: boolean;
}

export interface TaskNotificationSettings {
  enabled: boolean;
  reminder15Min: boolean;
  deadlineReminder: boolean;
  overdueReminder: boolean;
  dailySummary: boolean;
  dailySummaryTime: string; // "21:00"
}

export type GoalCategory =
  | 'Personal'
  | 'Financial'
  | 'Career'
  | 'Education'
  | 'Business'
  | 'Fitness'
  | 'Lifestyle';

export interface Goal {
  id: string;
  name: string;
  description: string;
  category: GoalCategory;
  targetDate: string;
  targetValue: number;
  currentProgress: number;
  unit: string;
  priority: 'high' | 'medium' | 'low';
  status: 'active' | 'completed' | 'overdue';
  createdAt: string;
}

export interface WaterLog {
  id: string;
  date: string; // YYYY-MM-DD
  amountMl: number;
  timestamp: string;
}

export interface WorkoutLog {
  id: string;
  exerciseName: string;
  category: string;
  durationMinutes: number;
  caloriesBurned?: number;
  date: string; // YYYY-MM-DD
  notes?: string;
}

export interface SleepLog {
  id: string;
  date: string; // YYYY-MM-DD
  bedtime: string; // HH:mm
  wakeTime: string; // HH:mm
  durationHours: number;
  quality: 'great' | 'good' | 'fair' | 'poor';
  notes?: string;
}

export interface WeightLog {
  id: string;
  date: string; // YYYY-MM-DD
  weight: number;
  unit: 'kg' | 'lbs';
  notes?: string;
}

export type TransactionType = 'income' | 'expense';

export interface FinanceTransaction {
  id: string;
  type: TransactionType;
  category: string;
  amount: number;
  date: string; // YYYY-MM-DD
  description: string;
  createdAt: string;
}

export type MoodType =
  | 'Happy'
  | 'Motivated'
  | 'Excited'
  | 'Normal'
  | 'Sad'
  | 'Stressed'
  | 'Tired';

export interface JournalEntry {
  id: string;
  date: string; // YYYY-MM-DD
  mood: MoodType;
  thoughts: string;
  achievements: string;
  biggestChallenge: string;
  learnedToday: string;
  tomorrowPlan: string;
  updatedAt: string;
}

export interface UserProfile {
  name: string;
  avatar: string;
  age?: number;
  mainGoal: string;
  productivityTargetPercent: number;
  waterTargetMl: number;
  sleepTargetHours: number;
  studyTargetMinutes: number;
  exerciseTargetMinutes: number;
  theme: 'dark' | 'light';
  notificationsEnabled: boolean;
  reminders: {
    habits: boolean;
    tasks: boolean;
    water: boolean;
    exercise: boolean;
    study: boolean;
    sleep: boolean;
  };
  taskNotifications?: TaskNotificationSettings;
}

export interface DailySummary {
  date: string;
  productivityScore: number;
  completedTasksCount: number;
  totalTasksCount: number;
  completedHabitsCount: number;
  totalHabitsCount: number;
  waterIntakeMl: number;
  exerciseMinutes: number;
  studyMinutes: number;
  sleepHours: number;
  productiveHours: number;
  unproductiveHours: number;
}
