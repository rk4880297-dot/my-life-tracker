import { Capacitor } from '@capacitor/core';
import { LocalNotifications, Channel } from '@capacitor/local-notifications';
import { Task, TaskNotificationSettings } from '../types';

export type NotificationPermissionState = 'default' | 'granted' | 'denied' | 'unsupported';

/**
 * Generate a deterministic positive 32-bit integer ID from a string key
 * (Capacitor LocalNotifications requires a 32-bit signed integer ID)
 */
function hashStringToId(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }
  // Return positive integer between 1 and 2147483647
  return Math.abs(hash) || 1;
}

export function getTaskDueDateTime(task: Task): Date {
  const time = task.dueTime || '23:59';
  const [hours, minutes] = time.split(':').map(Number);
  const dateObj = new Date(`${task.dueDate}T00:00:00`);
  dateObj.setHours(hours, minutes, 0, 0);
  return dateObj;
}

export function isTaskOverdue(task: Task, now: Date = new Date()): boolean {
  if (task.completed) return false;
  // If snoozed until a future time, not considered overdue yet
  if (task.snoozedUntil && new Date(task.snoozedUntil) > now) return false;
  const due = getTaskDueDateTime(task);
  return due < now;
}

export function getOverdueDurationText(dueDateTime: Date, now: Date = new Date()): string {
  const diffMs = now.getTime() - dueDateTime.getTime();
  if (diffMs <= 0) return 'Due now';

  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffDays > 0) {
    const remHours = diffHours % 24;
    return remHours > 0 ? `${diffDays}d ${remHours}h overdue` : `${diffDays}d overdue`;
  }
  if (diffHours > 0) {
    const remMins = diffMinutes % 60;
    return remMins > 0 ? `${diffHours}h ${remMins}m overdue` : `${diffHours}h overdue`;
  }
  return `${Math.max(1, diffMinutes)}m overdue`;
}

export class NotificationService {
  private static channelsInitialized = false;

  static isSupported(): boolean {
    if (Capacitor.isNativePlatform()) return true;
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  static async getPermission(): Promise<NotificationPermissionState> {
    if (Capacitor.isNativePlatform()) {
      try {
        const status = await LocalNotifications.checkPermissions();
        if (status.display === 'granted') return 'granted';
        if (status.display === 'denied') return 'denied';
        return 'default';
      } catch {
        return 'unsupported';
      }
    }

    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission as NotificationPermissionState;
    }
    return 'unsupported';
  }

  static async requestPermission(): Promise<boolean> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await LocalNotifications.requestPermissions();
        await this.initializeChannels();
        return res.display === 'granted';
      } catch (err) {
        console.warn('Capacitor notification permission error:', err);
        return false;
      }
    }

    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const res = await Notification.requestPermission();
        return res === 'granted';
      } catch {
        return false;
      }
    }
    return false;
  }

  /**
   * Configure Android Notification Channels for Local Notifications
   */
  static async initializeChannels(): Promise<void> {
    if (!Capacitor.isNativePlatform() || this.channelsInitialized) return;

    try {
      const taskRemindersChannel: Channel = {
        id: 'task-reminders',
        name: 'Task Deadlines & Reminders',
        description: 'Notifications for upcoming task deadlines and 15-minute alerts',
        importance: 5, // High
        visibility: 1, // Public
        vibration: true,
        sound: 'res://raw/notification.wav',
      };

      const overdueChannel: Channel = {
        id: 'overdue-alerts',
        name: 'Overdue Task Alerts',
        description: 'Urgent alerts when a task is past its scheduled deadline',
        importance: 5,
        visibility: 1,
        vibration: true,
      };

      const dailySummaryChannel: Channel = {
        id: 'daily-summary',
        name: 'Daily Progress Summary',
        description: 'Evening summary of completed, pending, and overdue tasks',
        importance: 4,
        visibility: 1,
        vibration: true,
      };

      await LocalNotifications.createChannel(taskRemindersChannel);
      await LocalNotifications.createChannel(overdueChannel);
      await LocalNotifications.createChannel(dailySummaryChannel);
      this.channelsInitialized = true;
    } catch (e) {
      console.warn('Failed to configure Android notification channels:', e);
    }
  }

  /**
   * Schedule 15-min, deadline, and overdue notifications for a task
   */
  static async scheduleTaskReminders(task: Task, settings: TaskNotificationSettings): Promise<void> {
    if (!settings.enabled) return;

    // First cancel existing notifications for this task to prevent duplicate entries
    await this.cancelTaskReminders(task.id);

    // If task is completed, don't schedule any reminders
    if (task.completed) return;

    const dueDateTime = getTaskDueDateTime(task);
    const now = new Date();

    const notificationsToSchedule: any[] = [];

    // 1. 15-minute reminder before deadline
    if (settings.reminder15Min) {
      const reminderTime = new Date(dueDateTime.getTime() - 15 * 60 * 1000);
      if (reminderTime > now) {
        notificationsToSchedule.push({
          id: hashStringToId(`${task.id}_15min`),
          title: `⏰ Reminder: "${task.title}"`,
          body: `Due in 15 minutes (${task.dueTime || 'end of day'}). Priority: ${task.priority.toUpperCase()}`,
          schedule: { at: reminderTime, allowWhileIdle: true },
          channelId: 'task-reminders',
          sound: 'default',
          extra: { taskId: task.id, type: '15min' },
        });
      }
    }

    // 2. Exact deadline reminder
    if (settings.deadlineReminder) {
      if (dueDateTime > now) {
        notificationsToSchedule.push({
          id: hashStringToId(`${task.id}_deadline`),
          title: `🎯 Task Deadline: "${task.title}"`,
          body: `This task is due right now! Priority: ${task.priority.toUpperCase()}`,
          schedule: { at: dueDateTime, allowWhileIdle: true },
          channelId: 'task-reminders',
          sound: 'default',
          extra: { taskId: task.id, type: 'deadline' },
        });
      }
    }

    // 3. Overdue alert (15 minutes after deadline if still incomplete)
    if (settings.overdueReminder) {
      const overdueTime = new Date(dueDateTime.getTime() + 15 * 60 * 1000);
      if (overdueTime > now) {
        notificationsToSchedule.push({
          id: hashStringToId(`${task.id}_overdue`),
          title: `⚠️ Overdue Task: "${task.title}"`,
          body: `Task deadline was 15 minutes ago. Mark complete or reschedule now.`,
          schedule: { at: overdueTime, allowWhileIdle: true },
          channelId: 'overdue-alerts',
          sound: 'default',
          extra: { taskId: task.id, type: 'overdue' },
        });
      }
    }

    if (notificationsToSchedule.length > 0 && Capacitor.isNativePlatform()) {
      try {
        await this.initializeChannels();
        await LocalNotifications.schedule({ notifications: notificationsToSchedule });
      } catch (err) {
        console.warn('Failed to schedule native Capacitor notifications:', err);
      }
    }
  }

  /**
   * Cancel all notifications associated with a task
   */
  static async cancelTaskReminders(taskId: string): Promise<void> {
    if (!Capacitor.isNativePlatform()) return;

    try {
      const ids = [
        hashStringToId(`${taskId}_15min`),
        hashStringToId(`${taskId}_deadline`),
        hashStringToId(`${taskId}_overdue`),
      ];
      await LocalNotifications.cancel({ notifications: ids.map((id) => ({ id })) });
    } catch (e) {
      console.warn('Failed to cancel notifications for task:', taskId, e);
    }
  }

  /**
   * Schedule Daily Summary notification at 9:00 PM (or custom time)
   */
  static async scheduleDailySummary(tasks: Task[], settings: TaskNotificationSettings): Promise<void> {
    if (!settings.enabled || !settings.dailySummary) return;

    const summaryId = 999999;

    // Calculate daily task counts for today
    const todayStr = new Date().toISOString().slice(0, 10);
    const todayTasks = tasks.filter((t) => t.dueDate === todayStr);
    const completed = todayTasks.filter((t) => t.completed).length;
    const pending = todayTasks.filter((t) => !t.completed).length;
    const overdue = tasks.filter((t) => isTaskOverdue(t)).length;

    const bodyText = `Completed: ${completed} Tasks | Pending: ${pending} Tasks | Overdue: ${overdue} Task${
      overdue !== 1 ? 's' : ''
    }\nDon't forget to complete your remaining tasks!`;

    // Parse target time (e.g. "21:00")
    const timeStr = settings.dailySummaryTime || '21:00';
    const [h, m] = timeStr.split(':').map(Number);

    const scheduleDate = new Date();
    scheduleDate.setHours(h, m, 0, 0);

    // If 9:00 PM has already passed today, schedule for tomorrow 9:00 PM
    if (scheduleDate <= new Date()) {
      scheduleDate.setDate(scheduleDate.getDate() + 1);
    }

    if (Capacitor.isNativePlatform()) {
      try {
        await this.initializeChannels();
        await LocalNotifications.cancel({ notifications: [{ id: summaryId }] });
        await LocalNotifications.schedule({
          notifications: [
            {
              id: summaryId,
              title: '📊 Your Daily Progress Report',
              body: bodyText,
              schedule: { at: scheduleDate, allowWhileIdle: true },
              channelId: 'daily-summary',
              sound: 'default',
            },
          ],
        });
      } catch (e) {
        console.warn('Failed to schedule daily summary notification:', e);
      }
    }
  }

  /**
   * Send an immediate notification on both Native Android and Web
   */
  static async sendImmediate(title: string, body: string, channelId: string = 'task-reminders'): Promise<boolean> {
    // Native Android
    if (Capacitor.isNativePlatform()) {
      try {
        await this.initializeChannels();
        await LocalNotifications.schedule({
          notifications: [
            {
              id: Math.floor(Math.random() * 100000) + 1000,
              title,
              body,
              schedule: { at: new Date(Date.now() + 500) },
              channelId,
              sound: 'default',
            },
          ],
        });
        return true;
      } catch (err) {
        console.warn('Capacitor sendImmediate error:', err);
      }
    }

    // Web Browser Notification fallback
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
        });
        return true;
      } catch (e) {
        console.warn('Web notification send error:', e);
      }
    }

    return false;
  }

  /**
   * Backward-compatibility helper for legacy send calls
   */
  static async send(title: string, options?: { body?: string }): Promise<boolean> {
    return this.sendImmediate(title, options?.body || '');
  }
}
