import { AppStateData } from './storage';
import { Habit, Activity, Task, Goal, JournalEntry, DailySummary } from '../types';

export interface ProductivityBreakdown {
  score: number;
  taskScore: number;
  habitScore: number;
  timeScore: number;
  healthScore: number;
  tasksCompleted: number;
  tasksTotal: number;
  habitsCompleted: number;
  habitsTotal: number;
  productiveMinutes: number;
  unproductiveMinutes: number;
  neutralMinutes: number;
  totalTrackedMinutes: number;
  waterIntakeMl: number;
  exerciseMinutes: number;
  studyMinutes: number;
  sleepHours: number;
}

export function calculateDayProductivity(
  date: string,
  data: AppStateData
): ProductivityBreakdown {
  // 1. Tasks for this date
  const dayTasks = data.tasks.filter((t) => t.dueDate === date);
  const tasksCompleted = dayTasks.filter((t) => t.completed).length;
  const tasksTotal = dayTasks.length;
  const taskScore = tasksTotal > 0 ? (tasksCompleted / tasksTotal) * 100 : 80;

  // 2. Habits for this date
  const activeHabits = data.habits.filter((h) => !h.archived);
  const dayHabitLogs = data.habitLogs.filter((l) => l.date === date && l.completed);
  const habitsCompleted = dayHabitLogs.length;
  const habitsTotal = activeHabits.length;
  const habitScore = habitsTotal > 0 ? (habitsCompleted / habitsTotal) * 100 : 80;

  // 3. Activities for this date
  const dayActivities = data.activities.filter((a) => a.date === date);
  let productiveMinutes = 0;
  let unproductiveMinutes = 0;
  let neutralMinutes = 0;
  let studyMinutes = 0;
  let exerciseMinutes = 0;

  dayActivities.forEach((a) => {
    if (a.productivityRating === 'productive') {
      productiveMinutes += a.durationMinutes;
    } else if (a.productivityRating === 'unproductive') {
      unproductiveMinutes += a.durationMinutes;
    } else {
      neutralMinutes += a.durationMinutes;
    }

    if (a.category === 'Study') {
      studyMinutes += a.durationMinutes;
    } else if (a.category === 'Exercise') {
      exerciseMinutes += a.durationMinutes;
    }
  });

  const totalTrackedMinutes = productiveMinutes + unproductiveMinutes + neutralMinutes;
  // If user tracked at least 180 min of productive work, or high proportion
  let timeScore = 70;
  if (totalTrackedMinutes > 0) {
    const ratio = productiveMinutes / (productiveMinutes + unproductiveMinutes * 1.5 || 1);
    timeScore = Math.min(100, Math.round(ratio * 100));
  } else if (tasksCompleted > 0 || habitsCompleted > 0) {
    timeScore = 75;
  }

  // 4. Health metrics
  const waterLogs = data.waterLogs.filter((w) => w.date === date);
  const waterIntakeMl = waterLogs.reduce((acc, curr) => acc + curr.amountMl, 0);
  const waterScore = Math.min(100, (waterIntakeMl / (data.profile.waterTargetMl || 3000)) * 100);

  const workoutLogs = data.workoutLogs.filter((w) => w.date === date);
  const workoutMin = workoutLogs.reduce((acc, curr) => acc + curr.durationMinutes, 0) + exerciseMinutes;

  const sleepLog = data.sleepLogs.find((s) => s.date === date);
  const sleepHours = sleepLog ? sleepLog.durationHours : 7.5;
  const sleepScore = Math.min(100, (sleepHours / (data.profile.sleepTargetHours || 8)) * 100);

  const healthScore = Math.round(waterScore * 0.4 + (workoutMin >= 30 ? 100 : (workoutMin / 30) * 100) * 0.3 + sleepScore * 0.3);

  // Overall Score (Weighted: 30% Tasks, 35% Habits, 25% Time, 10% Health)
  const score = Math.min(
    100,
    Math.max(
      0,
      Math.round(
        taskScore * 0.3 +
        habitScore * 0.35 +
        timeScore * 0.25 +
        healthScore * 0.1
      )
    )
  );

  return {
    score,
    taskScore: Math.round(taskScore),
    habitScore: Math.round(habitScore),
    timeScore: Math.round(timeScore),
    healthScore: Math.round(healthScore),
    tasksCompleted,
    tasksTotal,
    habitsCompleted,
    habitsTotal,
    productiveMinutes,
    unproductiveMinutes,
    neutralMinutes,
    totalTrackedMinutes,
    waterIntakeMl,
    exerciseMinutes: workoutMin,
    studyMinutes,
    sleepHours,
  };
}

/**
 * Calculate consecutive active streak and longest streak in days
 */
export function calculateStreaks(data: AppStateData): { currentStreak: number; longestStreak: number } {
  const datesWithActivity = new Set<string>();

  data.activities.forEach((a) => datesWithActivity.add(a.date));
  data.tasks.forEach((t) => {
    if (t.completed && t.dueDate) datesWithActivity.add(t.dueDate);
  });
  data.habitLogs.forEach((h) => {
    if (h.completed && h.date) datesWithActivity.add(h.date);
  });
  data.waterLogs.forEach((w) => datesWithActivity.add(w.date));
  data.workoutLogs.forEach((w) => datesWithActivity.add(w.date));

  const sortedDates = Array.from(datesWithActivity).sort();
  if (sortedDates.length === 0) return { currentStreak: 0, longestStreak: 0 };

  // Calculate current streak backward from today
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let currentStreak = 0;
  let checkDate = new Date(today);

  // If today isn't logged yet, check if yesterday was logged to preserve streak
  const checkDateStr = checkDate.toISOString().slice(0, 10);
  if (!datesWithActivity.has(checkDateStr)) {
    checkDate.setDate(checkDate.getDate() - 1);
  }

  while (true) {
    const dStr = checkDate.toISOString().slice(0, 10);
    if (datesWithActivity.has(dStr)) {
      currentStreak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  // Calculate longest streak
  let longestStreak = 0;
  let tempStreak = 0;
  let prevTime = 0;

  for (const dateStr of sortedDates) {
    const curTime = new Date(dateStr).getTime();
    if (prevTime === 0) {
      tempStreak = 1;
    } else {
      const diffDays = Math.round((curTime - prevTime) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        tempStreak++;
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
    }
    prevTime = curTime;
    if (tempStreak > longestStreak) longestStreak = tempStreak;
  }

  return {
    currentStreak: Math.max(currentStreak, 1),
    longestStreak: Math.max(longestStreak, currentStreak, 1),
  };
}

/**
 * Habit streak calculator
 */
export function calculateHabitStreaks(habitId: string, habitLogs: AppStateData['habitLogs']) {
  const completedLogs = habitLogs
    .filter((l) => l.habitId === habitId && l.completed)
    .sort((a, b) => a.date.localeCompare(b.date));

  if (completedLogs.length === 0) return { currentStreak: 0, longestStreak: 0, completionRate: 0 };

  const dates = new Set(completedLogs.map((l) => l.date));
  let currentStreak = 0;
  const d = new Date();
  d.setHours(0, 0, 0, 0);

  if (!dates.has(d.toISOString().slice(0, 10))) {
    d.setDate(d.getDate() - 1);
  }

  while (dates.has(d.toISOString().slice(0, 10))) {
    currentStreak++;
    d.setDate(d.getDate() - 1);
  }

  // Longest streak
  let longestStreak = 0;
  let cur = 0;
  let prevDate: Date | null = null;

  for (const log of completedLogs) {
    const curDate = new Date(log.date);
    if (!prevDate) {
      cur = 1;
    } else {
      const diff = Math.round((curDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
      if (diff === 1) {
        cur++;
      } else {
        cur = 1;
      }
    }
    prevDate = curDate;
    if (cur > longestStreak) longestStreak = cur;
  }

  const completionRate = Math.min(100, Math.round((completedLogs.length / 30) * 100));

  return {
    currentStreak,
    longestStreak: Math.max(longestStreak, currentStreak),
    completionRate,
  };
}

/**
 * Personalized Improvement Suggestions based on actual user data
 */
export function generateSmartSuggestions(data: AppStateData, todayDate: string): string[] {
  const suggestions: string[] = [];
  const todayBreakdown = calculateDayProductivity(todayDate, data);

  // Time-based check
  if (todayBreakdown.unproductiveMinutes >= 60) {
    suggestions.push(
      `You recorded ${(todayBreakdown.unproductiveMinutes / 60).toFixed(1)} hrs of unproductive time today. Shifting 30 mins into deep work or learning will increase your score by ~12%.`
    );
  }

  // Water check
  const waterTarget = data.profile.waterTargetMl || 3000;
  if (todayBreakdown.waterIntakeMl < waterTarget * 0.6) {
    const rem = waterTarget - todayBreakdown.waterIntakeMl;
    suggestions.push(
      `Hydration deficit: You need ${rem} ml more water today to reach your ${waterTarget} ml goal. Keep a water bottle at your desk!`
    );
  }

  // Habits check
  const activeHabits = data.habits.filter((h) => !h.archived);
  const remainingHabits = activeHabits.length - todayBreakdown.habitsCompleted;
  if (remainingHabits > 0) {
    suggestions.push(
      `You have ${remainingHabits} habit${remainingHabits > 1 ? 's' : ''} left for today. Complete them before 9:00 PM to keep your streak intact.`
    );
  }

  // Study check
  if (todayBreakdown.studyMinutes < (data.profile.studyTargetMinutes || 90)) {
    const diff = (data.profile.studyTargetMinutes || 90) - todayBreakdown.studyMinutes;
    suggestions.push(
      `Dedicate ${diff} more minutes to focused study or skill practice to hit your daily growth benchmark.`
    );
  }

  // Exercise check
  if (todayBreakdown.exerciseMinutes < 30) {
    suggestions.push(
      `Physical momentum boosts cognitive clarity. A quick 20-minute bodyweight routine or brisk walk will close your exercise gap.`
    );
  }

  // Sleep check
  if (todayBreakdown.sleepHours < 7) {
    suggestions.push(
      `You logged ${todayBreakdown.sleepHours} hrs of sleep. Aim to wind down 45 minutes earlier tonight to recharge neuro-cognitive performance.`
    );
  }

  if (suggestions.length === 0) {
    suggestions.push(
      'Outstanding consistency! You are performing above your daily target across habits, deep focus, and health.'
    );
  }

  return suggestions;
}

export const MOTIVATIONAL_QUOTES = [
  { text: "We are what we repeatedly do. Excellence, then, is not an act, but a habit.", author: "Will Durant" },
  { text: "You do not rise to the level of your goals. You fall to the level of your systems.", author: "James Clear" },
  { text: "Small disciplines repeated with consistency every day lead to great achievements.", author: "John C. Maxwell" },
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Action is the foundational key to all success.", author: "Pablo Picasso" },
  { text: "Focus on being productive instead of busy.", author: "Tim Ferriss" },
  { text: "Do something today that your future self will thank you for.", author: "Sean Patrick Flanery" },
  { text: "Success is the sum of small efforts, repeated day in and day out.", author: "Robert Collier" },
  { text: "Your time is limited, don't waste it living someone else's life.", author: "Steve Jobs" },
  { text: "Discipline is choosing between what you want now and what you want most.", author: "Abraham Lincoln" },
];

export function getDailyQuote(): { text: string; author: string } {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  return MOTIVATIONAL_QUOTES[dayOfYear % MOTIVATIONAL_QUOTES.length];
}
