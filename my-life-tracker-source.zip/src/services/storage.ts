import {
  Activity,
  Habit,
  HabitLog,
  Task,
  Goal,
  WaterLog,
  WorkoutLog,
  SleepLog,
  WeightLog,
  FinanceTransaction,
  JournalEntry,
  UserProfile,
  TaskNotificationSettings,
} from '../types';

const DB_NAME = 'MyLifeTrackerDB';
const DB_VERSION = 1;

export interface AppStateData {
  activities: Activity[];
  habits: Habit[];
  habitLogs: HabitLog[];
  tasks: Task[];
  goals: Goal[];
  waterLogs: WaterLog[];
  workoutLogs: WorkoutLog[];
  sleepLogs: SleepLog[];
  weightLogs: WeightLog[];
  transactions: FinanceTransaction[];
  journalEntries: JournalEntry[];
  profile: UserProfile;
}

export const DEFAULT_TASK_NOTIFICATIONS: TaskNotificationSettings = {
  enabled: true,
  reminder15Min: true,
  deadlineReminder: true,
  overdueReminder: true,
  dailySummary: true,
  dailySummaryTime: '21:00',
};

export const DEFAULT_PROFILE: UserProfile = {
  name: 'Alex Hunter',
  avatar: '🚀',
  age: 26,
  mainGoal: 'Build an unstoppable daily routine and achieve peak mental & physical health',
  productivityTargetPercent: 80,
  waterTargetMl: 3000,
  sleepTargetHours: 8,
  studyTargetMinutes: 90,
  exerciseTargetMinutes: 45,
  theme: 'dark',
  notificationsEnabled: true,
  reminders: {
    habits: true,
    tasks: true,
    water: true,
    exercise: true,
    study: true,
    sleep: true,
  },
  taskNotifications: DEFAULT_TASK_NOTIFICATIONS,
};

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDateOffset(offsetDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const INITIAL_HABITS: Habit[] = [
  {
    id: 'habit-1',
    name: 'Morning Meditation & Breathwork',
    icon: '🧘',
    category: 'Health',
    dailyTarget: '15 mins',
    reminderTime: '06:30',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-2',
    name: 'Drink 3 Litres Water',
    icon: '💧',
    category: 'Health',
    dailyTarget: '3000 ml',
    reminderTime: '09:00',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-3',
    name: 'Deep Focus Study / Skill Building',
    icon: '📚',
    category: 'Study',
    dailyTarget: '60 mins',
    reminderTime: '10:00',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-4',
    name: 'Workout or 30-min brisk walk',
    icon: '⚡',
    category: 'Exercise',
    dailyTarget: '45 mins',
    reminderTime: '17:00',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-5',
    name: 'Avoid Mindless Social Media',
    icon: '📵',
    category: 'Personal Development',
    dailyTarget: 'Under 30m',
    reminderTime: '14:00',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-6',
    name: 'Evening Journal & Review',
    icon: '✍️',
    category: 'Personal Development',
    dailyTarget: '10 mins',
    reminderTime: '21:30',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'habit-7',
    name: 'Sleep on Time (by 11 PM)',
    icon: '🌙',
    category: 'Health',
    dailyTarget: '8 hours',
    reminderTime: '22:45',
    frequency: 'daily',
    startDate: formatDateOffset(-30),
    createdAt: new Date().toISOString(),
  },
];

export function getInitialSeedData(): AppStateData {
  const today = getTodayDateString();
  const yesterday = formatDateOffset(-1);
  const twoDaysAgo = formatDateOffset(-2);
  const threeDaysAgo = formatDateOffset(-3);

  const habitLogs: HabitLog[] = [];
  // Populate realistic streak history for the last 14 days
  for (let i = 0; i <= 14; i++) {
    const d = formatDateOffset(-i);
    INITIAL_HABITS.forEach((h, idx) => {
      // Completed most habits with high consistency
      const completed = i === 0 ? idx < 5 : (i % 5 !== 0 || idx % 2 === 0);
      habitLogs.push({
        id: `hlog-${h.id}-${d}`,
        habitId: h.id,
        date: d,
        completed,
        completedAt: completed ? `${d}T12:00:00.000Z` : undefined,
      });
    });
  }

  const tasks: Task[] = [
    {
      id: 'task-1',
      title: 'Complete System Architecture Review',
      description: 'Review performance bottlenecks and mobile responsiveness.',
      priority: 'high',
      category: 'Business',
      dueDate: today,
      dueTime: '14:00',
      completed: true,
      completedAt: `${today}T11:30:00.000Z`,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-2',
      title: 'Complete 45 min Strength & Mobility session',
      description: 'Core stability and full body stretch.',
      priority: 'medium',
      category: 'Exercise',
      dueDate: today,
      dueTime: '17:30',
      completed: true,
      completedAt: `${today}T17:45:00.000Z`,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-3',
      title: 'Review Monthly Budget and Savings Goal',
      description: 'Allocate 25% surplus into investments.',
      priority: 'medium',
      category: 'Business',
      dueDate: today,
      dueTime: '18:00',
      completed: true,
      completedAt: `${today}T16:00:00.000Z`,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-4',
      title: 'Read 2 chapters of "Atomic Habits"',
      description: 'Take active notes on identity-based habit loops.',
      priority: 'low',
      category: 'Personal Development',
      dueDate: today,
      dueTime: '20:30',
      completed: false,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-5',
      title: 'Write Weekly Retrospective & Goal Setting',
      description: 'Analyze weekly productive hours vs distractors.',
      priority: 'high',
      category: 'Personal Development',
      dueDate: formatDateOffset(1),
      dueTime: '10:00',
      completed: false,
      createdAt: new Date().toISOString(),
    },
  ];

  const activities: Activity[] = [
    {
      id: 'act-1',
      name: 'Early Morning Run & Stretching',
      category: 'Exercise',
      startTime: '06:45',
      endTime: '07:30',
      durationMinutes: 45,
      date: today,
      description: 'Outdoor brisk 5km run in cool morning air.',
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-2',
      name: 'Product Architecture & Deep Code Review',
      category: 'Business',
      startTime: '09:00',
      endTime: '11:45',
      durationMinutes: 165,
      date: today,
      description: 'Designed offline sync engine and responsive UI components.',
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-3',
      name: 'Healthy Lunch & Family Conversation',
      category: 'Family',
      startTime: '12:00',
      endTime: '12:45',
      durationMinutes: 45,
      date: today,
      description: 'High-protein lunch and quality chat with family.',
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-4',
      name: 'Modern Web Engineering & TypeScript Study',
      category: 'Study',
      startTime: '14:00',
      endTime: '15:30',
      durationMinutes: 90,
      date: today,
      description: 'Studied state machines and service workers caching strategies.',
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-5',
      name: 'Relaxation & Reading Tech Articles',
      category: 'Entertainment',
      startTime: '16:00',
      endTime: '16:40',
      durationMinutes: 40,
      date: today,
      description: 'Coffee break and industry newsletter reading.',
      productivityRating: 'neutral',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    // Past activities for realistic history
    {
      id: 'act-prev-1',
      name: 'High Intensity Interval Training',
      category: 'Exercise',
      startTime: '07:00',
      endTime: '07:45',
      durationMinutes: 45,
      date: yesterday,
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-prev-2',
      name: 'Quarterly Planning & Strategy',
      category: 'Business',
      startTime: '09:30',
      endTime: '12:30',
      durationMinutes: 180,
      date: yesterday,
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'act-prev-3',
      name: 'Database Optimization Study',
      category: 'Study',
      startTime: '14:00',
      endTime: '16:00',
      durationMinutes: 120,
      date: yesterday,
      productivityRating: 'productive',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
  ];

  const goals: Goal[] = [
    {
      id: 'goal-1',
      name: 'Complete 30 Consecutive Active Days',
      description: 'Maintain 75%+ daily productivity for 30 consecutive days.',
      category: 'Personal',
      targetDate: formatDateOffset(15),
      targetValue: 30,
      currentProgress: 18,
      unit: 'days',
      priority: 'high',
      status: 'active',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'goal-2',
      name: 'Master Advanced Full-Stack Architecture',
      description: 'Finish 120 total hours of deep engineering practice.',
      category: 'Education',
      targetDate: formatDateOffset(45),
      targetValue: 120,
      currentProgress: 78,
      unit: 'hours',
      priority: 'high',
      status: 'active',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'goal-3',
      name: 'Build Emergency Fund & Savings Target',
      description: 'Save $5,000 in personal liquidity fund.',
      category: 'Financial',
      targetDate: formatDateOffset(60),
      targetValue: 5000,
      currentProgress: 3600,
      unit: '$',
      priority: 'medium',
      status: 'active',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'goal-4',
      name: 'Hit Target Body Composition (72 kg)',
      description: 'Consistent strength training, 10k steps, and clean nutrition.',
      category: 'Fitness',
      targetDate: formatDateOffset(30),
      targetValue: 72,
      currentProgress: 74.2,
      unit: 'kg',
      priority: 'medium',
      status: 'active',
      createdAt: new Date().toISOString(),
    },
  ];

  const waterLogs: WaterLog[] = [
    { id: 'w-1', date: today, amountMl: 500, timestamp: '07:30' },
    { id: 'w-2', date: today, amountMl: 500, timestamp: '10:00' },
    { id: 'w-3', date: today, amountMl: 750, timestamp: '12:30' },
    { id: 'w-4', date: today, amountMl: 500, timestamp: '15:45' },
    { id: 'w-prev-1', date: yesterday, amountMl: 3000, timestamp: '20:00' },
    { id: 'w-prev-2', date: twoDaysAgo, amountMl: 2750, timestamp: '20:00' },
  ];

  const workoutLogs: WorkoutLog[] = [
    {
      id: 'wo-1',
      exerciseName: '5km Morning Run & Calisthenics',
      category: 'Cardio',
      durationMinutes: 45,
      caloriesBurned: 380,
      date: today,
      notes: 'Pace was 5:20/km, felt energetic.',
    },
    {
      id: 'wo-prev-1',
      exerciseName: 'Upper Body Hypertrophy',
      category: 'Strength',
      durationMinutes: 50,
      caloriesBurned: 320,
      date: yesterday,
      notes: 'Bench press, pull-ups, dumbbell curls.',
    },
    {
      id: 'wo-prev-2',
      exerciseName: 'Leg Day & Core Stability',
      category: 'Strength',
      durationMinutes: 55,
      caloriesBurned: 410,
      date: threeDaysAgo,
      notes: 'Squats, Romanian deadlifts, hanging leg raises.',
    },
  ];

  const sleepLogs: SleepLog[] = [
    {
      id: 'sl-1',
      date: today,
      bedtime: '23:00',
      wakeTime: '06:30',
      durationHours: 7.5,
      quality: 'great',
      notes: 'Woke up naturally before alarm, refreshed.',
    },
    {
      id: 'sl-2',
      date: yesterday,
      bedtime: '23:15',
      wakeTime: '06:45',
      durationHours: 7.5,
      quality: 'good',
      notes: 'Deep sleep throughout the night.',
    },
    {
      id: 'sl-3',
      date: twoDaysAgo,
      bedtime: '22:45',
      wakeTime: '06:30',
      durationHours: 7.75,
      quality: 'great',
      notes: 'Slept like a rock.',
    },
  ];

  const weightLogs: WeightLog[] = [
    { id: 'wt-1', date: formatDateOffset(-21), weight: 76.5, unit: 'kg' },
    { id: 'wt-2', date: formatDateOffset(-14), weight: 75.8, unit: 'kg' },
    { id: 'wt-3', date: formatDateOffset(-7), weight: 75.0, unit: 'kg' },
    { id: 'wt-4', date: today, weight: 74.2, unit: 'kg', notes: 'Consistent drop, lean mass preserved.' },
  ];

  const transactions: FinanceTransaction[] = [
    {
      id: 'tx-1',
      type: 'income',
      category: 'Freelance & Consulting',
      amount: 1450,
      date: today,
      description: 'Web application milestone payout',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'tx-2',
      type: 'expense',
      category: 'Groceries & Health Food',
      amount: 85,
      date: today,
      description: 'Fresh fruits, vegetables, olive oil, and salmon',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'tx-3',
      type: 'expense',
      category: 'Utilities & Subscriptions',
      amount: 45,
      date: yesterday,
      description: 'Cloud hosting & development tools',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'tx-4',
      type: 'income',
      category: 'Salary',
      amount: 3200,
      date: formatDateOffset(-10),
      description: 'Monthly base compensation',
      createdAt: new Date().toISOString(),
    },
  ];

  const journalEntries: JournalEntry[] = [
    {
      id: 'jn-1',
      date: today,
      mood: 'Motivated',
      thoughts: 'Clear focus today. Got all primary objectives accomplished ahead of time.',
      achievements: 'Completed architecture review, drank 2.25L of water, stayed off doom-scrolling.',
      biggestChallenge: 'Avoiding distraction around mid-afternoon energy slump.',
      learnedToday: 'Short brisk walks during lunch completely eliminate afternoon brain fog.',
      tomorrowPlan: 'Tackle the weekly retrospective and organize goal sprints.',
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'jn-2',
      date: yesterday,
      mood: 'Happy',
      thoughts: 'Spent deep, undisturbed hours coding. Great momentum.',
      achievements: 'Exercised with intensity and hit all habit marks.',
      biggestChallenge: 'Balancing client messages with deep work blocks.',
      learnedToday: 'Batching replies to twice a day saves at least 1.5 hours.',
      tomorrowPlan: 'Execute the high-impact roadmap tasks first thing in the morning.',
      updatedAt: new Date().toISOString(),
    },
  ];

  return {
    activities,
    habits: INITIAL_HABITS,
    habitLogs,
    tasks,
    goals,
    waterLogs,
    workoutLogs,
    sleepLogs,
    weightLogs,
    transactions,
    journalEntries,
    profile: DEFAULT_PROFILE,
  };
}

class StorageManager {
  private db: IDBDatabase | null = null;
  private readonly fallbackKey = 'MY_LIFE_TRACKER_DATA';

  async initDB(): Promise<IDBDatabase> {
    if (this.db) return this.db;

    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        return reject(new Error('IndexedDB not supported'));
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('appData')) {
          db.createObjectStore('appData', { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        resolve(this.db);
      };

      request.onerror = (event) => {
        console.warn('IndexedDB open error, falling back to localStorage', event);
        reject(new Error('IndexedDB open failed'));
      };
    });
  }

  async loadAllData(): Promise<AppStateData> {
    try {
      const db = await this.initDB();
      return new Promise<AppStateData>((resolve) => {
        const tx = db.transaction('appData', 'readonly');
        const store = tx.objectStore('appData');
        const req = store.get('root_state');

        req.onsuccess = () => {
          if (req.result && req.result.data) {
            resolve(this.normalizeLoadedData(req.result.data as AppStateData));
          } else {
            // Check localStorage
            const local = this.loadFromLocalStorage();
            if (local) {
              const norm = this.normalizeLoadedData(local);
              this.saveAllData(norm);
              resolve(norm);
            } else {
              const seed = getInitialSeedData();
              this.saveAllData(seed);
              resolve(seed);
            }
          }
        };

        req.onerror = () => {
          const fallback = this.loadFromLocalStorage() || getInitialSeedData();
          resolve(this.normalizeLoadedData(fallback));
        };
      });
    } catch {
      const fallback = this.loadFromLocalStorage() || getInitialSeedData();
      return this.normalizeLoadedData(fallback);
    }
  }

  private normalizeLoadedData(data: AppStateData): AppStateData {
    if (!data) return getInitialSeedData();
    if (!data.profile) data.profile = { ...DEFAULT_PROFILE };
    if (!data.profile.taskNotifications) {
      data.profile.taskNotifications = { ...DEFAULT_TASK_NOTIFICATIONS };
    }
    return data;
  }

  async saveAllData(data: AppStateData): Promise<void> {
    // Save to localStorage as immediate duplicate backup
    try {
      localStorage.setItem(this.fallbackKey, JSON.stringify(data));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }

    try {
      const db = await this.initDB();
      return new Promise<void>((resolve, reject) => {
        const tx = db.transaction('appData', 'readwrite');
        const store = tx.objectStore('appData');
        const req = store.put({ id: 'root_state', data, updatedAt: new Date().toISOString() });

        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    } catch (e) {
      console.warn('IndexedDB save failed, saved in localStorage:', e);
    }
  }

  private loadFromLocalStorage(): AppStateData | null {
    try {
      const raw = localStorage.getItem(this.fallbackKey);
      if (raw) return JSON.parse(raw) as AppStateData;
    } catch {
      // ignore
    }
    return null;
  }

  async clearAllData(): Promise<AppStateData> {
    const seed = getInitialSeedData();
    await this.saveAllData(seed);
    return seed;
  }
}

export const storage = new StorageManager();

/**
 * Export full backup as JSON
 */
export function exportDataAsJSON(data: AppStateData): void {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `my-life-tracker-backup-${getTodayDateString()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Export Activities and Tasks as CSV Reports
 */
export function exportActivitiesCSV(activities: Activity[]): void {
  const headers = ['Date', 'Name', 'Category', 'Start Time', 'End Time', 'Duration (Min)', 'Productivity Rating', 'Status', 'Description'];
  const rows = activities.map(a => [
    `"${a.date}"`,
    `"${a.name.replace(/"/g, '""')}"`,
    `"${a.category}"`,
    `"${a.startTime}"`,
    `"${a.endTime}"`,
    a.durationMinutes,
    `"${a.productivityRating}"`,
    `"${a.status}"`,
    `"${(a.description || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `activities-report-${getTodayDateString()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportTasksCSV(tasks: Task[]): void {
  const headers = ['Title', 'Category', 'Priority', 'Due Date', 'Due Time', 'Status', 'Completed At', 'Description'];
  const rows = tasks.map(t => [
    `"${t.title.replace(/"/g, '""')}"`,
    `"${t.category}"`,
    `"${t.priority}"`,
    `"${t.dueDate}"`,
    `"${t.dueTime || ''}"`,
    t.completed ? '"Completed"' : '"Pending"',
    `"${t.completedAt || ''}"`,
    `"${(t.description || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `tasks-report-${getTodayDateString()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportFinancesCSV(transactions: FinanceTransaction[]): void {
  const headers = ['Date', 'Type', 'Category', 'Amount', 'Description'];
  const rows = transactions.map(t => [
    `"${t.date}"`,
    `"${t.type}"`,
    `"${t.category}"`,
    t.amount,
    `"${(t.description || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `finances-report-${getTodayDateString()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
