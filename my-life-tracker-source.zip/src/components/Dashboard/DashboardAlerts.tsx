import React, { useState } from 'react';
import {
  AlertTriangle,
  Clock,
  CheckCircle2,
  Calendar,
  BellRing,
  MoreVertical,
  Trash2,
  CalendarClock,
  AlarmClock,
  Sparkles,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Task, OverdueTaskInfo } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { RescheduleModal } from '../Tasks/RescheduleModal';
import { ConfirmModal } from '../Common/ConfirmModal';

export const DashboardAlerts: React.FC = () => {
  const {
    data,
    overdueTasks,
    pendingTasksCount,
    toggleTask,
    deleteTask,
    snoozeTask,
    setActiveNavTab,
  } = useLifeTracker();

  const [rescheduleTarget, setRescheduleTarget] = useState<Task | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [snoozeMenuTaskId, setSnoozeMenuTaskId] = useState<string | null>(null);

  // Incomplete tasks due today or earlier
  const incompleteTasks = data.tasks.filter((t) => !t.completed);

  return (
    <div className="space-y-4">
      {/* 1. SEPARATE OVERDUE TASKS SECTION WITH RED NOTIFICATION BADGE */}
      {overdueTasks.length > 0 && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-950/70 via-slate-900 to-rose-950/30 border-2 border-rose-500/40 p-5 sm:p-6 shadow-2xl shadow-rose-950/30 animate-in fade-in duration-300">
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-40 h-40 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />

          {/* Overdue Section Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-rose-500/20">
            <div className="flex items-center gap-3">
              <div className="relative p-2.5 rounded-2xl bg-rose-500/20 text-rose-400 shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-500"></span>
                </span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                    Action Required: Overdue Tasks
                  </h3>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-black bg-rose-600 text-white shadow-md animate-pulse">
                    {overdueTasks.length} OVERDUE
                  </span>
                </div>
                <p className="text-xs text-rose-200/80 mt-0.5">
                  These tasks exceeded their deadline and require your immediate attention.
                </p>
              </div>
            </div>

            <div className="text-xs font-semibold text-rose-300/90 font-mono bg-rose-950/50 px-3 py-1.5 rounded-xl border border-rose-500/30 self-stretch sm:self-center text-center">
              Never auto-completed
            </div>
          </div>

          {/* Overdue Task Cards List */}
          <div className="mt-4 space-y-3">
            {overdueTasks.map(({ task, overdueDurationText }) => (
              <div
                key={task.id}
                className="relative group rounded-2xl bg-slate-950/85 border border-rose-500/30 hover:border-rose-400/60 p-4 transition-all shadow-lg hover:shadow-rose-900/10"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  {/* Task details */}
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm sm:text-base font-extrabold text-white truncate">
                        {task.title}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40">
                        {task.priority} Priority
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold text-slate-400 bg-slate-900 border border-slate-800">
                        {task.category}
                      </span>
                    </div>

                    {task.description && (
                      <p className="text-xs text-slate-300 line-clamp-1">
                        {task.description}
                      </p>
                    )}

                    {/* Deadline and Overdue Duration Banner */}
                    <div className="flex flex-wrap items-center gap-2.5 text-xs">
                      <div className="flex items-center gap-1 text-slate-400 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-rose-400" />
                        <span>Deadline: {task.dueDate} {task.dueTime || ''}</span>
                      </div>
                      <span className="text-rose-500">•</span>
                      <div className="flex items-center gap-1 font-bold text-rose-400 font-mono bg-rose-950/60 px-2 py-0.5 rounded-lg border border-rose-500/40">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{overdueDurationText}</span>
                      </div>
                    </div>
                  </div>

                  {/* SMART TASK MANAGEMENT ACTION BUTTONS */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800">
                    {/* 1. Mark Completed */}
                    <button
                      onClick={() => toggleTask(task.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-sm active:scale-95"
                      title="Mark Completed"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Complete</span>
                    </button>

                    {/* 2. Reschedule */}
                    <button
                      onClick={() => setRescheduleTarget(task)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/90 hover:bg-indigo-600 text-white text-xs font-bold transition shadow-sm active:scale-95"
                      title="Reschedule Deadline"
                    >
                      <CalendarClock className="w-3.5 h-3.5" />
                      <span>Reschedule</span>
                    </button>

                    {/* 3. Remind Me Later (Snooze) */}
                    <div className="relative">
                      <button
                        onClick={() =>
                          setSnoozeMenuTaskId(snoozeMenuTaskId === task.id ? null : task.id)
                        }
                        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold transition"
                        title="Remind Me Later"
                      >
                        <AlarmClock className="w-3.5 h-3.5 text-amber-400" />
                        <span>Snooze</span>
                      </button>

                      {snoozeMenuTaskId === task.id && (
                        <div className="absolute right-0 bottom-full mb-1.5 w-36 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-1 z-30 animate-in fade-in text-xs space-y-0.5">
                          <button
                            onClick={() => {
                              snoozeTask(task.id, 15);
                              setSnoozeMenuTaskId(null);
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                          >
                            In 15 mins
                          </button>
                          <button
                            onClick={() => {
                              snoozeTask(task.id, 60);
                              setSnoozeMenuTaskId(null);
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                          >
                            In 1 hour
                          </button>
                          <button
                            onClick={() => {
                              snoozeTask(task.id, 180);
                              setSnoozeMenuTaskId(null);
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                          >
                            In 3 hours
                          </button>
                        </div>
                      )}
                    </div>

                    {/* 4. Delete */}
                    <button
                      onClick={() => setDeleteConfirmId(task.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                      title="Delete Task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. INCOMPLETE TASKS OVERVIEW & PENDING BADGE BANNER */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-indigo-500/15 text-indigo-400 shrink-0">
            <BellRing className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm sm:text-base font-bold text-white">
                Pending & Incomplete Tasks Pipeline
              </span>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-600 text-white">
                {pendingTasksCount} Pending
              </span>
              {overdueTasks.length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-600 text-white">
                  {overdueTasks.length} Overdue
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              All open tasks scheduled for today and upcoming deadlines.
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveNavTab('tasks')}
          className="flex items-center gap-1 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition shrink-0"
        >
          <span>Manage Task Queue</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Reschedule Modal */}
      <RescheduleModal
        isOpen={!!rescheduleTarget}
        task={rescheduleTarget}
        onClose={() => setRescheduleTarget(null)}
      />

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Incomplete Task"
        message="Are you sure you want to delete this task? All scheduled reminders and notifications will also be removed."
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteTask(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
