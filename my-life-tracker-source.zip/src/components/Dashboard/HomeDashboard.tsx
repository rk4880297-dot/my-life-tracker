import React from 'react';
import {
  Clock,
  Sparkles,
  CheckCircle2,
  Circle,
  Plus,
  ArrowRight,
  Flame,
  Zap,
  TrendingUp,
  Award,
  Calendar,
  AlertCircle,
  Activity as ActivityIcon,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { CircularProgress } from '../Common/CircularProgress';
import { QuoteBanner } from './QuoteBanner';
import { MetricCards } from './MetricCards';
import { DashboardAlerts } from './DashboardAlerts';
import { getTodayDateString } from '../../services/storage';

interface HomeDashboardProps {
  onOpenAddActivity: () => void;
  onOpenAddHabit: () => void;
  onOpenAddTask: () => void;
  onQuickAddWater: () => void;
  onQuickAddWorkout: () => void;
  onQuickAddSleep: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenAddActivity,
  onOpenAddHabit,
  onOpenAddTask,
  onQuickAddWater,
  onQuickAddWorkout,
  onQuickAddSleep,
}) => {
  const {
    data,
    selectedDate,
    currentTime,
    breakdown,
    streaks,
    suggestions,
    toggleHabit,
    toggleTask,
    setActiveNavTab,
  } = useLifeTracker();

  // Dynamic greeting based on current local hour
  const hour = currentTime.getHours();
  const greeting =
    hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  const todayStr = getTodayDateString();
  const isToday = selectedDate === todayStr;

  const dateObj = new Date(selectedDate + 'T00:00:00');
  const fullDateString = dateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  const clockString = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  // Today's activities
  const dayActivities = data.activities
    .filter((a) => a.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Active habits with their completed status for selected date
  const activeHabits = data.habits.filter((h) => !h.archived);
  const completedHabitIdSet = new Set(
    data.habitLogs
      .filter((l) => l.date === selectedDate && l.completed)
      .map((l) => l.habitId)
  );

  // Today's tasks
  const dayTasks = data.tasks.filter((t) => t.dueDate === selectedDate);

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* 1. Greeting, Live Clock, and Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950/70 via-slate-900/90 to-slate-950 border border-slate-800/90 p-5 sm:p-7 shadow-2xl">
        {/* Glow ambient backgrounds */}
        <div className="absolute top-0 right-1/4 -mt-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 -mb-8 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="text-2xl sm:text-3xl">{data.profile.avatar}</span>
              <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-indigo-400">
                {greeting},
              </span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {data.profile.name}
            </h2>
            <div className="flex flex-wrap items-center gap-2.5 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-1.5 font-medium">
                <Calendar className="w-4 h-4 text-indigo-400" />
                <span>{fullDateString}</span>
              </div>
              <span className="text-slate-600">•</span>
              <div className="flex items-center gap-1.5 font-mono font-semibold text-cyan-300 bg-cyan-950/40 px-2 py-0.5 rounded-md border border-cyan-500/20">
                <Clock className="w-3.5 h-3.5" />
                <span>{clockString}</span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 italic pt-1">
              "{data.profile.mainGoal}"
            </p>
          </div>

          {/* Productivity Gauge Card */}
          <div className="flex items-center gap-5 sm:gap-6 bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4 sm:p-5 shadow-2xl shrink-0 w-full lg:w-auto justify-center sm:justify-start">
            <CircularProgress
              percentage={breakdown.score}
              size={135}
              strokeWidth={12}
              label="Productivity"
              sublabel={`Target: ${data.profile.productivityTargetPercent}%`}
            />

            <div className="space-y-2 text-xs sm:text-sm">
              <div>
                <div className="text-slate-400 font-medium">Daily Productivity</div>
                <div className="text-lg font-bold text-white flex items-center gap-1.5">
                  <span>{breakdown.score}%</span>
                  {breakdown.score >= data.profile.productivityTargetPercent ? (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded-full font-bold">
                      On Target
                    </span>
                  ) : (
                    <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full font-bold">
                      In Progress
                    </span>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-800 pt-2 space-y-1">
                <div className="flex items-center justify-between gap-4 text-slate-300">
                  <span>Tasks:</span>
                  <span className="font-bold text-indigo-400">
                    {breakdown.tasksCompleted}/{breakdown.tasksTotal}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4 text-slate-300">
                  <span>Habits:</span>
                  <span className="font-bold text-emerald-400">
                    {breakdown.habitsCompleted}/{breakdown.habitsTotal}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4 text-slate-300">
                  <span>Productive:</span>
                  <span className="font-bold text-cyan-400">
                    {(breakdown.productiveMinutes / 60).toFixed(1)} hrs
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SMART TASK REMINDERS & OVERDUE DASHBOARD ALERTS */}
      <DashboardAlerts />

      {/* 2. Motivational Quote Banner */}
      <QuoteBanner />

      {/* 3. Metric Cards Grid */}
      <MetricCards
        onQuickAddWater={onQuickAddWater}
        onQuickAddWorkout={onQuickAddWorkout}
        onQuickAddSleep={onQuickAddSleep}
        onOpenGoals={() => setActiveNavTab('goals')}
        onOpenTasks={() => setActiveNavTab('tasks')}
        onOpenHabits={() => setActiveNavTab('habits')}
      />

      {/* 4. Quick Action & Daily Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Habits Checklist */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-white text-base">Habits Checklist</h3>
            </div>
            <button
              onClick={() => setActiveNavTab('habits')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {activeHabits.length === 0 ? (
              <div className="text-center py-6 text-sm text-slate-500">
                No active habits. Create your first habit!
              </div>
            ) : (
              activeHabits.slice(0, 6).map((habit) => {
                const isCompleted = completedHabitIdSet.has(habit.id);
                return (
                  <div
                    key={habit.id}
                    onClick={() => toggleHabit(habit.id)}
                    className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                      isCompleted
                        ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-100'
                        : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{habit.icon}</span>
                      <div>
                        <div className={`text-sm font-semibold ${isCompleted ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                          {habit.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Target: {habit.dailyTarget}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      className={`p-1 rounded-full transition ${
                        isCompleted ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 fill-emerald-500/20" />
                      ) : (
                        <Circle className="w-6 h-6" />
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>

          <button
            onClick={onOpenAddHabit}
            className="w-full py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-indigo-500 text-xs font-semibold text-slate-300 hover:text-indigo-300 flex items-center justify-center gap-1.5 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Create Custom Habit</span>
          </button>
        </div>

        {/* Middle Column: Today's Tasks */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-white text-base">Today's Priority Tasks</h3>
            </div>
            <button
              onClick={() => setActiveNavTab('tasks')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <span>View Tasks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {dayTasks.length === 0 ? (
              <div className="text-center py-6 text-sm text-slate-500">
                No tasks due for this date.
              </div>
            ) : (
              dayTasks.slice(0, 5).map((task) => (
                <div
                  key={task.id}
                  onClick={() => toggleTask(task.id)}
                  className={`flex items-start justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                    task.completed
                      ? 'bg-slate-950/40 border-slate-800 text-slate-400'
                      : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 text-slate-200'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <button
                      type="button"
                      className={`p-0.5 mt-0.5 rounded-md transition ${
                        task.completed ? 'text-indigo-400' : 'text-slate-500'
                      }`}
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-5 h-5 fill-indigo-500/20" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>
                    <div>
                      <div className={`text-sm font-semibold leading-snug ${task.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                        {task.title}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                            task.priority === 'high'
                              ? 'bg-rose-500/20 text-rose-300'
                              : task.priority === 'medium'
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {task.priority}
                        </span>
                        {task.dueTime && (
                          <span className="text-[11px] text-slate-400 font-mono">
                            {task.dueTime}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={onOpenAddTask}
            className="w-full py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-indigo-500 text-xs font-semibold text-slate-300 hover:text-indigo-300 flex items-center justify-center gap-1.5 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Task</span>
          </button>
        </div>

        {/* Right Column: Timeline Preview & Suggestions */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ActivityIcon className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Timeline Highlights</h3>
              </div>
              <button
                onClick={() => setActiveNavTab('daily')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <span>Full Timeline</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {dayActivities.length === 0 ? (
              <div className="text-center py-6 text-sm text-slate-500">
                No activities logged yet today.
              </div>
            ) : (
              <div className="mt-3 space-y-2.5">
                {dayActivities.slice(0, 4).map((act) => (
                  <div
                    key={act.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80 text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-200">{act.name}</div>
                      <div className="text-slate-400 text-[11px] font-mono">
                        {act.startTime} - {act.endTime} ({act.durationMinutes}m)
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        act.productivityRating === 'productive'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : act.productivityRating === 'unproductive'
                          ? 'bg-rose-500/20 text-rose-300'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {act.productivityRating}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Smart Suggestions card */}
          <div className="mt-4 p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/20 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Smart Productivity Insight</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {suggestions[0] || 'Keep recording your daily activities to reveal peak performance hours!'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
