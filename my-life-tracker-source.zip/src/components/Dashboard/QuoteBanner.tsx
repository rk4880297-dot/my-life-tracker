import React from 'react';
import { Quote, Flame, Sparkles } from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';

export const QuoteBanner: React.FC = () => {
  const { quote, streaks } = useLifeTracker();

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-950/40 via-purple-950/30 to-slate-900 border border-indigo-500/20 p-4 sm:p-5 shadow-xl">
      <div className="absolute top-0 right-0 -mt-6 -mr-6 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 shrink-0 mt-0.5">
            <Quote className="w-5 h-5" />
          </div>
          <div>
            <p className="text-sm sm:text-base font-medium text-slate-100 italic leading-relaxed">
              "{quote.text}"
            </p>
            <p className="text-xs font-semibold text-indigo-300 mt-1">
              — {quote.author}
            </p>
          </div>
        </div>

        {/* Current streak badge */}
        <div className="flex items-center gap-2.5 bg-slate-900/80 border border-amber-500/30 px-3.5 py-2 rounded-xl shrink-0 self-end sm:self-center shadow-lg">
          <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
            <Flame className="w-5 h-5 fill-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Active Streak</div>
            <div className="text-sm font-bold text-amber-300 flex items-center gap-1">
              <span>{streaks.currentStreak} Days</span>
              <span className="text-[10px] text-slate-400 font-normal">(Max: {streaks.longestStreak})</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
