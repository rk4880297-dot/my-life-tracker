import React from 'react';
import {
  CheckSquare,
  Sparkles,
  Droplets,
  Dumbbell,
  BookOpen,
  Moon,
  Target,
  TrendingUp,
  Plus,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';

interface MetricCardsProps {
  onQuickAddWater: () => void;
  onQuickAddWorkout: () => void;
  onQuickAddSleep: () => void;
  onOpenGoals: () => void;
  onOpenTasks: () => void;
  onOpenHabits: () => void;
}

export const MetricCards: React.FC<MetricCardsProps> = ({
  onQuickAddWater,
  onQuickAddWorkout,
  onQuickAddSleep,
  onOpenGoals,
  onOpenTasks,
  onOpenHabits,
}) => {
  const { data, breakdown } = useLifeTracker();

  const waterTarget = data.profile.waterTargetMl || 3000;
  const waterPct = Math.min(100, Math.round((breakdown.waterIntakeMl / waterTarget) * 100));

  const sleepTarget = data.profile.sleepTargetHours || 8;
  const sleepPct = Math.min(100, Math.round((breakdown.sleepHours / sleepTarget) * 100));

  const studyTarget = data.profile.studyTargetMinutes || 90;
  const studyPct = Math.min(100, Math.round((breakdown.studyMinutes / studyTarget) * 100));

  const exerciseTarget = data.profile.exerciseTargetMinutes || 45;
  const exercisePct = Math.min(100, Math.round((breakdown.exerciseMinutes / exerciseTarget) * 100));

  const activeGoals = data.goals.filter((g) => g.status === 'active');
  const avgGoalProgress = activeGoals.length > 0
    ? Math.round(
        activeGoals.reduce((acc, curr) => acc + (curr.currentProgress / (curr.targetValue || 1)) * 100, 0) /
          activeGoals.length
      )
    : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
      {/* 1. Daily Completed Tasks */}
      <div
        onClick={onOpenTasks}
        className="cursor-pointer group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-indigo-500/10"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Tasks</span>
          <div className="p-2 rounded-xl bg-indigo-500/15 text-indigo-400 group-hover:scale-110 transition-transform">
            <CheckSquare className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-xl sm:text-2xl font-extrabold text-white">
            {breakdown.tasksCompleted}
            <span className="text-sm font-semibold text-slate-400">/{breakdown.tasksTotal}</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-indigo-500 h-full rounded-full transition-all duration-500"
              style={{
                width: `${breakdown.tasksTotal > 0 ? (breakdown.tasksCompleted / breakdown.tasksTotal) * 100 : 0}%`,
              }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Progress</span>
            <span className="text-indigo-300 font-bold">
              {breakdown.tasksTotal > 0 ? Math.round((breakdown.tasksCompleted / breakdown.tasksTotal) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* 2. Habits Completed */}
      <div
        onClick={onOpenHabits}
        className="cursor-pointer group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-emerald-500/10"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Habits</span>
          <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400 group-hover:scale-110 transition-transform">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-xl sm:text-2xl font-extrabold text-white">
            {breakdown.habitsCompleted}
            <span className="text-sm font-semibold text-slate-400">/{breakdown.habitsTotal}</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{
                width: `${breakdown.habitsTotal > 0 ? (breakdown.habitsCompleted / breakdown.habitsTotal) * 100 : 0}%`,
              }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Completed</span>
            <span className="text-emerald-300 font-bold">
              {breakdown.habitsTotal > 0 ? Math.round((breakdown.habitsCompleted / breakdown.habitsTotal) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* 3. Water Intake */}
      <div
        onClick={onQuickAddWater}
        className="cursor-pointer group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-cyan-500/10"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Water</span>
          <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400 group-hover:scale-110 transition-transform">
            <Droplets className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
            {(breakdown.waterIntakeMl / 1000).toFixed(1)}L
            <span className="text-xs font-semibold text-slate-400 ml-1">/ {(waterTarget / 1000).toFixed(1)}L</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-cyan-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${waterPct}%` }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Hydration</span>
            <span className="text-cyan-300 font-bold">{waterPct}%</span>
          </div>
        </div>
      </div>

      {/* 4. Exercise Duration */}
      <div
        onClick={onQuickAddWorkout}
        className="cursor-pointer group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-amber-500/10"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Exercise</span>
          <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 group-hover:scale-110 transition-transform">
            <Dumbbell className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-lg sm:text-xl font-extrabold text-white">
            {breakdown.exerciseMinutes}
            <span className="text-xs font-semibold text-slate-400 ml-1">min</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${exercisePct}%` }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Goal: {exerciseTarget}m</span>
            <span className="text-amber-300 font-bold">{exercisePct}%</span>
          </div>
        </div>
      </div>

      {/* 5. Study Duration */}
      <div className="group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-purple-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-purple-500/10">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Study / Focus</span>
          <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400 group-hover:scale-110 transition-transform">
            <BookOpen className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-lg sm:text-xl font-extrabold text-white">
            {breakdown.studyMinutes}
            <span className="text-xs font-semibold text-slate-400 ml-1">min</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-purple-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${studyPct}%` }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Goal: {studyTarget}m</span>
            <span className="text-purple-300 font-bold">{studyPct}%</span>
          </div>
        </div>
      </div>

      {/* 6. Sleep Duration */}
      <div
        onClick={onQuickAddSleep}
        className="cursor-pointer group relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-blue-500/40 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/10"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Sleep</span>
          <div className="p-2 rounded-xl bg-blue-500/15 text-blue-400 group-hover:scale-110 transition-transform">
            <Moon className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2.5">
          <div className="text-lg sm:text-xl font-extrabold text-white">
            {breakdown.sleepHours}
            <span className="text-xs font-semibold text-slate-400 ml-1">hrs</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-blue-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${sleepPct}%` }}
            />
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Target: {sleepTarget}h</span>
            <span className="text-blue-300 font-bold">{sleepPct}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
