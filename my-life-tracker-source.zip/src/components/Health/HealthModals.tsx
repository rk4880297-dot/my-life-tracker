import React, { useState } from 'react';
import { X, Droplets, Dumbbell, Moon, Scale } from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { getTodayDateString } from '../../services/storage';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// 1. Water Intake Modal
export const WaterModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const { addWaterLog, selectedDate } = useLifeTracker();
  const [amount, setAmount] = useState(250);

  if (!isOpen) return null;

  const handleQuickAdd = (ml: number) => {
    addWaterLog(ml, selectedDate);
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount > 0) {
      addWaterLog(amount, selectedDate);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-base">
            <Droplets className="w-5 h-5" />
            <span>Add Water Intake</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-4">
          <div className="grid grid-cols-3 gap-2">
            {[250, 500, 750].map((ml) => (
              <button
                key={ml}
                onClick={() => handleQuickAdd(ml)}
                className="py-3 rounded-2xl bg-slate-950 border border-cyan-500/30 hover:bg-cyan-950/30 text-cyan-300 font-extrabold text-sm transition"
              >
                +{ml} ml
              </button>
            ))}
          </div>

          <form onSubmit={handleCustomSubmit} className="space-y-3 pt-2">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Custom Amount (ml)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="50"
                step="50"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold transition shadow-md"
              >
                Log
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// 2. Workout Modal
export const WorkoutModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const { addWorkoutLog, selectedDate } = useLifeTracker();

  const [name, setName] = useState('');
  const [category, setCategory] = useState('Cardio');
  const [duration, setDuration] = useState(30);
  const [calories, setCalories] = useState<number | ''>(250);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addWorkoutLog({
      exerciseName: name.trim(),
      category,
      durationMinutes: duration,
      caloriesBurned: calories === '' ? undefined : Number(calories),
      date: selectedDate,
      notes: notes.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
            <Dumbbell className="w-5 h-5" />
            <span>Record Workout</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Exercise Name *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. 5km Morning Run, Bench Press"
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
              autoFocus
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none"
              >
                <option value="Cardio">Cardio</option>
                <option value="Strength">Strength</option>
                <option value="HIIT">HIIT</option>
                <option value="Yoga / Mobility">Yoga</option>
                <option value="Sports">Sports</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Duration (Min)</label>
              <input
                type="number"
                min="1"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Calories (Optional)</label>
              <input
                type="number"
                min="0"
                value={calories}
                onChange={(e) => setCalories(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="kcal"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Notes (Optional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Reps, weight, heart rate or feeling..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 shadow-md"
            >
              Save Workout
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 3. Sleep Log Modal
export const SleepModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const { saveSleepLog, selectedDate } = useLifeTracker();

  const [bedtime, setBedtime] = useState('23:00');
  const [wakeTime, setWakeTime] = useState('07:00');
  const [durationHours, setDurationHours] = useState(8);
  const [quality, setQuality] = useState<'great' | 'good' | 'fair' | 'poor'>('great');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleTimeRecalc = (bed: string, wake: string) => {
    setBedtime(bed);
    setWakeTime(wake);

    const [bh, bm] = bed.split(':').map(Number);
    const [wh, wm] = wake.split(':').map(Number);

    let bedMins = bh * 60 + bm;
    let wakeMins = wh * 60 + wm;

    if (wakeMins < bedMins) {
      wakeMins += 24 * 60; // Next morning
    }

    const diffHrs = Number(((wakeMins - bedMins) / 60).toFixed(2));
    if (diffHrs > 0 && diffHrs <= 24) {
      setDurationHours(diffHrs);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveSleepLog({
      date: selectedDate,
      bedtime,
      wakeTime,
      durationHours,
      quality,
      notes: notes.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-blue-400 font-bold text-base">
            <Moon className="w-5 h-5" />
            <span>Record Sleep Duration</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Bedtime</label>
              <input
                type="time"
                value={bedtime}
                onChange={(e) => handleTimeRecalc(e.target.value, wakeTime)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Wake Time</label>
              <input
                type="time"
                value={wakeTime}
                onChange={(e) => handleTimeRecalc(bedtime, e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Duration (Hrs)</label>
              <input
                type="number"
                step="0.25"
                min="1"
                max="24"
                value={durationHours}
                onChange={(e) => setDurationHours(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Sleep Quality</label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'great', label: '🌟 Great' },
                { id: 'good', label: '✨ Good' },
                { id: 'fair', label: '😐 Fair' },
                { id: 'poor', label: '🥱 Poor' },
              ].map((q) => (
                <button
                  type="button"
                  key={q.id}
                  onClick={() => setQuality(q.id as any)}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    quality === q.id
                      ? 'bg-blue-600 text-white border-blue-500 shadow'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Slept uninterrupted, woke up refreshed"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-md"
            >
              Save Sleep Log
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 4. Weight Tracker Modal
export const WeightModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const { addWeightLog, selectedDate, data } = useLifeTracker();

  const lastLog = data.weightLogs[data.weightLogs.length - 1];
  const [weight, setWeight] = useState(lastLog ? lastLog.weight : 70);
  const [unit, setUnit] = useState<'kg' | 'lbs'>(lastLog ? lastLog.unit : 'kg');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (weight > 0) {
      addWeightLog({
        weight,
        unit,
        date: selectedDate,
        notes: notes.trim(),
      });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-base">
            <Scale className="w-5 h-5" />
            <span>Log Body Weight</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div className="flex items-center gap-2">
            <input
              type="number"
              step="0.1"
              min="20"
              max="300"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
              autoFocus
            />
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value as 'kg' | 'lbs')}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
            >
              <option value="kg">kg</option>
              <option value="lbs">lbs</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Notes (Optional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Weighed morning fasted"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-500 shadow-md"
            >
              Save Weight
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
