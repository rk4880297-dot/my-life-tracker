import React, { useState } from 'react';
import {
  Droplets,
  Dumbbell,
  Moon,
  Scale,
  Plus,
  Trash2,
  TrendingUp,
  Clock,
  Sparkles,
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { WaterModal, WorkoutModal, SleepModal, WeightModal } from './HealthModals';
import { ConfirmModal } from '../Common/ConfirmModal';

export const HealthTracker: React.FC = () => {
  const {
    data,
    selectedDate,
    breakdown,
    deleteWorkoutLog,
    deleteWeightLog,
  } = useLifeTracker();

  const [activeModal, setActiveModal] = useState<'water' | 'workout' | 'sleep' | 'weight' | null>(null);
  const [deleteWorkoutId, setDeleteWorkoutId] = useState<string | null>(null);
  const [deleteWeightId, setDeleteWeightId] = useState<string | null>(null);

  // Water metrics
  const waterTarget = data.profile.waterTargetMl || 3000;
  const waterIntake = breakdown.waterIntakeMl;
  const waterRemaining = Math.max(0, waterTarget - waterIntake);
  const waterPct = Math.min(100, Math.round((waterIntake / waterTarget) * 100));

  // Today's workouts & history
  const todayWorkouts = data.workoutLogs.filter((w) => w.date === selectedDate);
  const sortedWorkouts = [...data.workoutLogs].sort((a, b) => b.date.localeCompare(a.date));

  // Sleep history
  const sortedSleep = [...data.sleepLogs].sort((a, b) => b.date.localeCompare(a.date));
  const todaySleep = data.sleepLogs.find((s) => s.date === selectedDate);

  // Weight history
  const sortedWeight = [...data.weightLogs].sort((a, b) => a.date.localeCompare(b.date));
  const currentWeightLog = sortedWeight[sortedWeight.length - 1];
  const previousWeightLog = sortedWeight[sortedWeight.length - 2];

  const weightChartData = sortedWeight.map((w) => ({
    date: w.date.slice(5),
    weight: w.weight,
    unit: w.unit,
  }));

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <span>Health & Fitness Vitality Hub</span>
          <span className="text-xs bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold px-2.5 py-0.5 rounded-full">
            {selectedDate}
          </span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Monitor your hydration, workouts, restorative sleep, and weight progress.
        </p>
      </div>

      {/* 4 Health Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. Water Tracker */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-base">
              <Droplets className="w-5 h-5" />
              <span>Hydration Tracker</span>
            </div>
            <button
              onClick={() => setActiveModal('water')}
              className="px-3 py-1.5 bg-cyan-600/90 hover:bg-cyan-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Water</span>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-extrabold text-white tracking-tight">
                {waterIntake} <span className="text-sm font-normal text-slate-400">/ {waterTarget} ml</span>
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {waterRemaining > 0 ? `${waterRemaining} ml remaining to hit goal` : '🎉 Goal achieved for today!'}
              </div>
            </div>

            <div className="text-right">
              <span className="text-2xl font-extrabold text-cyan-400">{waterPct}%</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${waterPct}%` }}
            />
          </div>

          {/* Quick Add buttons */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              onClick={() => setActiveModal('water')}
              className="py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-300 text-xs font-bold transition"
            >
              +250 ml
            </button>
            <button
              onClick={() => setActiveModal('water')}
              className="py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-300 text-xs font-bold transition"
            >
              +500 ml
            </button>
            <button
              onClick={() => setActiveModal('water')}
              className="py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-300 text-xs font-bold transition"
            >
              +750 ml
            </button>
          </div>
        </div>

        {/* 2. Sleep Tracker */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-blue-400 font-bold text-base">
              <Moon className="w-5 h-5" />
              <span>Sleep & Recovery</span>
            </div>
            <button
              onClick={() => setActiveModal('sleep')}
              className="px-3 py-1.5 bg-blue-600/90 hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Sleep</span>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-extrabold text-white tracking-tight">
                {todaySleep ? todaySleep.durationHours : breakdown.sleepHours}{' '}
                <span className="text-sm font-normal text-slate-400">hrs</span>
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Target: {data.profile.sleepTargetHours || 8} hours per night
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                {todaySleep ? todaySleep.quality : 'Good'} Quality
              </span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs text-slate-300 font-mono">
            <div>
              <span className="text-slate-500">Bedtime: </span>
              {todaySleep ? todaySleep.bedtime : '23:00'}
            </div>
            <div>
              <span className="text-slate-500">Wake: </span>
              {todaySleep ? todaySleep.wakeTime : '07:00'}
            </div>
          </div>
        </div>

        {/* 3. Workout Tracker */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Dumbbell className="w-5 h-5" />
              <span>Workout & Exercise Log</span>
            </div>
            <button
              onClick={() => setActiveModal('workout')}
              className="px-3 py-1.5 bg-amber-600/90 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Workout</span>
            </button>
          </div>

          <div className="space-y-2.5 max-h-56 overflow-y-auto">
            {todayWorkouts.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500">
                No workouts logged for this date.
              </div>
            ) : (
              todayWorkouts.map((wo) => (
                <div
                  key={wo.id}
                  className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-white text-sm">{wo.exerciseName}</div>
                    <div className="text-slate-400 text-[11px] mt-0.5">
                      {wo.category} • {wo.durationMinutes} mins
                      {wo.caloriesBurned ? ` • ${wo.caloriesBurned} kcal` : ''}
                    </div>
                  </div>
                  <button
                    onClick={() => setDeleteWorkoutId(wo.id)}
                    className="p-1 text-slate-400 hover:text-rose-400 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* 4. Weight Tracker */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-purple-400 font-bold text-base">
              <Scale className="w-5 h-5" />
              <span>Weight Progress</span>
            </div>
            <button
              onClick={() => setActiveModal('weight')}
              className="px-3 py-1.5 bg-purple-600/90 hover:bg-purple-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Weight</span>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-extrabold text-white tracking-tight">
                {currentWeightLog ? `${currentWeightLog.weight} ${currentWeightLog.unit}` : '72 kg'}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {previousWeightLog
                  ? `Previous: ${previousWeightLog.weight} ${previousWeightLog.unit} (${(
                      currentWeightLog.weight - previousWeightLog.weight
                    ).toFixed(1)} change)`
                  : 'Starting baseline recorded'}
              </div>
            </div>
          </div>

          {/* Weight progress chart */}
          {weightChartData.length > 0 && (
            <div className="h-36 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightChartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                  <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={10} domain={['dataMin - 1', 'dataMax + 1']} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontSize: '11px',
                    }}
                  />
                  <Line type="monotone" dataKey="weight" stroke="#a855f7" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <WaterModal isOpen={activeModal === 'water'} onClose={() => setActiveModal(null)} />
      <WorkoutModal isOpen={activeModal === 'workout'} onClose={() => setActiveModal(null)} />
      <SleepModal isOpen={activeModal === 'sleep'} onClose={() => setActiveModal(null)} />
      <WeightModal isOpen={activeModal === 'weight'} onClose={() => setActiveModal(null)} />

      {/* Deletion confirmations */}
      <ConfirmModal
        isOpen={!!deleteWorkoutId}
        title="Delete Workout"
        message="Are you sure you want to delete this workout entry?"
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteWorkoutId) {
            deleteWorkoutLog(deleteWorkoutId);
            setDeleteWorkoutId(null);
          }
        }}
        onCancel={() => setDeleteWorkoutId(null)}
      />
    </div>
  );
};
