import React, { useState } from 'react';
import {
  Plus,
  Sparkles,
  CheckCircle2,
  Circle,
  Flame,
  Calendar,
  Award,
  Trash2,
  Edit2,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  AlertCircle,
  Check,
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { Habit } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { HabitModal } from './HabitModal';
import { ConfirmModal } from '../Common/ConfirmModal';
import { calculateHabitStreaks } from '../../services/analytics';
import { getTodayDateString } from '../../services/storage';

export const HabitTracker: React.FC = () => {
  const { data, selectedDate, toggleHabit, deleteHabit } = useLifeTracker();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'checklist' | 'weekly' | 'monthly'>('checklist');

  const activeHabits = data.habits.filter((h) => !h.archived);

  // Generate current week dates (Mon to Sun) based on selected date
  const selDate = new Date(selectedDate + 'T00:00:00');
  const dayOfWeek = (selDate.getDay() + 6) % 7; // Monday = 0
  const monday = new Date(selDate);
  monday.setDate(monday.getDate() - dayOfWeek);

  const weekDays = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(monday);
    d.setDate(d.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${day}`;
    return {
      dateStr,
      dayName: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
      dayNum: d.getDate(),
      isCurrentDay: dateStr === getTodayDateString(),
    };
  });

  // Calculate habit completion set for selectedDate
  const completedTodaySet = new Set(
    data.habitLogs
      .filter((l) => l.date === selectedDate && l.completed)
      .map((l) => l.habitId)
  );

  // Performance chart data (last 7 days completion rate)
  const chartData = weekDays.map((wd) => {
    const completedCount = data.habitLogs.filter(
      (l) => l.date === wd.dateStr && l.completed
    ).length;
    const total = activeHabits.length || 1;
    return {
      day: wd.dayName,
      completed: completedCount,
      percentage: Math.round((completedCount / total) * 100),
    };
  });

  // Overall metrics
  const totalHabitsCompletedToday = completedTodaySet.size;
  const totalActive = activeHabits.length;
  const overallPercentage = totalActive > 0 ? Math.round((totalHabitsCompletedToday / totalActive) * 100) : 0;
  const missedCount = Math.max(0, totalActive - totalHabitsCompletedToday);

  // Find most consistent habit
  let topHabit: Habit | null = null;
  let maxStreak = -1;
  activeHabits.forEach((h) => {
    const { currentStreak } = calculateHabitStreaks(h.id, data.habitLogs);
    if (currentStreak > maxStreak) {
      maxStreak = currentStreak;
      topHabit = h;
    }
  });

  const handleEdit = (habit: Habit) => {
    setEditingHabit(habit);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingHabit(null);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Habit Consistency Hub</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {totalHabitsCompletedToday}/{totalActive} Done
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Build unbreakable identity-based habits through consistent daily repetition.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* View Mode Toggle */}
          <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-xl">
            <button
              onClick={() => setViewMode('checklist')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                viewMode === 'checklist' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Checklist
            </button>
            <button
              onClick={() => setViewMode('weekly')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                viewMode === 'weekly' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Weekly Grid
            </button>
          </div>

          <button
            onClick={handleAdd}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white text-xs sm:text-sm font-bold px-3.5 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden xs:inline">Add Habit</span>
          </button>
        </div>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Today's Completion
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {overallPercentage}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {totalHabitsCompletedToday} of {totalActive} habits checked
          </div>
        </div>

        <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-4">
          <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span>Top Habit Streak</span>
          </div>
          <div className="text-2xl font-extrabold text-amber-300 mt-1">
            {maxStreak > 0 ? `${maxStreak} Days` : '0 Days'}
          </div>
          <div className="text-[11px] text-amber-200/80 mt-1 truncate">
            {topHabit ? (topHabit as Habit).name : 'Start a habit'}
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Missed / Remaining
          </div>
          <div className="text-2xl font-extrabold text-slate-200 mt-1">
            {missedCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {missedCount === 0 ? 'All habits finished!' : 'Pending for today'}
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-950/20 border border-indigo-500/30 p-4">
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
            Total Active Habits
          </div>
          <div className="text-2xl font-extrabold text-indigo-300 mt-1">
            {totalActive}
          </div>
          <div className="text-[11px] text-indigo-200/80 mt-1">
            Custom routines tracked
          </div>
        </div>
      </div>

      {/* Main View: Checklist or Weekly Matrix */}
      {viewMode === 'checklist' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Checklist */}
          <div className="lg:col-span-2 space-y-3">
            {activeHabits.length === 0 ? (
              <div className="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-10 text-center space-y-3">
                <Sparkles className="w-10 h-10 text-slate-600 mx-auto" />
                <div className="text-slate-300 font-semibold text-sm">
                  No habits added yet.
                </div>
                <button
                  onClick={handleAdd}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition"
                >
                  Create Habit
                </button>
              </div>
            ) : (
              activeHabits.map((habit) => {
                const isCompleted = completedTodaySet.has(habit.id);
                const { currentStreak, longestStreak, completionRate } = calculateHabitStreaks(
                  habit.id,
                  data.habitLogs
                );

                return (
                  <div
                    key={habit.id}
                    className={`group relative rounded-2xl border transition-all p-4 ${
                      isCompleted
                        ? 'bg-emerald-950/15 border-emerald-500/40'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      {/* Checkbox & Details */}
                      <div className="flex items-center gap-3.5 flex-1 min-w-0">
                        <button
                          type="button"
                          onClick={() => toggleHabit(habit.id)}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-transform active:scale-90 ${
                            isCompleted
                              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                              : 'bg-slate-950 border border-slate-800 text-slate-500 hover:border-emerald-500 hover:text-emerald-400'
                          }`}
                        >
                          {isCompleted ? <Check className="w-5 h-5 stroke-[3]" /> : <Circle className="w-5 h-5" />}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{habit.icon}</span>
                            <span
                              className={`text-sm sm:text-base font-bold truncate ${
                                isCompleted ? 'line-through text-slate-400' : 'text-white'
                              }`}
                            >
                              {habit.name}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-400">
                            <span className="px-2 py-0.5 rounded bg-slate-950 text-[10px] font-semibold border border-slate-800">
                              {habit.category}
                            </span>
                            <span>• Target: {habit.dailyTarget}</span>
                            {habit.reminderTime && <span>• ⏰ {habit.reminderTime}</span>}
                          </div>
                        </div>
                      </div>

                      {/* Right streak info & actions */}
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="hidden sm:flex flex-col items-end">
                          <div className="flex items-center gap-1 text-amber-400 font-bold text-xs">
                            <Flame className="w-3.5 h-3.5 fill-amber-400" />
                            <span>{currentStreak}d streak</span>
                          </div>
                          <span className="text-[10px] text-slate-500 font-medium">
                            Max: {longestStreak}d
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleEdit(habit)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            title="Edit Habit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(habit.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                            title="Delete Habit"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Habit Weekly Performance Chart */}
          <div className="lg:col-span-1 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Weekly Completion %</span>
            </h3>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="day" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                    formatter={(val: any) => [`${val}%`, 'Completed Rate']}
                  />
                  <Bar dataKey="percentage" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300">
              <span className="font-semibold text-emerald-400">Pro Tip: </span>
              Completing habits in the first 2 hours of waking increases consistency by over 40%!
            </div>
          </div>
        </div>
      ) : (
        /* Weekly Grid View */
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl overflow-x-auto">
          <div className="min-w-[650px]">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="pb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                    Habit Name
                  </th>
                  {weekDays.map((wd) => (
                    <th key={wd.dateStr} className="pb-3 text-center">
                      <div className={`text-xs font-bold ${wd.isCurrentDay ? 'text-indigo-400' : 'text-slate-400'}`}>
                        {wd.dayName}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">{wd.dayNum}</div>
                    </th>
                  ))}
                  <th className="pb-3 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                    Rate
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {activeHabits.map((habit) => {
                  let weekCompleted = 0;
                  return (
                    <tr key={habit.id} className="hover:bg-slate-950/40 transition">
                      <td className="py-3 pr-4 font-semibold text-white flex items-center gap-2">
                        <span>{habit.icon}</span>
                        <span className="truncate max-w-[200px]">{habit.name}</span>
                      </td>

                      {weekDays.map((wd) => {
                        const isDone = data.habitLogs.some(
                          (l) => l.habitId === habit.id && l.date === wd.dateStr && l.completed
                        );
                        if (isDone) weekCompleted++;

                        return (
                          <td key={wd.dateStr} className="py-3 text-center">
                            <button
                              type="button"
                              onClick={() => toggleHabit(habit.id, wd.dateStr)}
                              className={`w-7 h-7 rounded-lg inline-flex items-center justify-center transition ${
                                isDone
                                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                                  : 'bg-slate-950 border border-slate-800 text-slate-600 hover:border-slate-700'
                              }`}
                            >
                              {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : '·'}
                            </button>
                          </td>
                        );
                      })}

                      <td className="py-3 text-right font-mono font-bold text-slate-300">
                        {Math.round((weekCompleted / 7) * 100)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Habit Add/Edit Modal */}
      <HabitModal
        isOpen={isModalOpen}
        habitToEdit={editingHabit}
        onClose={() => setIsModalOpen(false)}
      />

      {/* Confirm Deletion */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Habit"
        message="Are you sure you want to delete this habit and all its logged history? This cannot be undone."
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteHabit(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
