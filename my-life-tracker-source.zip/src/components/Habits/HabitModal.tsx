import React, { useState, useEffect } from 'react';
import { X, Sparkles } from 'lucide-react';
import { Habit, HabitFrequency } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { getTodayDateString } from '../../services/storage';

interface HabitModalProps {
  isOpen: boolean;
  habitToEdit?: Habit | null;
  onClose: () => void;
}

const COMMON_ICONS = ['🧘', '💧', '📚', '⚡', '📵', '✍️', '🌙', '🏃', '🥗', '🎯', '💪', '🧠', '🌿', '⏰', '🚴'];

export const HabitModal: React.FC<HabitModalProps> = ({
  isOpen,
  habitToEdit,
  onClose,
}) => {
  const { addHabit, updateHabit } = useLifeTracker();

  const [name, setName] = useState('');
  const [icon, setIcon] = useState('🧘');
  const [category, setCategory] = useState('Health');
  const [dailyTarget, setDailyTarget] = useState('15 mins');
  const [reminderTime, setReminderTime] = useState('08:00');
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [startDate, setStartDate] = useState(getTodayDateString());
  const [error, setError] = useState('');

  useEffect(() => {
    if (habitToEdit) {
      setName(habitToEdit.name);
      setIcon(habitToEdit.icon);
      setCategory(habitToEdit.category);
      setDailyTarget(habitToEdit.dailyTarget);
      setReminderTime(habitToEdit.reminderTime || '08:00');
      setFrequency(habitToEdit.frequency);
      setStartDate(habitToEdit.startDate);
    } else {
      setName('');
      setIcon('🧘');
      setCategory('Health');
      setDailyTarget('1 time');
      setReminderTime('08:00');
      setFrequency('daily');
      setStartDate(getTodayDateString());
    }
    setError('');
  }, [habitToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a habit name');
      return;
    }

    if (habitToEdit) {
      updateHabit({
        ...habitToEdit,
        name: name.trim(),
        icon,
        category,
        dailyTarget: dailyTarget.trim() || '1 time',
        reminderTime,
        frequency,
        startDate,
      });
    } else {
      addHabit({
        name: name.trim(),
        icon,
        category,
        dailyTarget: dailyTarget.trim() || '1 time',
        reminderTime,
        frequency,
        startDate,
      });
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/80 bg-slate-950/40">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">
              {habitToEdit ? 'Edit Habit' : 'Create Custom Habit'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Habit Name */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Habit Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Read 20 Pages Daily"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition"
              autoFocus
            />
          </div>

          {/* Icon Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Select Icon
            </label>
            <div className="flex items-center gap-2 overflow-x-auto p-1.5 bg-slate-950 rounded-xl border border-slate-800 no-scrollbar">
              {COMMON_ICONS.map((emoji) => (
                <button
                  type="button"
                  key={emoji}
                  onClick={() => setIcon(emoji)}
                  className={`w-9 h-9 text-lg rounded-lg flex items-center justify-center shrink-0 transition ${
                    icon === emoji
                      ? 'bg-indigo-600 scale-110 shadow-md'
                      : 'hover:bg-slate-800'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Category & Daily Target */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="Health">Health</option>
                <option value="Personal Development">Personal Development</option>
                <option value="Study">Study</option>
                <option value="Exercise">Exercise</option>
                <option value="Business">Business</option>
                <option value="Family">Family</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Daily Target</label>
              <input
                type="text"
                value={dailyTarget}
                onChange={(e) => setDailyTarget(e.target.value)}
                placeholder="e.g. 30 mins, 3L"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Reminder Time & Frequency */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Reminder Time</label>
              <input
                type="time"
                value={reminderTime}
                onChange={(e) => setReminderTime(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Frequency</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as HabitFrequency)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="daily">Daily (7 days)</option>
                <option value="weekdays">Weekdays (Mon-Fri)</option>
                <option value="weekends">Weekends only</option>
              </select>
            </div>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
            />
          </div>

          {/* Submit */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 shadow-lg shadow-emerald-600/30 transition"
            >
              {habitToEdit ? 'Save Changes' : 'Create Habit'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
