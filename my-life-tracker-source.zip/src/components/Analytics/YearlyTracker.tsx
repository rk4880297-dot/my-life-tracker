import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Award,
  Flame,
  Copy,
  Trophy,
  Zap,
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { calculateDayProductivity } from '../../services/analytics';

const MONTH_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export const YearlyTracker: React.FC = () => {
  const { data, streaks, setSelectedDate, addToast } = useLifeTracker();

  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);

  // Generate 12 months aggregates for this year
  const monthData = MONTH_NAMES.map((mName, mIdx) => {
    const daysInMonth = new Date(selectedYear, mIdx + 1, 0).getDate();
    let monthProductiveMins = 0;
    let scores: number[] = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${selectedYear}-${String(mIdx + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const bd = calculateDayProductivity(dateStr, data);
      monthProductiveMins += bd.productiveMinutes;
      scores.push(bd.score);
    }

    const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
    return {
      name: mName,
      monthIndex: mIdx,
      score: avgScore,
      productiveHours: (monthProductiveMins / 60).toFixed(0),
    };
  });

  // Calculate year totals
  let totalActiveDays = 0;
  let totalYearProductiveMins = 0;
  let totalYearHabits = 0;
  let totalYearTasks = data.tasks.filter((t) => t.completed && t.dueDate.startsWith(String(selectedYear))).length;

  // Yearly contribution heatmap data (all 365 days)
  const isLeapYear = (selectedYear % 4 === 0 && selectedYear % 100 !== 0) || selectedYear % 400 === 0;
  const daysInYear = isLeapYear ? 366 : 365;

  const yearDays: { dateStr: string; score: number }[] = [];
  const startOfYear = new Date(selectedYear, 0, 1);

  for (let i = 0; i < daysInYear; i++) {
    const d = new Date(startOfYear);
    d.setDate(d.getDate() + i);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const bd = calculateDayProductivity(dateStr, data);

    if (bd.tasksCompleted > 0 || bd.habitsCompleted > 0 || bd.totalTrackedMinutes > 0) {
      totalActiveDays++;
    }
    totalYearProductiveMins += bd.productiveMinutes;
    totalYearHabits += bd.habitsCompleted;

    yearDays.push({ dateStr, score: bd.score });
  }

  const yearlyAverageProductivity = Math.round(
    monthData.reduce((acc, curr) => acc + curr.score, 0) / 12
  );

  // Best month
  let bestMonth = monthData[0];
  monthData.forEach((m) => {
    if (m.score > bestMonth.score) bestMonth = m;
  });

  // Completed goals in this year
  const completedGoals = data.goals.filter((g) => g.status === 'completed').length;
  const goalAchievementRate = data.goals.length > 0
    ? Math.round((completedGoals / data.goals.length) * 100)
    : 0;

  const handleCopyAnnualReport = () => {
    const report = `====================================
MY LIFE TRACKER - ANNUAL LIFE PERFORMANCE REPORT (${selectedYear})
====================================
• Active Days: ${totalActiveDays} / ${daysInYear} days
• Average Annual Productivity: ${yearlyAverageProductivity}%
• Total Productive Hours: ${(totalYearProductiveMins / 60).toFixed(0)} hrs
• Habits Completed: ${totalYearHabits}
• Tasks Finalized: ${totalYearTasks}
• Peak Month: ${bestMonth.name} (${bestMonth.score}%)
• Longest Habit Streak: ${streaks.longestStreak} days
• Goal Achievement: ${completedGoals} of ${data.goals.length} (${goalAchievementRate}%)
====================================`;
    navigator.clipboard.writeText(report);
    addToast('Annual life performance report copied!', 'success');
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Yearly Progress & Heatmap</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {selectedYear}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Annual trajectory, 365-day contribution matrix, and milestone achievement.
          </p>
        </div>

        {/* Year Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              onClick={() => setSelectedYear((y) => y - 1)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-white px-3 font-mono">
              {selectedYear}
            </span>
            <button
              onClick={() => setSelectedYear((y) => y + 1)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleCopyAnnualReport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white rounded-xl transition"
          >
            <Copy className="w-3.5 h-3.5 text-indigo-400" />
            <span>Annual Report</span>
          </button>
        </div>
      </div>

      {/* Annual KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Total Active Days
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {totalActiveDays} <span className="text-sm font-normal text-slate-400">/ {daysInYear}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {Math.round((totalActiveDays / daysInYear) * 100)}% year consistency
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-950/20 border border-indigo-500/30 p-4">
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
            Productive Hours
          </div>
          <div className="text-2xl font-extrabold text-indigo-300 mt-1">
            {(totalYearProductiveMins / 60).toFixed(0)} <span className="text-sm font-normal text-indigo-400">hrs</span>
          </div>
          <div className="text-[11px] text-indigo-200/80 mt-1">
            Annual focused work
          </div>
        </div>

        <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-4">
          <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span>Longest Streak</span>
          </div>
          <div className="text-2xl font-extrabold text-amber-300 mt-1">
            {streaks.longestStreak} Days
          </div>
          <div className="text-[11px] text-amber-200/80 mt-1">
            Best Month: {bestMonth.name} ({bestMonth.score}%)
          </div>
        </div>

        <div className="rounded-2xl bg-emerald-950/20 border border-emerald-500/30 p-4">
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5" />
            <span>Goal Achievement</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {goalAchievementRate}%
          </div>
          <div className="text-[11px] text-emerald-200/80 mt-1">
            {completedGoals} of {data.goals.length} goals realized
          </div>
        </div>
      </div>

      {/* GitHub-style 365-Day Contribution Heatmap */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-400" />
            <span>Yearly Life Contribution Heatmap (365 Days)</span>
          </h3>
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
            <span>0%</span>
            <span className="w-2.5 h-2.5 rounded-sm bg-slate-800" />
            <span className="w-2.5 h-2.5 rounded-sm bg-indigo-950" />
            <span className="w-2.5 h-2.5 rounded-sm bg-indigo-600" />
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
            <span>100%</span>
          </div>
        </div>

        <div className="overflow-x-auto pb-2">
          <div className="grid grid-flow-col grid-rows-7 gap-1 min-w-[720px]">
            {yearDays.map((yd, idx) => {
              let bg = 'bg-slate-950 border border-slate-850';
              if (yd.score >= 80) bg = 'bg-emerald-500 shadow-xs shadow-emerald-500/30';
              else if (yd.score >= 60) bg = 'bg-indigo-500';
              else if (yd.score >= 40) bg = 'bg-indigo-800';
              else if (yd.score > 0) bg = 'bg-indigo-950/70 border border-slate-800';

              return (
                <div
                  key={idx}
                  title={`${yd.dateStr}: ${yd.score}% Productivity`}
                  onClick={() => setSelectedDate(yd.dateStr)}
                  className={`w-3 h-3 rounded-xs cursor-pointer hover:scale-150 transition-all ${bg}`}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* 12-Month Performance Bar Chart */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span>12-Month Performance Trend (%)</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {selectedYear}
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`${val}%`, 'Average Productivity']}
              />
              <Bar dataKey="score" radius={[6, 6, 0, 0]}>
                {monthData.map((entry) => (
                  <Cell
                    key={`bar-${entry.name}`}
                    fill={entry.score >= 75 ? '#10b981' : '#6366f1'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
