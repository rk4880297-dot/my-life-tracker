import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  Clock,
  TrendingUp,
  Award,
  Sparkles,
  Info,
  CheckCircle2,
  PieChart as PieIcon,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { CircularProgress } from '../Common/CircularProgress';
import { WeeklyTracker } from './WeeklyTracker';
import { MonthlyTracker } from './MonthlyTracker';
import { YearlyTracker } from './YearlyTracker';
import { TimeManagement } from './TimeManagement';

export const SmartAnalytics: React.FC = () => {
  const { breakdown, suggestions, data, selectedDate } = useLifeTracker();
  const [subTab, setSubTab] = useState<'overview' | 'weekly' | 'monthly' | 'yearly' | 'time'>('overview');

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Analytics Sub-navigation Pills */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-900 border border-slate-800 rounded-2xl overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: 'Productivity Score' },
          { id: 'weekly', label: 'Weekly Performance' },
          { id: 'monthly', label: 'Monthly Heatmap' },
          { id: 'yearly', label: 'Yearly Overview' },
          { id: 'time', label: 'Time Management' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSubTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
              subTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === 'weekly' && <WeeklyTracker />}
      {subTab === 'monthly' && <MonthlyTracker />}
      {subTab === 'yearly' && <YearlyTracker />}
      {subTab === 'time' && <TimeManagement />}

      {subTab === 'overview' && (
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
              <span>Transparent Productivity Engine</span>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold px-2.5 py-0.5 rounded-full">
                Score: {breakdown.score}%
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Zero fake analytics. Formulated purely from your real task completions, habit streaks, and tracked focus.
            </p>
          </div>

          {/* Transparent Formula Breakdown */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-6">
            <div className="flex flex-col md:flex-row items-center gap-6 justify-between pb-6 border-b border-slate-800">
              <div className="flex items-center gap-6">
                <CircularProgress
                  percentage={breakdown.score}
                  size={140}
                  strokeWidth={12}
                  label="Score"
                  sublabel="Daily Composite"
                />
                <div className="space-y-1">
                  <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                    Productivity Algorithm
                  </div>
                  <h3 className="text-xl font-extrabold text-white">
                    4-Factor Weighted Formula
                  </h3>
                  <p className="text-xs text-slate-400 max-w-md">
                    Score = (Tasks × 30%) + (Habits × 35%) + (Focus Ratio × 25%) + (Hydration & Health × 10%)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl text-xs text-indigo-300">
                <Info className="w-5 h-5 shrink-0 text-indigo-400" />
                <span>Verified mathematically from local database records for {selectedDate}.</span>
              </div>
            </div>

            {/* 4 Factor Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Factor 1: Habits */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-emerald-400">1. Habits (35% Weight)</span>
                  <span className="font-bold text-white">{breakdown.habitScore}%</span>
                </div>
                <div className="text-xs text-slate-400">
                  {breakdown.habitsCompleted} of {breakdown.habitsTotal} active habits completed today.
                </div>
                <div className="w-full bg-slate-850 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full"
                    style={{ width: `${breakdown.habitScore}%` }}
                  />
                </div>
              </div>

              {/* Factor 2: Tasks */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-indigo-400">2. Tasks (30% Weight)</span>
                  <span className="font-bold text-white">{breakdown.taskScore}%</span>
                </div>
                <div className="text-xs text-slate-400">
                  {breakdown.tasksCompleted} of {breakdown.tasksTotal} due tasks finished.
                </div>
                <div className="w-full bg-slate-850 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-indigo-500 h-full rounded-full"
                    style={{ width: `${breakdown.taskScore}%` }}
                  />
                </div>
              </div>

              {/* Factor 3: Time Focus */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-cyan-400">3. Focus (25% Weight)</span>
                  <span className="font-bold text-white">{breakdown.timeScore}%</span>
                </div>
                <div className="text-xs text-slate-400">
                  {(breakdown.productiveMinutes / 60).toFixed(1)}h productive vs {(breakdown.unproductiveMinutes / 60).toFixed(1)}h unproductive.
                </div>
                <div className="w-full bg-slate-850 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-cyan-500 h-full rounded-full"
                    style={{ width: `${breakdown.timeScore}%` }}
                  />
                </div>
              </div>

              {/* Factor 4: Health */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-blue-400">4. Health (10% Weight)</span>
                  <span className="font-bold text-white">{breakdown.healthScore}%</span>
                </div>
                <div className="text-xs text-slate-400">
                  {(breakdown.waterIntakeMl / 1000).toFixed(1)}L water, {breakdown.exerciseMinutes}m workout, {breakdown.sleepHours}h sleep.
                </div>
                <div className="w-full bg-slate-850 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-blue-500 h-full rounded-full"
                    style={{ width: `${breakdown.healthScore}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Smart Suggestions */}
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-3">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span>Real-Time Personalized Growth Suggestions</span>
            </h3>
            <div className="space-y-2.5">
              {suggestions.map((suggestion, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-xs text-slate-200 leading-relaxed flex items-start gap-3"
                >
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <span>{suggestion}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
