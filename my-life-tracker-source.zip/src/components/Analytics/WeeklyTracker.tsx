import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Award,
  Zap,
  CheckCircle2,
  FileText,
  Copy,
  Clock,
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { calculateDayProductivity } from '../../services/analytics';

export const WeeklyTracker: React.FC = () => {
  const { data, selectedDate, setSelectedDate, addToast } = useLifeTracker();

  // Reference date for the week
  const [currentWeekOffset, setCurrentWeekOffset] = useState(0);

  // Calculate Monday date of the current view
  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() + currentWeekOffset * 7);
  const dayOfWeek = (baseDate.getDay() + 6) % 7; // Monday = 0
  const monday = new Date(baseDate);
  monday.setDate(monday.getDate() - dayOfWeek);

  // 7 days from Monday to Sunday
  const days = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(monday);
    d.setDate(d.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${day}`;
    const dayName = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i];
    const breakdown = calculateDayProductivity(dateStr, data);

    return {
      dateStr,
      dayName,
      dayNum: d.getDate(),
      breakdown,
    };
  });

  // Aggregates
  let totalProductiveMinutes = 0;
  let totalStudyMinutes = 0;
  let totalExerciseMinutes = 0;
  let totalSleepHours = 0;
  let totalCompletedHabits = 0;
  let totalCompletedTasks = 0;
  let totalActivitiesCount = 0;
  let productivityScores: number[] = [];

  days.forEach((d) => {
    totalProductiveMinutes += d.breakdown.productiveMinutes;
    totalStudyMinutes += d.breakdown.studyMinutes;
    totalExerciseMinutes += d.breakdown.exerciseMinutes;
    totalSleepHours += d.breakdown.sleepHours;
    totalCompletedHabits += d.breakdown.habitsCompleted;
    totalCompletedTasks += d.breakdown.tasksCompleted;
    productivityScores.push(d.breakdown.score);

    const actCount = data.activities.filter((a) => a.date === d.dateStr).length;
    totalActivitiesCount += actCount;
  });

  const avgProductivity = Math.round(
    productivityScores.reduce((a, b) => a + b, 0) / productivityScores.length
  );

  // Best and worst day
  let bestDay = days[0];
  let worstDay = days[0];
  days.forEach((d) => {
    if (d.breakdown.score > bestDay.breakdown.score) bestDay = d;
    if (d.breakdown.score < worstDay.breakdown.score) worstDay = d;
  });

  const chartData = days.map((d) => ({
    name: d.dayName,
    date: d.dateStr,
    score: d.breakdown.score,
    productiveHours: (d.breakdown.productiveMinutes / 60).toFixed(1),
  }));

  const weekRangeLabel = `${days[0].dateStr} to ${days[6].dateStr}`;

  // Copy or Generate Weekly Report
  const handleCopyWeeklyReport = () => {
    const report = `====================================
MY LIFE TRACKER - WEEKLY PERFORMANCE REPORT
Week: ${weekRangeLabel}
====================================
• Average Productivity: ${avgProductivity}%
• Total Productive Hours: ${(totalProductiveMinutes / 60).toFixed(1)} hrs
• Total Study / Focus: ${(totalStudyMinutes / 60).toFixed(1)} hrs
• Total Exercise: ${(totalExerciseMinutes / 60).toFixed(1)} hrs
• Total Sleep: ${totalSleepHours.toFixed(1)} hrs (Avg: ${(totalSleepHours / 7).toFixed(1)}h/night)
• Completed Habits: ${totalCompletedHabits}
• Completed Tasks: ${totalCompletedTasks}
• Total Recorded Activities: ${totalActivitiesCount}
------------------------------------
• Best Day: ${bestDay.dayName} (${bestDay.breakdown.score}%)
• Lowest Day: ${worstDay.dayName} (${worstDay.breakdown.score}%)
====================================`;

    navigator.clipboard.writeText(report);
    addToast('Weekly report copied to clipboard!', 'success');
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header & Navigation */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Weekly Performance Dashboard</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              Avg: {avgProductivity}%
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Analyze your Monday-to-Sunday trends, focus consistency, and recovery.
          </p>
        </div>

        {/* Week navigation & Export */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              onClick={() => setCurrentWeekOffset((prev) => prev - 1)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Previous Week"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-slate-300 px-2 font-mono">
              {days[0].dayNum} {days[0].dayName} - {days[6].dayNum} {days[6].dayName}
            </span>
            <button
              onClick={() => setCurrentWeekOffset((prev) => prev + 1)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Next Week"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleCopyWeeklyReport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white rounded-xl transition"
          >
            <Copy className="w-3.5 h-3.5 text-indigo-400" />
            <span>Copy Report</span>
          </button>
        </div>
      </div>

      {/* 8 Aggregates Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Average Productivity
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {avgProductivity}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Weekly composite score
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-950/20 border border-indigo-500/30 p-4">
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
            Productive Hours
          </div>
          <div className="text-2xl font-extrabold text-indigo-300 mt-1">
            {(totalProductiveMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-indigo-400">hrs</span>
          </div>
          <div className="text-[11px] text-indigo-200/80 mt-1">
            Deep focus logged
          </div>
        </div>

        <div className="rounded-2xl bg-purple-950/20 border border-purple-500/30 p-4">
          <div className="text-xs text-purple-400 font-semibold uppercase tracking-wider">
            Study / Practice
          </div>
          <div className="text-2xl font-extrabold text-purple-300 mt-1">
            {(totalStudyMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-purple-400">hrs</span>
          </div>
          <div className="text-[11px] text-purple-200/80 mt-1">
            Learning & research
          </div>
        </div>

        <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-4">
          <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
            Exercise Time
          </div>
          <div className="text-2xl font-extrabold text-amber-300 mt-1">
            {(totalExerciseMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-amber-400">hrs</span>
          </div>
          <div className="text-[11px] text-amber-200/80 mt-1">
            Cardio & workouts
          </div>
        </div>

        <div className="rounded-2xl bg-blue-950/20 border border-blue-500/30 p-4">
          <div className="text-xs text-blue-400 font-semibold uppercase tracking-wider">
            Sleep Logged
          </div>
          <div className="text-2xl font-extrabold text-blue-300 mt-1">
            {totalSleepHours.toFixed(1)} <span className="text-sm font-normal text-blue-400">hrs</span>
          </div>
          <div className="text-[11px] text-blue-200/80 mt-1">
            Avg: {(totalSleepHours / 7).toFixed(1)}h/night
          </div>
        </div>

        <div className="rounded-2xl bg-emerald-950/20 border border-emerald-500/30 p-4">
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">
            Habits Finished
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {totalCompletedHabits}
          </div>
          <div className="text-[11px] text-emerald-200/80 mt-1">
            Checkmarks completed
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Tasks Completed
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {totalCompletedTasks}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Action items finalized
          </div>
        </div>

        <div className="rounded-2xl bg-cyan-950/20 border border-cyan-500/30 p-4">
          <div className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">
            Best / Lowest Day
          </div>
          <div className="text-sm font-extrabold text-cyan-300 mt-1.5 flex items-center justify-between">
            <span>Peak: {bestDay.dayName} ({bestDay.breakdown.score}%)</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Low: {worstDay.dayName} ({worstDay.breakdown.score}%)
          </div>
        </div>
      </div>

      {/* Monday-to-Sunday Performance Bar Chart */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span>Monday-to-Sunday Productivity (%)</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {weekRangeLabel}
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`${val}%`, 'Productivity Score']}
              />
              <Bar dataKey="score" radius={[8, 8, 0, 0]}>
                {chartData.map((entry) => (
                  <Cell
                    key={`bar-${entry.name}`}
                    fill={
                      entry.score >= 80
                        ? '#10b981'
                        : entry.score >= 60
                        ? '#6366f1'
                        : '#f59e0b'
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
