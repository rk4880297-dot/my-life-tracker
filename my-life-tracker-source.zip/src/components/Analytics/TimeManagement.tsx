import React from 'react';
import {
  Clock,
  PieChart as PieIcon,
  Zap,
  AlertOctagon,
  ArrowUpRight,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';
import { useLifeTracker } from '../../context/LifeTrackerContext';

export const TimeManagement: React.FC = () => {
  const { data, selectedDate, breakdown, suggestions } = useLifeTracker();

  // Find activities for selected date
  const dayActivities = data.activities.filter((a) => a.date === selectedDate);

  // Time buckets
  let productiveMins = 0;
  let studyMins = 0;
  let businessMins = 0;
  let exerciseMins = 0;
  let entertainmentMins = 0;
  let socialMediaMins = 0;
  let sleepMins = breakdown.sleepHours * 60; // from sleep log or default
  let otherMins = 0;

  dayActivities.forEach((a) => {
    if (a.productivityRating === 'productive') productiveMins += a.durationMinutes;

    if (a.category === 'Study') studyMins += a.durationMinutes;
    else if (a.category === 'Business') businessMins += a.durationMinutes;
    else if (a.category === 'Exercise') exerciseMins += a.durationMinutes;
    else if (a.category === 'Entertainment') entertainmentMins += a.durationMinutes;
    else if (a.category === 'Social Media') socialMediaMins += a.durationMinutes;
    else if (a.category === 'Sleep') sleepMins += a.durationMinutes;
    else otherMins += a.durationMinutes;
  });

  const totalTrackedWakingMins = dayActivities.reduce((acc, curr) => acc + curr.durationMinutes, 0);
  const totalWastedMins = breakdown.unproductiveMinutes;

  // Daily Time Utilization % (Productive Hours / (24 hours - Sleep Hours))
  const wakingHours = Math.max(1, 24 - breakdown.sleepHours);
  const productiveHours = productiveMins / 60;
  const wastedHours = totalWastedMins / 60;
  const utilizationPercentage = Math.min(100, Math.round((productiveHours / wakingHours) * 100));

  const timeBarsData = [
    { name: 'Business', minutes: businessMins, hours: (businessMins / 60).toFixed(1), color: '#06b6d4' },
    { name: 'Study', minutes: studyMins, hours: (studyMins / 60).toFixed(1), color: '#a855f7' },
    { name: 'Exercise', minutes: exerciseMins, hours: (exerciseMins / 60).toFixed(1), color: '#10b981' },
    { name: 'Sleep', minutes: sleepMins, hours: (sleepMins / 60).toFixed(1), color: '#3b82f6' },
    { name: 'Entertainment', minutes: entertainmentMins, hours: (entertainmentMins / 60).toFixed(1), color: '#f59e0b' },
    { name: 'Social Media', minutes: socialMediaMins, hours: (socialMediaMins / 60).toFixed(1), color: '#ec4899' },
  ];

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <span>24-Hour Time Management Hub</span>
          <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
            {utilizationPercentage}% Waking Utilization
          </span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Deep analysis of productive focus vs wasted time across your 24-hour cycle.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-emerald-950/20 border border-emerald-500/30 p-4">
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-4 h-4" />
            <span>Productive Hours</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {productiveHours.toFixed(1)} <span className="text-sm font-normal text-emerald-400">hrs</span>
          </div>
          <div className="text-[11px] text-emerald-300/80 mt-1">
            High cognitive value work
          </div>
        </div>

        <div className="rounded-2xl bg-rose-950/20 border border-rose-500/30 p-4">
          <div className="text-xs text-rose-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <AlertOctagon className="w-4 h-4" />
            <span>Wasted Time</span>
          </div>
          <div className="text-2xl font-extrabold text-rose-300 mt-1">
            {wastedHours.toFixed(1)} <span className="text-sm font-normal text-rose-400">hrs</span>
          </div>
          <div className="text-[11px] text-rose-300/80 mt-1">
            Distractions & doom-scrolling
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-950/20 border border-indigo-500/30 p-4">
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" />
            <span>Time Utilization</span>
          </div>
          <div className="text-2xl font-extrabold text-indigo-300 mt-1">
            {utilizationPercentage}%
          </div>
          <div className="text-[11px] text-indigo-200/80 mt-1">
            Of {wakingHours.toFixed(1)} waking hours
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Total Sleep Logged
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {breakdown.sleepHours.toFixed(1)} <span className="text-sm font-normal text-slate-400">hrs</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Restorative cycle
          </div>
        </div>
      </div>

      {/* 24-Hour Time Distribution Bar Chart */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>Time Allocation Breakdown (Hours)</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {selectedDate}
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={timeBarsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`${val} mins (${(Number(val) / 60).toFixed(1)}h)`, 'Duration']}
              />
              <Bar dataKey="minutes" radius={[6, 6, 0, 0]}>
                {timeBarsData.map((entry) => (
                  <Cell key={`cell-${entry.name}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Real Smart Suggestions for Time Management */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-3">
        <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span>Actionable Time Management Optimization Tips</span>
        </div>
        <div className="space-y-2.5">
          {suggestions.map((s, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-200"
            >
              <div className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center shrink-0 mt-0.5">
                {idx + 1}
              </div>
              <p className="leading-relaxed">{s}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
