import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Award,
  Zap,
  Sparkles,
  Copy,
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { calculateDayProductivity, calculateHabitStreaks } from '../../services/analytics';
import { getTodayDateString } from '../../services/storage';

export const MonthlyTracker: React.FC = () => {
  const { data, selectedDate, setSelectedDate, addToast } = useLifeTracker();

  const now = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(now.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(now.getMonth()); // 0-indexed

  // Days in selected month
  const firstDay = new Date(selectedYear, selectedMonth, 1);
  const totalDays = new Date(selectedYear, selectedMonth + 1, 0).getDate();
  const startDayOfWeek = (firstDay.getDay() + 6) % 7; // Monday = 0

  const monthName = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  // Gather days data
  let totalProductiveMinutes = 0;
  let totalHabitsCompleted = 0;
  let totalTasksCompleted = 0;
  let scores: number[] = [];
  let bestDayNum = 1;
  let bestDayScore = -1;

  const daysData = Array.from({ length: totalDays }).map((_, i) => {
    const dayNum = i + 1;
    const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    const breakdown = calculateDayProductivity(dateStr, data);

    totalProductiveMinutes += breakdown.productiveMinutes;
    totalHabitsCompleted += breakdown.habitsCompleted;
    totalTasksCompleted += breakdown.tasksCompleted;
    scores.push(breakdown.score);

    if (breakdown.score > bestDayScore) {
      bestDayScore = breakdown.score;
      bestDayNum = dayNum;
    }

    return {
      dayNum,
      dateStr,
      score: breakdown.score,
      breakdown,
    };
  });

  const avgProductivity = scores.length > 0
    ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
    : 0;

  // Most consistent habit
  let topHabitName = 'None';
  let topStreak = -1;
  data.habits.forEach((h) => {
    const { currentStreak } = calculateHabitStreaks(h.id, data.habitLogs);
    if (currentStreak > topStreak) {
      topStreak = currentStreak;
      topHabitName = h.name;
    }
  });

  // Week-by-week averages (approx 4-5 weeks)
  const weeklyBuckets: { name: string; score: number }[] = [];
  for (let w = 0; w < Math.ceil(totalDays / 7); w++) {
    const chunk = daysData.slice(w * 7, (w + 1) * 7);
    const chunkAvg = chunk.length > 0
      ? Math.round(chunk.reduce((acc, curr) => acc + curr.score, 0) / chunk.length)
      : 0;
    weeklyBuckets.push({
      name: `Week ${w + 1}`,
      score: chunkAvg,
    });
  }

  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11);
      setSelectedYear((y) => y - 1);
    } else {
      setSelectedMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0);
      setSelectedYear((y) => y + 1);
    } else {
      setSelectedMonth((m) => m + 1);
    }
  };

  const handleCopyMonthlyReport = () => {
    const text = `====================================
MY LIFE TRACKER - MONTHLY REPORT: ${monthName.toUpperCase()}
====================================
• Monthly Average Productivity: ${avgProductivity}%
• Total Productive Hours: ${(totalProductiveMinutes / 60).toFixed(1)} hrs
• Total Habits Checked: ${totalHabitsCompleted}
• Total Tasks Accomplished: ${totalTasksCompleted}
• Best Day: Day ${bestDayNum} (${bestDayScore}%)
• Most Consistent Habit: ${topHabitName}
====================================`;
    navigator.clipboard.writeText(text);
    addToast('Monthly report copied to clipboard!', 'success');
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Monthly Life Analytics</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {monthName}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Productivity heatmaps, week-by-week comparisons, and habit consistency.
          </p>
        </div>

        {/* Month Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              onClick={handlePrevMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-white px-2.5 font-mono">
              {monthName}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleCopyMonthlyReport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white rounded-xl transition"
          >
            <Copy className="w-3.5 h-3.5 text-indigo-400" />
            <span>Copy Report</span>
          </button>
        </div>
      </div>

      {/* Aggregate Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Monthly Average Score
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {avgProductivity}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Across {totalDays} days
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-950/20 border border-indigo-500/30 p-4">
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
            Total Productive Hours
          </div>
          <div className="text-2xl font-extrabold text-indigo-300 mt-1">
            {(totalProductiveMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-indigo-400">hrs</span>
          </div>
          <div className="text-[11px] text-indigo-200/80 mt-1">
            Focused output
          </div>
        </div>

        <div className="rounded-2xl bg-emerald-950/20 border border-emerald-500/30 p-4">
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">
            Habits Completed
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {totalHabitsCompleted}
          </div>
          <div className="text-[11px] text-emerald-200/80 mt-1">
            Checkmarks hit
          </div>
        </div>

        <div className="rounded-2xl bg-amber-950/20 border border-amber-500/30 p-4">
          <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
            Best Day
          </div>
          <div className="text-lg font-extrabold text-amber-300 mt-1">
            Day {bestDayNum} ({bestDayScore}%)
          </div>
          <div className="text-[11px] text-amber-200/80 mt-1 truncate">
            Top Habit: {topHabitName}
          </div>
        </div>
      </div>

      {/* Heatmap & Week Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Heatmap Calendar */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-400" />
              <span>Daily Productivity Heatmap</span>
            </h3>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
              <span>Low</span>
              <span className="w-2.5 h-2.5 rounded bg-slate-800" />
              <span className="w-2.5 h-2.5 rounded bg-indigo-900" />
              <span className="w-2.5 h-2.5 rounded bg-indigo-600" />
              <span className="w-2.5 h-2.5 rounded bg-emerald-500" />
              <span>High</span>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
              <div key={d} className="text-center text-[11px] font-bold text-slate-500 py-1">
                {d}
              </div>
            ))}

            {/* Empty offset days */}
            {Array.from({ length: startDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="h-12 rounded-xl bg-transparent" />
            ))}

            {/* Month days */}
            {daysData.map((d) => {
              const score = d.score;
              const isSelected = selectedDate === d.dateStr;

              let bgClass = 'bg-slate-950 border-slate-800 text-slate-400';
              if (score >= 80) bgClass = 'bg-emerald-500/25 border-emerald-500/50 text-emerald-300';
              else if (score >= 60) bgClass = 'bg-indigo-600/30 border-indigo-500/50 text-indigo-200';
              else if (score > 30) bgClass = 'bg-indigo-950/40 border-slate-800 text-slate-300';

              return (
                <div
                  key={d.dayNum}
                  onClick={() => setSelectedDate(d.dateStr)}
                  className={`h-12 rounded-xl border p-1.5 flex flex-col justify-between cursor-pointer transition hover:scale-105 ${bgClass} ${
                    isSelected ? 'ring-2 ring-indigo-400' : ''
                  }`}
                >
                  <span className="text-[11px] font-mono font-bold leading-none">{d.dayNum}</span>
                  <span className="text-[10px] font-bold self-end font-mono">
                    {score}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weekly Comparison Chart */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span>Week-by-Week Average %</span>
          </h3>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyBuckets} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                  formatter={(val: any) => [`${val}%`, 'Weekly Average']}
                />
                <Bar dataKey="score" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
