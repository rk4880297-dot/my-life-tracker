import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  Terminal,
  CheckCircle2,
  Copy,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Cloud,
  Github,
  Play,
  FileCheck,
  PackageCheck,
  ArrowRight,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { PWAInstallButton } from '../Common/PWAInstallButton';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const AndroidAppHub: React.FC = () => {
  const { addToast } = useLifeTracker();
  const { isInstalled } = usePWAInstall();
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'cloud' | 'instructions' | 'workflow'>('cloud');

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(label);
    addToast(`Copied ${label} to clipboard`, 'success');
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  const workflowYaml = `name: Build Android APK

on:
  workflow_dispatch:
  push:
    branches:
      - main
      - master

permissions:
  contents: read

jobs:
  build-apk:
    name: Build Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Set up Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install Project Dependencies
        run: |
          npm ci --legacy-peer-deps || npm install --legacy-peer-deps

      - name: Build Web Application
        run: |
          npm run build

      - name: Sync Web Assets to Android Project
        run: |
          npx cap sync android

      - name: Grant Execute Permission to Gradle Wrapper
        run: |
          chmod +x android/gradlew

      - name: Build Android Debug APK with Gradle
        working-directory: android
        run: |
          ./gradlew assembleDebug --no-daemon --stacktrace

      - name: Verify APK Output
        run: |
          if [ ! -f "android/app/build/outputs/apk/debug/app-debug.apk" ]; then
            echo "::error::APK file was not generated at android/app/build/outputs/apk/debug/app-debug.apk"
            exit 1
          fi
          echo "APK successfully built:"
          ls -lh android/app/build/outputs/apk/debug/app-debug.apk

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: My-Life-Tracker-Debug-APK
          path: android/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 30`;

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Android APK & Cloud Build Hub</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              Mobile-Only Ready
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Build your native Android APK using free GitHub Actions cloud runners directly from your smartphone.
          </p>
        </div>

        {/* Direct Download ZIP Button */}
        <a
          href="/my-life-tracker-source.zip"
          download="my-life-tracker-source.zip"
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm shadow-xl shadow-emerald-950/50 transition active:scale-95 shrink-0 border border-emerald-400/40"
        >
          <Download className="w-4 h-4" />
          <span>Download Project ZIP (3.0 MB)</span>
        </a>
      </div>

      {/* Hero: 1-Tap Cloud APK Overview */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/40 p-6 sm:p-7 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-56 h-56 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
              <Cloud className="w-4 h-4 text-cyan-400" />
              <span>No Laptop or PC Required · 100% Mobile Workflow</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
              Build & Download Your Real Android APK in 3 Steps
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Your source code is pre-configured with <strong className="text-white">Capacitor 8</strong>, <strong className="text-white">Gradle 8.14</strong>, exact notification alarm permissions, and an automated <strong className="text-indigo-300">GitHub Actions CI workflow</strong>. Simply upload this ZIP to GitHub on your phone to get your downloadable <code className="font-mono text-emerald-400 bg-emerald-950/50 px-1.5 py-0.5 rounded text-[11px]">app-debug.apk</code> artifact.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full lg:w-auto shrink-0">
            <a
              href="/my-life-tracker-source.zip"
              download="my-life-tracker-source.zip"
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition active:scale-95 border border-indigo-400/40"
            >
              <Download className="w-4 h-4" />
              <span>1. Download ZIP to Phone</span>
            </a>

            <a
              href="https://github.com/new"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-sm border border-slate-700 transition active:scale-95"
            >
              <Github className="w-4 h-4" />
              <span>2. Open GitHub (New Repo)</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('cloud')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'cloud'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span>Mobile Phone Step-by-Step Guide</span>
        </button>

        <button
          onClick={() => setActiveTab('workflow')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'workflow'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>GitHub Actions Workflow</span>
        </button>

        <button
          onClick={() => setActiveTab('instructions')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'instructions'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Verification & Technical Specs</span>
        </button>
      </div>

      {/* TAB 1: Mobile-Only Step-by-Step Guide */}
      {activeTab === 'cloud' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Step 1 */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3 relative">
              <div className="w-8 h-8 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 font-extrabold flex items-center justify-center text-sm">
                1
              </div>
              <h4 className="font-bold text-white text-base">Download the Source ZIP</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tap the green <strong className="text-slate-200">Download Project ZIP</strong> button. Your phone will save <code className="text-indigo-300 font-mono text-[11px]">my-life-tracker-source.zip</code> (approx. 3.0 MB) to your Downloads folder.
              </p>
              <div className="pt-2">
                <a
                  href="/my-life-tracker-source.zip"
                  download="my-life-tracker-source.zip"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tap to Download ZIP</span>
                </a>
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="w-8 h-8 rounded-2xl bg-cyan-600/20 border border-cyan-500/40 text-cyan-400 font-extrabold flex items-center justify-center text-sm">
                2
              </div>
              <h4 className="font-bold text-white text-base">Create Free GitHub Repo</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Open <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-cyan-300 underline font-semibold">github.com/new</a> in Chrome/Brave on your phone. Name it <code className="text-cyan-300 font-mono text-[11px]">my-life-tracker</code> and tap <strong className="text-slate-200">Create repository</strong>.
              </p>
              <div className="pt-2 text-[11px] text-slate-500">
                You can keep it Public or Private.
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="w-8 h-8 rounded-2xl bg-purple-600/20 border border-purple-500/40 text-purple-400 font-extrabold flex items-center justify-center text-sm">
                3
              </div>
              <h4 className="font-bold text-white text-base">Upload & Push Code</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                On the repo page on your phone, tap <strong className="text-slate-200">uploading an existing file</strong>. Drag/select the extracted files or push using Git/Termux or GitHub Mobile app.
              </p>
              <div className="pt-2 text-[11px] text-purple-300/80">
                Workflow file <code className="font-mono">.github/workflows/android-apk.yml</code> is included in the ZIP!
              </div>
            </div>

            {/* Step 4 */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="w-8 h-8 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 font-extrabold flex items-center justify-center text-sm">
                4
              </div>
              <h4 className="font-bold text-white text-base">Download Built APK</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tap the <strong className="text-slate-200">Actions</strong> tab on GitHub → tap <strong className="text-slate-200">Build Android APK</strong> → tap <strong className="text-slate-200">Run workflow</strong>. Wait 3 mins, then download <strong className="text-emerald-400">My-Life-Tracker-Debug-APK</strong>!
              </p>
              <div className="pt-2 text-[11px] text-emerald-400 font-semibold">
                Tap the downloaded APK on your phone to install!
              </div>
            </div>
          </div>

          {/* Detailed Walkthrough with Visual Cards */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Play className="w-4 h-4 text-emerald-400" />
              <span>How GitHub Actions Builds Your APK in the Cloud</span>
            </h3>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <p>
                GitHub provides free high-performance cloud virtual machines equipped with <strong>Ubuntu Linux, Node.js 20, Java 17, and the Android SDK</strong>.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                  <div className="text-indigo-400 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Exact APK Output Path</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-200 break-all">
                    android/app/build/outputs/apk/debug/app-debug.apk
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                  <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Downloadable Artifact Name</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-200">
                    My-Life-Tracker-Debug-APK (.zip containing app-debug.apk)
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Workflow Code */}
      {activeTab === 'workflow' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">
              File path in project: <code className="text-indigo-300 font-mono">.github/workflows/android-apk.yml</code>
            </div>
            <button
              onClick={() => copyToClipboard(workflowYaml, 'android-apk.yml')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedCmd === 'android-apk.yml' ? 'Copied!' : 'Copy Workflow'}</span>
            </button>
          </div>

          <div className="rounded-2xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs text-slate-300 overflow-x-auto max-h-[500px]">
            <pre>{workflowYaml}</pre>
          </div>
        </div>
      )}

      {/* TAB 3: Pre-flight Verification Checklist */}
      {activeTab === 'instructions' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Mobile-Only Build Pre-Flight Verification</span>
            </h3>

            <div className="space-y-2.5 text-xs">
              {[
                {
                  label: 'Capacitor Android Configuration',
                  detail: 'capacitor.config.ts verified with appId: com.mylifetracker.app & webDir: dist',
                  status: 'PASSED',
                },
                {
                  label: 'Android Native Gradle Project',
                  detail: 'Gradle 8.14.3 wrapper with executable permissions and AGP 8.13.0',
                  status: 'PASSED',
                },
                {
                  label: 'Android Exact Alarm Permissions',
                  detail: 'SCHEDULE_EXACT_ALARM, USE_EXACT_ALARM, POST_NOTIFICATIONS in AndroidManifest.xml',
                  status: 'PASSED',
                },
                {
                  label: 'Lockfile & Dependencies Integrity',
                  detail: 'package.json and package-lock.json verified in sync with .npmrc legacy-peer-deps',
                  status: 'PASSED',
                },
                {
                  label: 'Cloud Build Workflow',
                  detail: '.github/workflows/android-apk.yml configured with Java 17, Android SDK & artifact upload',
                  status: 'PASSED',
                },
                {
                  label: 'Complete Project ZIP Archive',
                  detail: 'my-life-tracker-source.zip generated (3.0 MB) preserving file permissions',
                  status: 'PASSED',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-start justify-between p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 gap-3"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{item.label}</span>
                    </div>
                    <div className="text-slate-400 text-[11px] pl-6">{item.detail}</div>
                  </div>
                  <span className="font-mono text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-md font-bold">
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Alternative: Instant PWA Install */}
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Alternative: Instant Offline App (No APK Needed)</span>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            You can also install My Life Tracker right now without waiting for a cloud build via Progressive Web App technology.
          </p>
        </div>

        <div className="shrink-0">
          {isInstalled ? (
            <div className="flex items-center gap-2 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 px-3.5 py-2 rounded-xl text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Installed as PWA</span>
            </div>
          ) : (
            <PWAInstallButton />
          )}
        </div>
      </div>
    </div>
  );
};
