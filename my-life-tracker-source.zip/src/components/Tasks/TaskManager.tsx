import React, { useState } from 'react';
import {
  Plus,
  CheckCircle2,
  Circle,
  Calendar,
  Clock,
  Trash2,
  Edit2,
  AlertTriangle,
  Search,
  CalendarClock,
  AlarmClock,
  Bell,
  Sparkles,
} from 'lucide-react';
import { Task } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { TaskModal } from './TaskModal';
import { RescheduleModal } from './RescheduleModal';
import { ConfirmModal } from '../Common/ConfirmModal';
import { getTodayDateString } from '../../services/storage';
import {
  isTaskOverdue,
  getTaskDueDateTime,
  getOverdueDurationText,
} from '../../services/notifications';

export const TaskManager: React.FC = () => {
  const {
    data,
    selectedDate,
    toggleTask,
    deleteTask,
    snoozeTask,
    currentTime,
  } = useLifeTracker();

  const [activeTab, setActiveTab] = useState<'today' | 'pending' | 'completed' | 'overdue'>('today');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [reschedulingTask, setReschedulingTask] = useState<Task | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [snoozeMenuTaskId, setSnoozeMenuTaskId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');

  // Categorize tasks using accurate time comparisons
  const todayTasks = data.tasks.filter((t) => t.dueDate === selectedDate);
  const completedTasks = data.tasks.filter((t) => t.completed);
  const pendingTasks = data.tasks.filter((t) => !t.completed);
  const overdueTasks = data.tasks.filter((t) => isTaskOverdue(t, currentTime));

  let displayedTasks: Task[] = [];
  if (activeTab === 'today') displayedTasks = todayTasks;
  else if (activeTab === 'completed') displayedTasks = completedTasks;
  else if (activeTab === 'pending') displayedTasks = pendingTasks;
  else if (activeTab === 'overdue') displayedTasks = overdueTasks;

  // Filter by query and priority
  displayedTasks = displayedTasks.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.description && t.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPriority = priorityFilter === 'all' || t.priority === priorityFilter;
    return matchesSearch && matchesPriority;
  });

  // Calculate completion percentage for today
  const todayTotal = todayTasks.length;
  const todayCompleted = todayTasks.filter((t) => t.completed).length;
  const todayPct = todayTotal > 0 ? Math.round((todayCompleted / todayTotal) * 100) : 0;

  // Global completion percentage
  const globalTotal = data.tasks.length;
  const globalCompleted = completedTasks.length;
  const globalPct = globalTotal > 0 ? Math.round((globalCompleted / globalTotal) * 100) : 0;

  const handleEdit = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingTask(null);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Daily Task Manager</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {todayCompleted}/{todayTotal} Done Today ({todayPct}%)
            </span>
            {overdueTasks.length > 0 && (
              <span className="text-xs bg-rose-600 text-white font-bold px-2.5 py-0.5 rounded-full shadow-md animate-pulse">
                {overdueTasks.length} Overdue
              </span>
            )}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Organize high-impact priorities, monitor deadlines, and receive smart Android notifications.
          </p>
        </div>

        <button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition shrink-0 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Task</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div
          onClick={() => setActiveTab('today')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'today'
              ? 'bg-indigo-950/30 border-indigo-500/50 shadow-lg shadow-indigo-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Today's Tasks
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {todayTotal}
          </div>
          <div className="text-[11px] text-indigo-400 mt-1 font-semibold">
            {todayPct}% completed
          </div>
        </div>

        <div
          onClick={() => setActiveTab('pending')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'pending'
              ? 'bg-amber-950/30 border-amber-500/50 shadow-lg shadow-amber-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
            Pending Tasks
          </div>
          <div className="text-2xl font-extrabold text-amber-300 mt-1">
            {pendingTasks.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Incomplete pipeline
          </div>
        </div>

        <div
          onClick={() => setActiveTab('completed')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'completed'
              ? 'bg-emerald-950/30 border-emerald-500/50 shadow-lg shadow-emerald-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">
            Completed
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {completedTasks.length}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1 font-semibold">
            {globalPct}% lifetime success
          </div>
        </div>

        <div
          onClick={() => setActiveTab('overdue')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all relative overflow-hidden ${
            activeTab === 'overdue'
              ? 'bg-rose-950/40 border-rose-500 shadow-lg shadow-rose-950/30'
              : 'bg-slate-900/80 border-slate-800 hover:border-rose-500/40'
          }`}
        >
          <div className="text-xs text-rose-400 font-bold uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Overdue Tasks</span>
            </span>
            {overdueTasks.length > 0 && (
              <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
            )}
          </div>
          <div className="text-2xl font-extrabold text-rose-300 mt-1 flex items-baseline gap-2">
            <span>{overdueTasks.length}</span>
            {overdueTasks.length > 0 && (
              <span className="text-[11px] font-bold text-rose-400 bg-rose-950/70 px-2 py-0.5 rounded-full border border-rose-500/40">
                Action Required
              </span>
            )}
          </div>
          <div className="text-[11px] text-rose-300/80 mt-1">
            Past scheduled deadline
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-2xl">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'today', label: "Today's Tasks", count: todayTasks.length },
            { id: 'pending', label: 'Pending', count: pendingTasks.length },
            { id: 'completed', label: 'Completed', count: completedTasks.length },
            { id: 'overdue', label: 'Overdue', count: overdueTasks.length, isOverdue: true },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? tab.isOverdue
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-indigo-600 text-white shadow-md'
                  : tab.isOverdue && tab.count > 0
                  ? 'bg-rose-950/40 text-rose-300 border border-rose-500/40 hover:bg-rose-900/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  tab.isOverdue && tab.count > 0
                    ? 'bg-rose-500 text-white font-bold'
                    : 'bg-slate-950/60'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search & Priority Filter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-48">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as any)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="all">All Priorities</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-3">
        {displayedTasks.length === 0 ? (
          <div className="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-12 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-slate-600 mx-auto" />
            <div className="text-slate-300 font-semibold text-sm">
              {activeTab === 'overdue'
                ? 'No overdue tasks! You are on top of your schedule.'
                : 'No tasks found in this view.'}
            </div>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              Add tasks with deadlines and priorities to keep your day structured and productive.
            </p>
            {activeTab !== 'overdue' && (
              <button
                onClick={handleAdd}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-md"
              >
                + Create New Task
              </button>
            )}
          </div>
        ) : (
          displayedTasks.map((task) => {
            const isOverdue = isTaskOverdue(task, currentTime);
            const dueDateTime = getTaskDueDateTime(task);
            const durationText = isOverdue ? getOverdueDurationText(dueDateTime, currentTime) : null;

            return (
              <div
                key={task.id}
                className={`group relative rounded-2xl border transition-all p-4 ${
                  task.completed
                    ? 'bg-slate-950/40 border-slate-800/80 text-slate-400'
                    : isOverdue
                    ? 'bg-rose-950/15 border-rose-500/40 shadow-lg shadow-rose-950/10'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  {/* Checkbox & Info */}
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <button
                      type="button"
                      onClick={() => toggleTask(task.id)}
                      className={`p-1 mt-0.5 rounded-lg transition shrink-0 ${
                        task.completed ? 'text-indigo-400' : 'text-slate-500 hover:text-indigo-400'
                      }`}
                      title={task.completed ? 'Mark Incomplete' : 'Mark Completed'}
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-6 h-6 fill-indigo-500/20" />
                      ) : (
                        <Circle className="w-6 h-6" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`text-sm sm:text-base font-bold ${
                            task.completed ? 'line-through text-slate-500' : 'text-white'
                          }`}
                        >
                          {task.title}
                        </span>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                            task.priority === 'high'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : task.priority === 'medium'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          }`}
                        >
                          {task.priority}
                        </span>

                        <span className="text-[10px] font-semibold text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                          {task.category}
                        </span>
                      </div>

                      {task.description && (
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          {task.description}
                        </p>
                      )}

                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-400">
                        <div className="flex items-center gap-1 font-mono">
                          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{task.dueDate}</span>
                        </div>
                        {task.dueTime && (
                          <div className="flex items-center gap-1 font-mono">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span>{task.dueTime}</span>
                          </div>
                        )}
                        {isOverdue && durationText && (
                          <span className="text-rose-400 font-bold flex items-center gap-1 text-[11px] bg-rose-950/70 border border-rose-500/30 px-2 py-0.5 rounded-lg">
                            <AlertTriangle className="w-3 h-3" />
                            {durationText}
                          </span>
                        )}
                        {task.snoozedUntil && new Date(task.snoozedUntil) > currentTime && (
                          <span className="text-amber-400 font-semibold flex items-center gap-1 text-[11px]">
                            <AlarmClock className="w-3 h-3" />
                            Snoozed until {new Date(task.snoozedUntil).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* SMART TASK MANAGEMENT BUTTONS */}
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800">
                    {/* Mark Completed button */}
                    <button
                      onClick={() => toggleTask(task.id)}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition ${
                        task.completed
                          ? 'bg-slate-800 text-slate-300 hover:text-white'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
                      }`}
                      title={task.completed ? 'Reopen Task' : 'Mark Completed'}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{task.completed ? 'Reopen' : 'Done'}</span>
                    </button>

                    {/* Reschedule button */}
                    <button
                      onClick={() => setReschedulingTask(task)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold transition"
                      title="Reschedule Deadline"
                    >
                      <CalendarClock className="w-3.5 h-3.5" />
                      <span>Reschedule</span>
                    </button>

                    {/* Remind Me Later / Snooze button */}
                    {!task.completed && (
                      <div className="relative">
                        <button
                          onClick={() =>
                            setSnoozeMenuTaskId(snoozeMenuTaskId === task.id ? null : task.id)
                          }
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold transition"
                          title="Remind Me Later"
                        >
                          <AlarmClock className="w-3.5 h-3.5" />
                          <span>Snooze</span>
                        </button>

                        {snoozeMenuTaskId === task.id && (
                          <div className="absolute right-0 bottom-full mb-1.5 w-36 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-1 z-30 animate-in fade-in text-xs space-y-0.5">
                            <button
                              onClick={() => {
                                snoozeTask(task.id, 15);
                                setSnoozeMenuTaskId(null);
                              }}
                              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                            >
                              In 15 mins
                            </button>
                            <button
                              onClick={() => {
                                snoozeTask(task.id, 60);
                                setSnoozeMenuTaskId(null);
                              }}
                              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                            >
                              In 1 hour
                            </button>
                            <button
                              onClick={() => {
                                snoozeTask(task.id, 180);
                                setSnoozeMenuTaskId(null);
                              }}
                              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-slate-200"
                            >
                              In 3 hours
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Edit button */}
                    <button
                      onClick={() => handleEdit(task)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                      title="Edit Task"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {/* Delete button */}
                    <button
                      onClick={() => setDeleteConfirmId(task.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                      title="Delete Task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Task Edit/Create Modal */}
      <TaskModal
        isOpen={isModalOpen}
        taskToEdit={editingTask}
        onClose={() => setIsModalOpen(false)}
      />

      {/* Reschedule Modal */}
      <RescheduleModal
        isOpen={!!reschedulingTask}
        task={reschedulingTask}
        onClose={() => setReschedulingTask(null)}
      />

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Task"
        message="Are you sure you want to delete this task? All scheduled reminders and notifications will also be cancelled."
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteTask(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
