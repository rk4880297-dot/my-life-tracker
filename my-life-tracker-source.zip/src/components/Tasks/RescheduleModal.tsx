import React, { useState } from 'react';
import { Calendar, Clock, X, ArrowRight, Sparkles } from 'lucide-react';
import { Task } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { formatDateOffset, getTodayDateString } from '../../services/storage';

interface RescheduleModalProps {
  isOpen: boolean;
  task: Task | null;
  onClose: () => void;
}

export const RescheduleModal: React.FC<RescheduleModalProps> = ({ isOpen, task, onClose }) => {
  const { rescheduleTask } = useLifeTracker();

  const [date, setDate] = useState(task?.dueDate || getTodayDateString());
  const [time, setTime] = useState(task?.dueTime || '18:00');

  if (!isOpen || !task) return null;

  const handleQuickReschedule = (daysOffset: number, defaultTime: string = '18:00') => {
    const targetDate = formatDateOffset(daysOffset);
    rescheduleTask(task.id, targetDate, defaultTime);
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (date) {
      rescheduleTask(task.id, date, time);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base">Reschedule Task Deadline</h3>
            <p className="text-xs text-slate-400 mt-0.5 truncate max-w-[280px]">"{task.title}"</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Options */}
        <div className="py-4 space-y-3">
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
            Quick Reschedule Presets
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleQuickReschedule(0, '20:00')}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 text-left transition"
            >
              <div className="text-xs font-bold text-white">Tonight (8:00 PM)</div>
              <div className="text-[11px] text-slate-400">Finish before sleep</div>
            </button>

            <button
              onClick={() => handleQuickReschedule(1, '09:00')}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 text-left transition"
            >
              <div className="text-xs font-bold text-indigo-300">Tomorrow Morning</div>
              <div className="text-[11px] text-slate-400">Fresh start at 9:00 AM</div>
            </button>

            <button
              onClick={() => handleQuickReschedule(1, '18:00')}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 text-left transition"
            >
              <div className="text-xs font-bold text-white">Tomorrow Evening</div>
              <div className="text-[11px] text-slate-400">End of next workday</div>
            </button>

            <button
              onClick={() => handleQuickReschedule(3, '14:00')}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 text-left transition"
            >
              <div className="text-xs font-bold text-cyan-300">In 3 Days</div>
              <div className="text-[11px] text-slate-400">Pushed to weekend block</div>
            </button>
          </div>

          {/* Custom Date & Time Form */}
          <form onSubmit={handleCustomSubmit} className="pt-3 border-t border-slate-800/80 space-y-3">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Or Choose Specific Date & Time
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">New Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">New Time</label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  required
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md transition"
              >
                Update Deadline
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
