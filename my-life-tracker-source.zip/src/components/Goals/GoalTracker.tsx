import React, { useState } from 'react';
import {
  Plus,
  Target,
  Trophy,
  Calendar,
  AlertTriangle,
  Edit2,
  Trash2,
  TrendingUp,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { Goal, GoalCategory } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { GoalModal } from './GoalModal';
import { ConfirmModal } from '../Common/ConfirmModal';
import { getTodayDateString } from '../../services/storage';

export const GoalTracker: React.FC = () => {
  const { data, updateGoalProgress, deleteGoal } = useLifeTracker();

  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'completed' | 'overdue'>('active');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const todayStr = getTodayDateString();

  // Classify goals
  const activeGoals = data.goals.filter(
    (g) => g.status === 'active' && g.currentProgress < g.targetValue && g.targetDate >= todayStr
  );
  const completedGoals = data.goals.filter(
    (g) => g.status === 'completed' || g.currentProgress >= g.targetValue
  );
  const overdueGoals = data.goals.filter(
    (g) => g.currentProgress < g.targetValue && g.targetDate < todayStr
  );

  let displayedGoals = data.goals;
  if (activeTab === 'active') displayedGoals = activeGoals;
  else if (activeTab === 'completed') displayedGoals = completedGoals;
  else if (activeTab === 'overdue') displayedGoals = overdueGoals;

  if (categoryFilter !== 'All') {
    displayedGoals = displayedGoals.filter((g) => g.category === categoryFilter);
  }

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingGoal(null);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Milestone & Long-term Goals</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {completedGoals.length}/{data.goals.length} Achieved
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Transform high-level aspirations into quantifiable, measurable progress.
          </p>
        </div>

        <button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Goal</span>
        </button>
      </div>

      {/* Goal Summary Counters */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div
          onClick={() => setActiveTab('active')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'active'
              ? 'bg-indigo-950/30 border-indigo-500/50 shadow-lg shadow-indigo-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Active Goals
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {activeGoals.length}
          </div>
          <div className="text-[11px] text-indigo-400 mt-1 font-semibold">
            In active progress
          </div>
        </div>

        <div
          onClick={() => setActiveTab('completed')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'completed'
              ? 'bg-emerald-950/30 border-emerald-500/50 shadow-lg shadow-emerald-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5" />
            <span>Accomplished</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {completedGoals.length}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            Goals finalized
          </div>
        </div>

        <div
          onClick={() => setActiveTab('overdue')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'overdue'
              ? 'bg-rose-950/30 border-rose-500/50 shadow-lg shadow-rose-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-rose-400 font-semibold uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Overdue</span>
          </div>
          <div className="text-2xl font-extrabold text-rose-300 mt-1">
            {overdueGoals.length}
          </div>
          <div className="text-[11px] text-rose-300/80 mt-1">
            Past target date
          </div>
        </div>

        <div
          onClick={() => setActiveTab('all')}
          className={`cursor-pointer rounded-2xl border p-4 transition-all ${
            activeTab === 'all'
              ? 'bg-purple-950/30 border-purple-500/50 shadow-lg shadow-purple-500/10'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="text-xs text-purple-400 font-semibold uppercase tracking-wider">
            Total Target Registry
          </div>
          <div className="text-2xl font-extrabold text-purple-300 mt-1">
            {data.goals.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Short & long-term targets
          </div>
        </div>
      </div>

      {/* Category selector */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        {['All', 'Personal', 'Financial', 'Career', 'Education', 'Business', 'Fitness', 'Lifestyle'].map(
          (cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                categoryFilter === cat
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          )
        )}
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {displayedGoals.length === 0 ? (
          <div className="col-span-full rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-12 text-center space-y-3">
            <Target className="w-10 h-10 text-slate-600 mx-auto" />
            <div className="text-slate-300 font-semibold text-sm">
              No goals found for this filter.
            </div>
            <button
              onClick={handleAdd}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition"
            >
              + Create Goal
            </button>
          </div>
        ) : (
          displayedGoals.map((goal) => {
            const pct = Math.min(100, Math.round((goal.currentProgress / (goal.targetValue || 1)) * 100));
            const isCompleted = pct >= 100 || goal.status === 'completed';
            const isOverdue = !isCompleted && goal.targetDate < todayStr;

            return (
              <div
                key={goal.id}
                className={`relative rounded-2xl border p-5 transition-all shadow-xl space-y-4 ${
                  isCompleted
                    ? 'bg-emerald-950/15 border-emerald-500/40'
                    : isOverdue
                    ? 'bg-rose-950/10 border-rose-500/40'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-extrabold text-white">{goal.name}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {goal.category}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                          goal.priority === 'high'
                            ? 'bg-rose-500/20 text-rose-300'
                            : goal.priority === 'medium'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {goal.priority}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {goal.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => handleEdit(goal)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                      title="Edit Goal"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(goal.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                      title="Delete Goal"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Progress Bar & Value Metrics */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <div className="text-slate-300 font-mono">
                      <span>{goal.currentProgress}</span>
                      <span className="text-slate-500"> / {goal.targetValue} {goal.unit}</span>
                    </div>
                    <div className={`font-bold ${isCompleted ? 'text-emerald-400' : 'text-indigo-400'}`}>
                      {pct}%
                    </div>
                  </div>

                  <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800/80">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isCompleted
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                          : isOverdue
                          ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                          : 'bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {/* Interactive Quick Step Slider or Number Adjustment */}
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="range"
                      min="0"
                      max={goal.targetValue}
                      step={goal.targetValue > 100 ? 5 : 1}
                      value={goal.currentProgress}
                      onChange={(e) => updateGoalProgress(goal.id, Number(e.target.value))}
                      className="flex-1 accent-indigo-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg"
                    />
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() =>
                          updateGoalProgress(
                            goal.id,
                            Math.min(goal.targetValue, goal.currentProgress + (goal.targetValue > 50 ? 5 : 1))
                          )
                        }
                        className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 transition"
                      >
                        +{goal.targetValue > 50 ? 5 : 1}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Deadline and Status */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs text-slate-400">
                  <div className="flex items-center gap-1.5 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Target: {goal.targetDate}</span>
                  </div>

                  {isCompleted ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Completed
                    </span>
                  ) : isOverdue ? (
                    <span className="text-rose-400 font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Overdue
                    </span>
                  ) : (
                    <span className="text-slate-400 font-medium">In Progress</span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Goal Modal */}
      <GoalModal
        isOpen={isModalOpen}
        goalToEdit={editingGoal}
        onClose={() => setIsModalOpen(false)}
      />

      {/* Delete confirmation */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Milestone Goal"
        message="Are you sure you want to delete this goal and its progress tracking?"
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteGoal(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
