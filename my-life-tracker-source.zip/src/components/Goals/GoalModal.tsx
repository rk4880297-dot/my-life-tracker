import React, { useState, useEffect } from 'react';
import { X, Target } from 'lucide-react';
import { Goal, GoalCategory } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { formatDateOffset } from '../../services/storage';

interface GoalModalProps {
  isOpen: boolean;
  goalToEdit?: Goal | null;
  onClose: () => void;
}

const GOAL_CATEGORIES: GoalCategory[] = [
  'Personal',
  'Financial',
  'Career',
  'Education',
  'Business',
  'Fitness',
  'Lifestyle',
];

export const GoalModal: React.FC<GoalModalProps> = ({
  isOpen,
  goalToEdit,
  onClose,
}) => {
  const { addGoal, updateGoal } = useLifeTracker();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GoalCategory>('Personal');
  const [targetDate, setTargetDate] = useState(formatDateOffset(30));
  const [targetValue, setTargetValue] = useState(100);
  const [currentProgress, setCurrentProgress] = useState(0);
  const [unit, setUnit] = useState('%');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('high');
  const [error, setError] = useState('');

  useEffect(() => {
    if (goalToEdit) {
      setName(goalToEdit.name);
      setDescription(goalToEdit.description);
      setCategory(goalToEdit.category);
      setTargetDate(goalToEdit.targetDate);
      setTargetValue(goalToEdit.targetValue);
      setCurrentProgress(goalToEdit.currentProgress);
      setUnit(goalToEdit.unit);
      setPriority(goalToEdit.priority);
    } else {
      setName('');
      setDescription('');
      setCategory('Personal');
      setTargetDate(formatDateOffset(30));
      setTargetValue(100);
      setCurrentProgress(0);
      setUnit('%');
      setPriority('high');
    }
    setError('');
  }, [goalToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a goal name');
      return;
    }
    if (targetValue <= 0) {
      setError('Target value must be greater than 0');
      return;
    }

    const isDone = currentProgress >= targetValue;

    if (goalToEdit) {
      updateGoal({
        ...goalToEdit,
        name: name.trim(),
        description: description.trim(),
        category,
        targetDate,
        targetValue,
        currentProgress,
        unit: unit.trim() || '%',
        priority,
        status: isDone ? 'completed' : 'active',
      });
    } else {
      addGoal({
        name: name.trim(),
        description: description.trim(),
        category,
        targetDate,
        targetValue,
        currentProgress,
        unit: unit.trim() || '%',
        priority,
        status: isDone ? 'completed' : 'active',
      });
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/80 bg-slate-950/40">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">
              {goalToEdit ? 'Edit Goal' : 'Create New Milestone Goal'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Goal Name */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Goal Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Save $10,000 in index funds"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition"
              autoFocus
            />
          </div>

          {/* Category & Priority */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as GoalCategory)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                {GOAL_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'high' | 'medium' | 'low')}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>
            </div>
          </div>

          {/* Target Value, Current Progress, and Unit */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Target Value</label>
              <input
                type="number"
                min="1"
                step="any"
                value={targetValue}
                onChange={(e) => setTargetValue(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Current Progress</label>
              <input
                type="number"
                min="0"
                step="any"
                value={currentProgress}
                onChange={(e) => setCurrentProgress(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Unit</label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="$, kg, hrs, books"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Target Date */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Target Deadline</label>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Goal Strategy / Milestones
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Why this goal matters and key weekly habits needed..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 shadow-lg shadow-indigo-600/30 transition"
            >
              {goalToEdit ? 'Save Goal' : 'Create Goal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
