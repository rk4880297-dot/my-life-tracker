import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Smile,
  Zap,
  Sparkles,
  Save,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Search,
} from 'lucide-react';
import { MoodType, JournalEntry } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';

const MOODS: { type: MoodType; emoji: string; color: string }[] = [
  { type: 'Motivated', emoji: '🔥', color: '#f59e0b' },
  { type: 'Excited', emoji: '⚡', color: '#10b981' },
  { type: 'Happy', emoji: '😄', color: '#06b6d4' },
  { type: 'Normal', emoji: '🙂', color: '#6366f1' },
  { type: 'Tired', emoji: '🥱', color: '#8b5cf6' },
  { type: 'Stressed', emoji: '😰', color: '#f43f5e' },
  { type: 'Sad', emoji: '🌧️', color: '#64748b' },
];

export const JournalTracker: React.FC = () => {
  const { data, selectedDate, setSelectedDate, saveJournalEntry } = useLifeTracker();

  const [mood, setMood] = useState<MoodType>('Motivated');
  const [thoughts, setThoughts] = useState('');
  const [achievements, setAchievements] = useState('');
  const [biggestChallenge, setBiggestChallenge] = useState('');
  const [learnedToday, setLearnedToday] = useState('');
  const [tomorrowPlan, setTomorrowPlan] = useState('');
  const [searchFilter, setSearchFilter] = useState('');

  // Load entry for selectedDate whenever selectedDate or data changes
  useEffect(() => {
    const existing = data.journalEntries.find((j) => j.date === selectedDate);
    if (existing) {
      setMood(existing.mood);
      setThoughts(existing.thoughts);
      setAchievements(existing.achievements);
      setBiggestChallenge(existing.biggestChallenge);
      setLearnedToday(existing.learnedToday);
      setTomorrowPlan(existing.tomorrowPlan);
    } else {
      setMood('Motivated');
      setThoughts('');
      setAchievements('');
      setBiggestChallenge('');
      setLearnedToday('');
      setTomorrowPlan('');
    }
  }, [selectedDate, data.journalEntries]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveJournalEntry({
      date: selectedDate,
      mood,
      thoughts,
      achievements,
      biggestChallenge,
      learnedToday,
      tomorrowPlan,
    });
  };

  // Past journal entries
  const sortedEntries = [...data.journalEntries].sort((a, b) => b.date.localeCompare(a.date));
  const filteredPastEntries = sortedEntries.filter((entry) => {
    if (!searchFilter) return true;
    const q = searchFilter.toLowerCase();
    return (
      entry.date.includes(q) ||
      entry.thoughts.toLowerCase().includes(q) ||
      entry.achievements.toLowerCase().includes(q) ||
      entry.learnedToday.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Daily Mood & Growth Journal</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full font-mono">
              {selectedDate}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Capture daily reflections, lessons, micro-wins, and mental state.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Journal Editor */}
        <form onSubmit={handleSave} className="lg:col-span-2 rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-5">
          {/* Mood Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              How are you feeling today?
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {MOODS.map((m) => (
                <button
                  type="button"
                  key={m.type}
                  onClick={() => setMood(m.type)}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all ${
                    mood === m.type
                      ? 'bg-indigo-600/20 border-indigo-500 scale-105 shadow-md shadow-indigo-500/20'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span className="text-2xl">{m.emoji}</span>
                  <span className="text-[11px] font-bold text-slate-300 mt-1">{m.type}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 5 Reflection Prompts */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                💭 Today's Thoughts & Mindset
              </label>
              <textarea
                rows={2}
                value={thoughts}
                onChange={(e) => setThoughts(e.target.value)}
                placeholder="What was on your mind? How was your energy throughout the day?"
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
                🏆 Today's Key Achievements & Wins
              </label>
              <textarea
                rows={2}
                value={achievements}
                onChange={(e) => setAchievements(e.target.value)}
                placeholder="What did you get done that you're proud of?"
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-rose-400 mb-1">
                ⚠️ Biggest Challenge & Roadblocks
              </label>
              <textarea
                rows={2}
                value={biggestChallenge}
                onChange={(e) => setBiggestChallenge(e.target.value)}
                placeholder="Where did friction occur? What drained your energy or focus?"
                className="w-full bg-slate-950 border border-slate-800 focus:border-rose-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-1">
                💡 What I Learned Today
              </label>
              <textarea
                rows={2}
                value={learnedToday}
                onChange={(e) => setLearnedToday(e.target.value)}
                placeholder="A mental insight, book quote, coding concept, or life wisdom..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
                🎯 Tomorrow's Strategic Improvement Plan
              </label>
              <textarea
                rows={2}
                value={tomorrowPlan}
                onChange={(e) => setTomorrowPlan(e.target.value)}
                placeholder="The top 2-3 essential tasks to execute first thing tomorrow..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 transition active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Save Journal Entry</span>
            </button>
          </div>
        </form>

        {/* Previous Entries Browser */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-400" />
                <span>Past Reflections</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                {sortedEntries.length} saved
              </span>
            </div>

            {/* Search past journals */}
            <div className="relative mt-3">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search reflections..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div className="space-y-2.5 mt-4 max-h-[460px] overflow-y-auto">
              {filteredPastEntries.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  No previous journal entries found.
                </div>
              ) : (
                filteredPastEntries.map((entry) => {
                  const mObj = MOODS.find((m) => m.type === entry.mood) || MOODS[0];
                  const isCur = entry.date === selectedDate;
                  return (
                    <div
                      key={entry.id}
                      onClick={() => setSelectedDate(entry.date)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                        isCur
                          ? 'bg-indigo-600/20 border-indigo-500 text-white'
                          : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 font-bold text-xs">
                          <span>{mObj.emoji}</span>
                          <span>{entry.date}</span>
                        </div>
                        <span className="text-[10px] uppercase font-bold text-slate-400">
                          {entry.mood}
                        </span>
                      </div>
                      {entry.thoughts && (
                        <p className="text-xs text-slate-400 line-clamp-2 mt-1.5 leading-relaxed">
                          {entry.thoughts}
                        </p>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
