import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Plus,
  Compass,
  Bell,
  Sparkles,
  Download,
  Menu,
  X,
} from 'lucide-react';
import { useLifeTracker } from '../context/LifeTrackerContext';
import { getTodayDateString } from '../services/storage';
import { PWAInstallButton } from './Common/PWAInstallButton';
import { NotificationService } from '../services/notifications';

interface NavbarProps {
  onOpenAddActivity: () => void;
  onOpenQuickAdd: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAddActivity, onOpenQuickAdd }) => {
  const {
    data,
    selectedDate,
    setSelectedDate,
    currentTime,
    activeNavTab,
    setActiveNavTab,
    updateProfile,
    addToast,
  } = useLifeTracker();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const todayStr = getTodayDateString();
  const isToday = selectedDate === todayStr;

  const handlePrevDay = () => {
    const cur = new Date(selectedDate + 'T00:00:00');
    cur.setDate(cur.getDate() - 1);
    const y = cur.getFullYear();
    const m = String(cur.getMonth() + 1).padStart(2, '0');
    const d = String(cur.getDate()).padStart(2, '0');
    setSelectedDate(`${y}-${m}-${d}`);
  };

  const handleNextDay = () => {
    const cur = new Date(selectedDate + 'T00:00:00');
    cur.setDate(cur.getDate() + 1);
    const y = cur.getFullYear();
    const m = String(cur.getMonth() + 1).padStart(2, '0');
    const d = String(cur.getDate()).padStart(2, '0');
    setSelectedDate(`${y}-${m}-${d}`);
  };

  const handleToggleTheme = () => {
    const next = data.profile.theme === 'dark' ? 'light' : 'dark';
    updateProfile({ theme: next });
  };

  const handleRequestNotifications = async () => {
    const granted = await NotificationService.requestPermission();
    if (granted) {
      updateProfile({ notificationsEnabled: true });
      addToast('Notifications enabled for reminders!', 'success');
      NotificationService.send('MY LIFE TRACKER', {
        body: 'Reminders are now active. Stay consistent and reach your goals!',
      });
    } else {
      addToast('Notification permission was not granted or is blocked', 'info');
    }
  };

  const timeFormatted = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const dateObj = new Date(selectedDate + 'T00:00:00');
  const dateFormatted = dateObj.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  const navLinks = [
    { id: 'home', label: 'Dashboard' },
    { id: 'daily', label: 'Daily Life' },
    { id: 'habits', label: 'Habits' },
    { id: 'tasks', label: 'Tasks' },
    { id: 'goals', label: 'Goals' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'time', label: 'Time Hub' },
    { id: 'health', label: 'Health' },
    { id: 'finance', label: 'Finance' },
    { id: 'journal', label: 'Journal' },
    { id: 'calendar', label: 'Calendar' },
    { id: 'apk', label: 'Android APK' },
    { id: 'profile', label: 'Settings' },
  ];

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-2">
          {/* Brand Logo & Tagline */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveNavTab('home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Compass className="w-5 h-5 text-indigo-400 group-hover:rotate-45 transition-transform" />
                </div>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-base font-extrabold tracking-tight text-white leading-none flex items-center gap-1.5">
                  MY LIFE TRACKER
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">PRO</span>
                </h1>
                <p className="text-[11px] text-slate-400 font-medium tracking-tight mt-0.5">
                  Track Your Days. Transform Your Life.
                </p>
              </div>
            </button>
          </div>

          {/* Date Selector & Live Clock */}
          <div className="flex items-center gap-1 sm:gap-2 bg-slate-900/90 border border-slate-800 rounded-xl px-2 py-1 shadow-inner text-xs sm:text-sm">
            <button
              onClick={handlePrevDay}
              title="Previous Day"
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5 px-1 font-semibold text-slate-200">
              <Calendar className="w-3.5 h-3.5 text-indigo-400 hidden xs:inline" />
              <span>{dateFormatted}</span>
              {isToday && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded-full font-bold">
                  TODAY
                </span>
              )}
            </div>

            <button
              onClick={handleNextDay}
              title="Next Day"
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {!isToday && (
              <button
                onClick={() => setSelectedDate(todayStr)}
                className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 px-1.5 py-0.5 rounded hover:bg-indigo-950/40 transition"
              >
                Reset
              </button>
            )}

            <div className="hidden md:flex items-center pl-2 border-l border-slate-800 font-mono text-xs font-semibold text-slate-400">
              {timeFormatted}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <PWAInstallButton compact />

            {/* Quick Add Activity button */}
            <button
              onClick={onOpenAddActivity}
              className="flex items-center gap-1.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs sm:text-sm font-semibold px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl shadow-lg shadow-indigo-600/25 active:scale-95 transition"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden xs:inline">+ Add Activity</span>
              <span className="xs:hidden">Add</span>
            </button>

            {/* Notification toggle */}
            <button
              onClick={handleRequestNotifications}
              title="Enable / Check Notifications"
              className={`p-2 rounded-xl border transition ${
                data.profile.notificationsEnabled
                  ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20'
                  : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Bell className="w-4 h-4" />
            </button>

            {/* Theme Toggle */}
            <button
              onClick={handleToggleTheme}
              title="Toggle Light/Dark Theme"
              className="p-2 rounded-xl border border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              {data.profile.theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-300" />
              )}
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl border border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden lg:flex items-center space-x-1 py-1.5 overflow-x-auto no-scrollbar border-t border-slate-900/60">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setActiveNavTab(link.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
                activeNavTab === link.id
                  ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Mobile Dropdown Nav Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-3 border-t border-slate-800/80 animate-in slide-in-from-top-2 duration-200">
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveNavTab(link.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-3 py-2 rounded-xl text-left text-xs font-semibold transition ${
                    activeNavTab === link.id
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
