import React, { useState } from 'react';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Plus,
  Trash2,
  DollarSign,
  PieChart as PieIcon,
  X,
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { FinanceTransaction, TransactionType } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { ConfirmModal } from '../Common/ConfirmModal';
import { getTodayDateString } from '../../services/storage';

const EXPENSE_CATEGORIES = [
  'Groceries & Food',
  'Rent & Housing',
  'Utilities & Bills',
  'Transport & Fuel',
  'Health & Fitness',
  'Education & Books',
  'Entertainment',
  'Shopping',
  'Other',
];

const INCOME_CATEGORIES = [
  'Salary',
  'Freelance & Consulting',
  'Investments',
  'Side Business',
  'Gift / Bonus',
  'Other',
];

const COLORS = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#f43f5e', '#64748b'];

export const FinanceTracker: React.FC = () => {
  const { data, addTransaction, deleteTransaction, selectedDate } = useLifeTracker();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form State
  const [type, setType] = useState<TransactionType>('expense');
  const [category, setCategory] = useState('Groceries & Food');
  const [amount, setAmount] = useState<number | ''>(50);
  const [date, setDate] = useState(selectedDate);
  const [description, setDescription] = useState('');

  // Calculate monthly stats based on selectedDate's month (YYYY-MM)
  const currentMonthPrefix = selectedDate.slice(0, 7);

  const monthTransactions = data.transactions.filter((t) =>
    t.date.startsWith(currentMonthPrefix)
  );

  let monthlyIncome = 0;
  let monthlyExpenses = 0;
  const expenseCategoryMap: Record<string, number> = {};

  monthTransactions.forEach((t) => {
    if (t.type === 'income') {
      monthlyIncome += t.amount;
    } else {
      monthlyExpenses += t.amount;
      expenseCategoryMap[t.category] = (expenseCategoryMap[t.category] || 0) + t.amount;
    }
  });

  const remainingBalance = monthlyIncome - monthlyExpenses;

  const expensePieData = Object.entries(expenseCategoryMap).map(([cat, val]) => ({
    name: cat,
    value: val,
  }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return;

    addTransaction({
      type,
      category,
      amount: Number(amount),
      date,
      description: description.trim(),
    });

    setIsModalOpen(false);
    setDescription('');
    setAmount(50);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Personal Money Tracker</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full">
              {currentMonthPrefix}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Private, offline personal expense and income logging with monthly balance tracking.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Transaction</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">
              Monthly Income
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
              <ArrowDownLeft className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-emerald-300 mt-2">
            ${monthlyIncome.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Total cash inflow</div>
        </div>

        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-400 font-semibold uppercase tracking-wider">
              Monthly Expenses
            </span>
            <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400">
              <ArrowUpRight className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-rose-300 mt-2">
            ${monthlyExpenses.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Total spend recorded</div>
        </div>

        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
              Net Surplus / Remaining
            </span>
            <div className="p-2 rounded-xl bg-indigo-500/15 text-indigo-400">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div
            className={`text-3xl font-extrabold mt-2 ${
              remainingBalance >= 0 ? 'text-indigo-300' : 'text-rose-400'
            }`}
          >
            ${remainingBalance.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {remainingBalance >= 0 ? 'Positive net cashflow' : 'Deficit this month'}
          </div>
        </div>
      </div>

      {/* Chart & Transaction History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Transaction History */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-bold text-white text-base">Transactions ({currentMonthPrefix})</h3>
            <span className="text-xs text-slate-400 font-mono">
              {monthTransactions.length} records
            </span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto">
            {monthTransactions.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-500">
                No transactions recorded for this month.
              </div>
            ) : (
              monthTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-xl ${
                        tx.type === 'income'
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : 'bg-rose-500/15 text-rose-400'
                      }`}
                    >
                      {tx.type === 'income' ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-white text-sm">{tx.category}</div>
                      <div className="text-[11px] text-slate-400">
                        {tx.date} {tx.description ? `• ${tx.description}` : ''}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`font-mono font-bold text-sm ${
                        tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {tx.type === 'income' ? '+' : '-'}${tx.amount.toFixed(2)}
                    </span>
                    <button
                      onClick={() => setDeleteConfirmId(tx.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Expense Category Breakdown Chart */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-rose-400" />
            <span>Expense Distribution</span>
          </h3>

          {expensePieData.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-500">
              No expenses logged this month to generate distribution chart.
            </div>
          ) : (
            <>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expensePieData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      paddingAngle={3}
                    >
                      {expensePieData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '0.75rem',
                        color: '#fff',
                        fontSize: '12px',
                      }}
                      formatter={(val: any) => [`$${Number(val).toFixed(2)}`, 'Amount']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-800 text-xs">
                {expensePieData.map((item, idx) => (
                  <div key={item.name} className="flex items-center justify-between text-slate-300">
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                      />
                      <span className="truncate">{item.name}</span>
                    </div>
                    <span className="font-mono font-bold shrink-0">
                      ${item.value.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Add Transaction Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Record Financial Transaction</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="py-4 space-y-4">
              {/* Type Switcher */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setType('expense');
                    setCategory(EXPENSE_CATEGORIES[0]);
                  }}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    type === 'expense'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setType('income');
                    setCategory(INCOME_CATEGORIES[0]);
                  }}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    type === 'income'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  Income
                </button>
              </div>

              {/* Amount */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Amount ($) *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
                  autoFocus
                  required
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  {(type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES).map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Transaction Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Weekly supermarket run"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md"
                >
                  Save Transaction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Transaction"
        message="Are you sure you want to remove this financial record?"
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteTransaction(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
