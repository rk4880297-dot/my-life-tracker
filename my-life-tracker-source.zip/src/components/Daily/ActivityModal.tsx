import React, { useState, useEffect } from 'react';
import { X, Clock, Tag, Star, AlignLeft, Check } from 'lucide-react';
import { Activity, ActivityCategory, ProductivityRating } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';

interface ActivityModalProps {
  isOpen: boolean;
  activityToEdit?: Activity | null;
  onClose: () => void;
}

const CATEGORIES: ActivityCategory[] = [
  'Personal Development',
  'Business',
  'Study',
  'Exercise',
  'Health',
  'Family',
  'Entertainment',
  'Social Media',
  'Sleep',
  'Other',
];

export const ActivityModal: React.FC<ActivityModalProps> = ({
  isOpen,
  activityToEdit,
  onClose,
}) => {
  const { addActivity, updateActivity, selectedDate } = useLifeTracker();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<ActivityCategory>('Personal Development');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [description, setDescription] = useState('');
  const [productivityRating, setProductivityRating] = useState<ProductivityRating>('productive');
  const [status, setStatus] = useState<'completed' | 'pending'>('completed');
  const [date, setDate] = useState(selectedDate);
  const [error, setError] = useState('');

  useEffect(() => {
    if (activityToEdit) {
      setName(activityToEdit.name);
      setCategory(activityToEdit.category);
      setStartTime(activityToEdit.startTime);
      setEndTime(activityToEdit.endTime);
      setDurationMinutes(activityToEdit.durationMinutes);
      setDescription(activityToEdit.description || '');
      setProductivityRating(activityToEdit.productivityRating);
      setStatus(activityToEdit.status);
      setDate(activityToEdit.date);
    } else {
      // Default to current hour
      const now = new Date();
      const curH = String(now.getHours()).padStart(2, '0');
      const nextH = String((now.getHours() + 1) % 24).padStart(2, '0');
      setName('');
      setCategory('Personal Development');
      setStartTime(`${curH}:00`);
      setEndTime(`${nextH}:00`);
      setDurationMinutes(60);
      setDescription('');
      setProductivityRating('productive');
      setStatus('completed');
      setDate(selectedDate);
    }
    setError('');
  }, [activityToEdit, selectedDate, isOpen]);

  // Automatically recalculate duration whenever startTime or endTime changes
  const handleTimeChange = (start: string, end: string) => {
    setStartTime(start);
    setEndTime(end);
    if (!start || !end) return;

    const [sh, sm] = start.split(':').map(Number);
    const [eh, em] = end.split(':').map(Number);

    let startMins = sh * 60 + sm;
    let endMins = eh * 60 + em;

    if (endMins < startMins) {
      // Crossed midnight
      endMins += 24 * 60;
    }

    const diff = endMins - startMins;
    if (diff > 0) {
      setDurationMinutes(diff);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter an activity name');
      return;
    }

    if (durationMinutes <= 0) {
      setError('Duration must be greater than 0 minutes');
      return;
    }

    if (activityToEdit) {
      updateActivity({
        ...activityToEdit,
        name: name.trim(),
        category,
        startTime,
        endTime,
        durationMinutes,
        description: description.trim(),
        productivityRating,
        status,
        date,
      });
    } else {
      addActivity({
        name: name.trim(),
        category,
        startTime,
        endTime,
        durationMinutes,
        description: description.trim(),
        productivityRating,
        status,
        date,
      });
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/80 bg-slate-950/40">
          <div>
            <h3 className="text-lg font-bold text-white">
              {activityToEdit ? 'Edit Activity' : 'Record New Activity'}
            </h3>
            <p className="text-xs text-slate-400">
              Track your time, identify productivity leaks, and optimize focus.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Activity Name */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Activity Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Deep Work: System Architecture"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition"
              autoFocus
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-2.5 py-2 rounded-xl text-xs font-semibold text-left border transition ${
                    category === cat
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Times and Duration */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Start Time</label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => handleTimeChange(e.target.value, endTime)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">End Time</label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => handleTimeChange(startTime, e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Duration (Min)</label>
              <input
                type="number"
                min="1"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Productivity Rating */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Productivity Rating
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setProductivityRating('productive')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  productivityRating === 'productive'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-emerald-500/10 shadow-lg'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                ⚡ Productive
              </button>
              <button
                type="button"
                onClick={() => setProductivityRating('neutral')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  productivityRating === 'neutral'
                    ? 'bg-slate-700/50 text-slate-200 border-slate-600 shadow-lg'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                ⚖️ Neutral
              </button>
              <button
                type="button"
                onClick={() => setProductivityRating('unproductive')}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  productivityRating === 'unproductive'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-rose-500/10 shadow-lg'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                🚫 Unproductive
              </button>
            </div>
          </div>

          {/* Status and Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'completed' | 'pending')}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Description / Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What did you accomplish or learn?"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none resize-none transition"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 shadow-lg shadow-indigo-600/30 transition"
            >
              {activityToEdit ? 'Save Changes' : 'Record Activity'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
