import React, { useState } from 'react';
import {
  Plus,
  Clock,
  Filter,
  Search,
  Trash2,
  Edit2,
  Calendar,
  Sparkles,
  PieChart as PieChartIcon,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { Activity, ActivityCategory } from '../../types';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { ActivityModal } from './ActivityModal';
import { ConfirmModal } from '../Common/ConfirmModal';

const CATEGORY_COLORS: Record<string, string> = {
  'Personal Development': '#6366f1',
  Business: '#06b6d4',
  Study: '#a855f7',
  Exercise: '#10b981',
  Health: '#3b82f6',
  Family: '#f43f5e',
  Entertainment: '#f59e0b',
  'Social Media': '#ec4899',
  Sleep: '#64748b',
  Other: '#94a3b8',
};

export const DailyTracker: React.FC = () => {
  const { data, selectedDate, setSelectedDate, deleteActivity } = useLifeTracker();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Activities for selected date
  const dayActivities = data.activities
    .filter((a) => a.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Filtered by category & query
  const filteredActivities = dayActivities.filter((a) => {
    const matchesCat = selectedCategory === 'All' || a.category === selectedCategory;
    const matchesSearch =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.description && a.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  // Calculate totals
  let totalMinutes = 0;
  let productiveMinutes = 0;
  let unproductiveMinutes = 0;
  let neutralMinutes = 0;

  const categoryTimeMap: Record<string, number> = {};

  dayActivities.forEach((a) => {
    totalMinutes += a.durationMinutes;
    if (a.productivityRating === 'productive') productiveMinutes += a.durationMinutes;
    else if (a.productivityRating === 'unproductive') unproductiveMinutes += a.durationMinutes;
    else neutralMinutes += a.durationMinutes;

    categoryTimeMap[a.category] = (categoryTimeMap[a.category] || 0) + a.durationMinutes;
  });

  const pieData = Object.entries(categoryTimeMap).map(([cat, mins]) => ({
    name: cat,
    value: mins,
    hours: (mins / 60).toFixed(1),
  }));

  const handleEdit = (act: Activity) => {
    setEditingActivity(act);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setEditingActivity(null);
    setIsModalOpen(true);
  };

  const dateObj = new Date(selectedDate + 'T00:00:00');
  const dateFormatted = dateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header & Summary Stats */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Daily Life Timeline</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2 py-0.5 rounded-full">
              {dateFormatted}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Chronological record of everything you do throughout the day.
          </p>
        </div>

        <button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Record Activity</span>
        </button>
      </div>

      {/* Time Allocation Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Total Logged Time
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {(totalMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-slate-400">hrs</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {dayActivities.length} total recorded sessions
          </div>
        </div>

        <div className="rounded-2xl bg-emerald-950/20 border border-emerald-500/30 p-4">
          <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">
            Productive Focus
          </div>
          <div className="text-2xl font-extrabold text-emerald-300 mt-1">
            {(productiveMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-emerald-400">hrs</span>
          </div>
          <div className="text-[11px] text-emerald-300/80 mt-1">
            {totalMinutes > 0 ? Math.round((productiveMinutes / totalMinutes) * 100) : 0}% of recorded time
          </div>
        </div>

        <div className="rounded-2xl bg-rose-950/20 border border-rose-500/30 p-4">
          <div className="text-xs text-rose-400 font-semibold uppercase tracking-wider">
            Unproductive Time
          </div>
          <div className="text-2xl font-extrabold text-rose-300 mt-1">
            {(unproductiveMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-rose-400">hrs</span>
          </div>
          <div className="text-[11px] text-rose-300/80 mt-1">
            {totalMinutes > 0 ? Math.round((unproductiveMinutes / totalMinutes) * 100) : 0}% wasted / distraction
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
            Neutral / Routine
          </div>
          <div className="text-2xl font-extrabold text-slate-300 mt-1">
            {(neutralMinutes / 60).toFixed(1)} <span className="text-sm font-normal text-slate-400">hrs</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Meals, commute, errands
          </div>
        </div>
      </div>

      {/* Distribution Chart and Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Interactive Timeline */}
        <div className="lg:col-span-2 space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-2xl">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search activities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            {/* Category filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {['All', 'Study', 'Business', 'Exercise', 'Health', 'Entertainment'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Chronological Timeline List */}
          {filteredActivities.length === 0 ? (
            <div className="rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 p-10 text-center space-y-3">
              <Clock className="w-10 h-10 text-slate-600 mx-auto" />
              <div className="text-slate-300 font-semibold text-sm">
                No activities found for this selection.
              </div>
              <p className="text-slate-500 text-xs max-w-sm mx-auto">
                Record your daily work blocks, reading, workouts, or routines to visualize your time distribution.
              </p>
              <button
                onClick={handleAdd}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-600/20"
              >
                + Add First Activity
              </button>
            </div>
          ) : (
            <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
              {filteredActivities.map((act) => {
                const color = CATEGORY_COLORS[act.category] || '#6366f1';
                return (
                  <div
                    key={act.id}
                    className="relative group rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 p-4 transition-all hover:shadow-xl"
                  >
                    {/* Timeline Node Dot */}
                    <div
                      className="absolute -left-[27px] top-5 w-3.5 h-3.5 rounded-full border-2 border-slate-950 shadow"
                      style={{ backgroundColor: color }}
                    />

                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-bold text-white">{act.name}</span>
                          <span
                            className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider"
                            style={{
                              backgroundColor: `${color}20`,
                              color: color,
                              border: `1px solid ${color}40`,
                            }}
                          >
                            {act.category}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                              act.productivityRating === 'productive'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : act.productivityRating === 'unproductive'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : 'bg-slate-800 text-slate-300 border border-slate-700'
                            }`}
                          >
                            {act.productivityRating}
                          </span>
                        </div>

                        {act.description && (
                          <p className="text-xs text-slate-300 leading-relaxed pt-0.5">
                            {act.description}
                          </p>
                        )}
                      </div>

                      {/* Right Time & Actions */}
                      <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-0 border-slate-800">
                        <div className="text-right">
                          <div className="text-xs font-mono font-bold text-slate-200">
                            {act.startTime} — {act.endTime}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {act.durationMinutes} mins ({(act.durationMinutes / 60).toFixed(1)}h)
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleEdit(act)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(act.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Daily Time Distribution Chart & Insights */}
        <div className="lg:col-span-1 space-y-4">
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <PieChartIcon className="w-4 h-4 text-indigo-400" />
                <span>Time Distribution</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                {(totalMinutes / 60).toFixed(1)}h Total
              </span>
            </div>

            {pieData.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-500">
                Log activities to generate today's distribution breakdown.
              </div>
            ) : (
              <>
                <div className="h-52 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={75}
                        paddingAngle={3}
                      >
                        {pieData.map((entry) => (
                          <Cell
                            key={`cell-${entry.name}`}
                            fill={CATEGORY_COLORS[entry.name] || '#6366f1'}
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0f172a',
                          borderColor: '#334155',
                          borderRadius: '0.75rem',
                          color: '#fff',
                          fontSize: '12px',
                        }}
                        formatter={(val: any) => [`${val} mins (${(Number(val) / 60).toFixed(1)}h)`, 'Time']}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs">
                  {pieData.map((item) => {
                    const color = CATEGORY_COLORS[item.name] || '#6366f1';
                    const pct = totalMinutes > 0 ? Math.round((item.value / totalMinutes) * 100) : 0;
                    return (
                      <div key={item.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-2 truncate">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                          <span className="text-slate-300 truncate">{item.name}</span>
                        </div>
                        <div className="flex items-center gap-2 font-mono text-slate-400 shrink-0">
                          <span>{item.hours}h</span>
                          <span className="text-slate-500 font-sans">({pct}%)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Activity Add/Edit Modal */}
      <ActivityModal
        isOpen={isModalOpen}
        activityToEdit={editingActivity}
        onClose={() => setIsModalOpen(false)}
      />

      {/* Deletion Confirm */}
      <ConfirmModal
        isOpen={!!deleteConfirmId}
        title="Delete Activity Record"
        message="Are you sure you want to delete this recorded activity? This action cannot be undone."
        confirmLabel="Delete"
        isDestructive
        onConfirm={() => {
          if (deleteConfirmId) {
            deleteActivity(deleteConfirmId);
            setDeleteConfirmId(null);
          }
        }}
        onCancel={() => setDeleteConfirmId(null)}
      />
    </div>
  );
};
