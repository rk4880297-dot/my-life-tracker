import React, { useState, useRef } from 'react';
import {
  User,
  Settings,
  Download,
  Upload,
  FileSpreadsheet,
  Trash2,
  Bell,
  Sun,
  Moon,
  Save,
  CheckCircle2,
  Clock,
  Sparkles,
  AlertTriangle,
  Smartphone,
  Send,
  Info,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { ConfirmModal } from '../Common/ConfirmModal';
import { NotificationService } from '../../services/notifications';
import { DEFAULT_TASK_NOTIFICATIONS } from '../../services/storage';
import { TaskNotificationSettings } from '../../types';

const AVATAR_OPTIONS = ['🚀', '⚡', '🦁', '🦉', '👑', '🎯', '🌟', '🐺', '🦊', '🔥', '💎', '🧘'];

export const ProfileSettings: React.FC = () => {
  const {
    data,
    updateProfile,
    resetAllData,
    exportDataJSON,
    exportCSVReport,
    importDataFromJSON,
    addToast,
    setActiveNavTab,
    updateTaskNotificationSettings,
    sendTestNotification,
  } = useLifeTracker();

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Profile local state
  const [name, setName] = useState(data.profile.name);
  const [avatar, setAvatar] = useState(data.profile.avatar);
  const [age, setAge] = useState<number | ''>(data.profile.age || '');
  const [mainGoal, setMainGoal] = useState(data.profile.mainGoal);
  const [productivityTarget, setProductivityTarget] = useState(data.profile.productivityTargetPercent);
  const [waterTarget, setWaterTarget] = useState(data.profile.waterTargetMl);
  const [sleepTarget, setSleepTarget] = useState(data.profile.sleepTargetHours);
  const [studyTarget, setStudyTarget] = useState(data.profile.studyTargetMinutes || 90);
  const [exerciseTarget, setExerciseTarget] = useState(data.profile.exerciseTargetMinutes || 45);
  const [theme, setTheme] = useState<'dark' | 'light'>(data.profile.theme);

  // Reminders & Task Notifications
  const [reminders, setReminders] = useState(data.profile.reminders);
  const [notificationsEnabled, setNotificationsEnabled] = useState(data.profile.notificationsEnabled);
  const [taskNotifications, setTaskNotifications] = useState<TaskNotificationSettings>(
    data.profile.taskNotifications || DEFAULT_TASK_NOTIFICATIONS
  );
  const [isTestingNotification, setIsTestingNotification] = useState(false);

  // Confirmation modals
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: name.trim() || 'Champion',
      avatar,
      age: age === '' ? undefined : Number(age),
      mainGoal: mainGoal.trim(),
      productivityTargetPercent: Number(productivityTarget),
      waterTargetMl: Number(waterTarget),
      sleepTargetHours: Number(sleepTarget),
      studyTargetMinutes: Number(studyTarget),
      exerciseTargetMinutes: Number(exerciseTarget),
      theme,
      reminders,
      notificationsEnabled,
      taskNotifications,
    });
    updateTaskNotificationSettings(taskNotifications);
  };

  const handleToggleTaskSetting = (key: keyof TaskNotificationSettings) => {
    setTaskNotifications((prev) => {
      const updated = {
        ...prev,
        [key]: !prev[key],
      };
      updateTaskNotificationSettings(updated);
      return updated;
    });
  };

  const handleDailySummaryTimeChange = (time: string) => {
    setTaskNotifications((prev) => {
      const updated = {
        ...prev,
        dailySummaryTime: time,
      };
      updateTaskNotificationSettings(updated);
      return updated;
    });
  };

  const handleTestNotificationClick = async () => {
    setIsTestingNotification(true);
    try {
      await sendTestNotification();
    } finally {
      setTimeout(() => setIsTestingNotification(false), 800);
    }
  };

  const handleThemeChange = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    updateProfile({ theme: newTheme });
  };

  const handleToggleNotification = async () => {
    if (!notificationsEnabled) {
      const granted = await NotificationService.requestPermission();
      if (granted) {
        setNotificationsEnabled(true);
        updateProfile({ notificationsEnabled: true });
        addToast('Notification alerts enabled!', 'success');
      } else {
        addToast('Permission was blocked or denied in browser settings', 'info');
      }
    } else {
      setNotificationsEnabled(false);
      updateProfile({ notificationsEnabled: false });
      addToast('Notifications turned off', 'info');
    }
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const success = await importDataFromJSON(parsed);
        if (success && fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } catch (err) {
        addToast('Failed to parse backup JSON file', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <span>Profile, Targets & Data Backup</span>
          <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full font-mono">
            Settings
          </span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Customize your personal identity, benchmarks, reminder schedules, and export complete offline backups.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Form: Profile & Targets */}
        <form onSubmit={handleSaveProfile} className="lg:col-span-2 space-y-6">
          {/* Identity Card */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-5">
            <h3 className="font-bold text-white text-base flex items-center gap-2 pb-3 border-b border-slate-800">
              <User className="w-5 h-5 text-indigo-400" />
              <span>Personal Identity</span>
            </h3>

            {/* Avatar Selector */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Choose Profile Avatar
              </label>
              <div className="flex items-center gap-2 overflow-x-auto p-1.5 bg-slate-950 rounded-2xl border border-slate-800 no-scrollbar">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    type="button"
                    key={av}
                    onClick={() => setAvatar(av)}
                    className={`w-10 h-10 text-xl rounded-xl flex items-center justify-center shrink-0 transition ${
                      avatar === av
                        ? 'bg-indigo-600 scale-110 shadow-lg shadow-indigo-600/30'
                        : 'hover:bg-slate-800'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Age (Optional)</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 26"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Main Life Goal / North Star</label>
              <input
                type="text"
                value={mainGoal}
                onChange={(e) => setMainGoal(e.target.value)}
                placeholder="e.g. Master engineering leadership and build optimal habits"
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Daily Productivity Targets */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-5">
            <h3 className="font-bold text-white text-base flex items-center gap-2 pb-3 border-b border-slate-800">
              <Settings className="w-5 h-5 text-emerald-400" />
              <span>Daily Target Benchmarks</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Productivity Target (%)
                </label>
                <input
                  type="number"
                  min="30"
                  max="100"
                  value={productivityTarget}
                  onChange={(e) => setProductivityTarget(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Water Goal (ml)
                </label>
                <input
                  type="number"
                  step="250"
                  min="1000"
                  max="6000"
                  value={waterTarget}
                  onChange={(e) => setWaterTarget(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Sleep Target (hours)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="4"
                  max="12"
                  value={sleepTarget}
                  onChange={(e) => setSleepTarget(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Daily Study Goal (min)
                </label>
                <input
                  type="number"
                  step="15"
                  min="0"
                  value={studyTarget}
                  onChange={(e) => setStudyTarget(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Daily Exercise Goal (min)
                </label>
                <input
                  type="number"
                  step="10"
                  min="0"
                  value={exerciseTarget}
                  onChange={(e) => setExerciseTarget(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Theme & Basic Modules */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-5">
            <h3 className="font-bold text-white text-base flex items-center gap-2 pb-3 border-b border-slate-800">
              <Sun className="w-5 h-5 text-amber-400" />
              <span>Theme & General Reminders</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Theme choice */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">Preferred Theme</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleThemeChange('dark')}
                    className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                      theme === 'dark'
                        ? 'bg-slate-950 border-indigo-500 text-white shadow-md'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Moon className="w-4 h-4 text-indigo-400" />
                    <span>Dark (Default)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleThemeChange('light')}
                    className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                      theme === 'light'
                        ? 'bg-slate-100 border-indigo-500 text-slate-900 shadow-md'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Sun className="w-4 h-4 text-amber-500" />
                    <span>Light Mode</span>
                  </button>
                </div>
              </div>

              {/* General Notification Toggle */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2">System Notification Permission</label>
                <button
                  type="button"
                  onClick={handleToggleNotification}
                  className={`w-full p-3 rounded-2xl border text-xs font-bold flex items-center justify-between transition ${
                    notificationsEnabled
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4" />
                    <span>{notificationsEnabled ? 'Permission Granted' : 'Request Permission'}</span>
                  </div>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                    {notificationsEnabled ? 'ACTIVE' : 'OFF'}
                  </span>
                </button>
              </div>
            </div>

            {/* Individual Reminder Schedule Toggles */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-slate-400 mb-2">Active Tracker Alerts</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'habits', label: 'Daily Habits' },
                  { id: 'tasks', label: 'Due Tasks' },
                  { id: 'water', label: 'Water Reminders' },
                  { id: 'exercise', label: 'Workout Time' },
                  { id: 'study', label: 'Study Sessions' },
                  { id: 'sleep', label: 'Sleep Schedule' },
                ].map((item) => {
                  const key = item.id as keyof typeof reminders;
                  const isChecked = reminders[key];
                  return (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setReminders((r) => ({ ...r, [key]: !isChecked }))}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition ${
                        isChecked
                          ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300'
                          : 'bg-slate-950/60 border-slate-800 text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      <span>{item.label}</span>
                      <CheckCircle2 className={`w-4 h-4 ${isChecked ? 'text-indigo-400' : 'opacity-20'}`} />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* SMART TASK REMINDER & NOTIFICATION SYSTEM */}
          <div className="rounded-3xl bg-gradient-to-br from-indigo-950/30 via-slate-900/95 to-slate-900/90 border border-indigo-500/40 p-6 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  <Bell className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                    <span>Smart Task Reminders & Notifications</span>
                    <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-mono px-2 py-0.5 rounded-full font-bold">
                      Native & Web
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Android Native Local Notifications & Web Browser Alert Engine
                  </p>
                </div>
              </div>

              {/* Master Notification Toggle */}
              <button
                type="button"
                onClick={() => handleToggleTaskSetting('enabled')}
                className={`px-4 py-2 rounded-2xl border text-xs font-bold flex items-center gap-2 transition shadow-sm ${
                  taskNotifications.enabled
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-emerald-500/10'
                    : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${taskNotifications.enabled ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                <span>{taskNotifications.enabled ? 'Reminders Enabled' : 'Reminders Disabled'}</span>
              </button>
            </div>

            {/* Granular Notification Controls */}
            <div className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>Automated Task Alert Triggers</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* 15-Minute Reminder */}
                <div
                  onClick={() => handleToggleTaskSetting('reminder15Min')}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between gap-3 ${
                    taskNotifications.reminder15Min && taskNotifications.enabled
                      ? 'bg-indigo-950/40 border-indigo-500/40 shadow-lg shadow-indigo-950/40'
                      : 'bg-slate-950/60 border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-cyan-400" />
                      <span>15-Minute Reminder</span>
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        taskNotifications.reminder15Min && taskNotifications.enabled
                          ? 'bg-indigo-500/30 text-indigo-300'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {taskNotifications.reminder15Min && taskNotifications.enabled ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Receive a priority heads-up exactly 15 minutes before any task deadline.
                  </p>
                </div>

                {/* Deadline Reminder */}
                <div
                  onClick={() => handleToggleTaskSetting('deadlineReminder')}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between gap-3 ${
                    taskNotifications.deadlineReminder && taskNotifications.enabled
                      ? 'bg-indigo-950/40 border-indigo-500/40 shadow-lg shadow-indigo-950/40'
                      : 'bg-slate-950/60 border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Deadline Alert</span>
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        taskNotifications.deadlineReminder && taskNotifications.enabled
                          ? 'bg-amber-500/30 text-amber-300'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {taskNotifications.deadlineReminder && taskNotifications.enabled ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Trigger an immediate notification at the exact moment the task is due.
                  </p>
                </div>

                {/* Overdue Alert */}
                <div
                  onClick={() => handleToggleTaskSetting('overdueReminder')}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between gap-3 ${
                    taskNotifications.overdueReminder && taskNotifications.enabled
                      ? 'bg-rose-950/30 border-rose-500/40 shadow-lg shadow-rose-950/30'
                      : 'bg-slate-950/60 border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                      <span>Overdue Reminder</span>
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        taskNotifications.overdueReminder && taskNotifications.enabled
                          ? 'bg-rose-500/30 text-rose-300'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {taskNotifications.overdueReminder && taskNotifications.enabled ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Alert if a task is not marked completed past its deadline with overdue duration.
                  </p>
                </div>
              </div>
            </div>

            {/* Daily Progress Report Schedule */}
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <span>Daily Evening Progress Report (Default: 9:00 PM)</span>
                    <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded border border-purple-500/30">
                      Summary
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Sends completed, pending, and overdue task tallies to ensure no tasks are forgotten.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleTaskSetting('dailySummary')}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition self-start sm:self-auto ${
                    taskNotifications.dailySummary && taskNotifications.enabled
                      ? 'bg-purple-600/30 border-purple-500/50 text-purple-200'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {taskNotifications.dailySummary && taskNotifications.enabled ? 'Summary Active' : 'Disabled'}
                </button>
              </div>

              {taskNotifications.dailySummary && (
                <div className="pt-2 border-t border-slate-800/70 flex flex-wrap items-center gap-3">
                  <label className="text-xs text-slate-300 font-semibold flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-purple-400" />
                    <span>Custom Notification Time:</span>
                  </label>
                  <input
                    type="time"
                    value={taskNotifications.dailySummaryTime}
                    onChange={(e) => handleDailySummaryTimeChange(e.target.value)}
                    className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1 text-xs text-white font-mono focus:outline-none focus:border-purple-400"
                  />
                  <div className="flex items-center gap-1.5">
                    {['20:00', '21:00', '21:30', '22:00'].map((preset) => (
                      <button
                        type="button"
                        key={preset}
                        onClick={() => handleDailySummaryTimeChange(preset)}
                        className={`text-[10px] font-mono px-2 py-1 rounded-lg border transition ${
                          taskNotifications.dailySummaryTime === preset
                            ? 'bg-purple-500 text-white border-purple-400 font-bold'
                            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {preset === '21:00' ? '9:00 PM (Default)' : preset}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Test Notification Trigger & Platform Note */}
            <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-indigo-400" />
                  <span>Test Notification Delivery</span>
                </div>
                <p className="text-[11px] text-slate-400 max-w-md">
                  Sends an immediate test alert to verify Android Local Notification channels or active browser notification permissions.
                </p>
              </div>

              <button
                type="button"
                onClick={handleTestNotificationClick}
                disabled={isTestingNotification}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition active:scale-95 disabled:opacity-60"
              >
                <Send className={`w-3.5 h-3.5 ${isTestingNotification ? 'animate-spin' : ''}`} />
                <span>{isTestingNotification ? 'Dispatching...' : 'Send Test Notification'}</span>
              </button>
            </div>

            {/* Platform Background Execution Truth & Guidelines */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 flex items-start gap-2.5 text-[11px] text-slate-400 leading-relaxed">
              <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200">Platform Delivery Guarantee:</strong> In the installed{' '}
                <span className="text-indigo-300 font-semibold">Android APK</span>, notifications leverage Capacitor Local Notifications with native Android exact alarm permissions (<code className="font-mono text-[10px] text-slate-300">SCHEDULE_EXACT_ALARM</code>), firing reliably in background or when the app is closed. On <span className="text-slate-300 font-semibold">Web Browsers</span>, notifications trigger while the browser is running or tab is active, backed by our real-time 15s in-app alert monitor.
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 transition active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile & Targets</span>
            </button>
          </div>
        </form>

        {/* Right Column: Data Storage, JSON Backup & CSV Export */}
        <div className="lg:col-span-1 space-y-6">
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800 text-white font-bold text-base">
              <Download className="w-5 h-5 text-indigo-400" />
              <span>Data Storage & Backup</span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              All data is stored directly in your browser's persistent IndexedDB storage engine. You have 100% data ownership.
            </p>

            {/* Export JSON */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={exportDataJSON}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs transition shadow"
              >
                <Download className="w-4 h-4 text-indigo-400" />
                <span>Export Full Backup (JSON)</span>
              </button>

              {/* Import JSON */}
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleFileImport}
                className="hidden"
                id="backup-file-import"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-slate-200 font-bold text-xs transition"
              >
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Import Backup (JSON)</span>
              </button>
            </div>

            {/* CSV Reports */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <span className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Export Reports (CSV)
              </span>

              <div className="grid grid-cols-1 gap-1.5">
                <button
                  type="button"
                  onClick={() => exportCSVReport('activities')}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 transition"
                >
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                    <span>Activities History (.csv)</span>
                  </span>
                  <Download className="w-3.5 h-3.5 text-slate-400" />
                </button>

                <button
                  type="button"
                  onClick={() => exportCSVReport('tasks')}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 transition"
                >
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-indigo-400" />
                    <span>Tasks Registry (.csv)</span>
                  </span>
                  <Download className="w-3.5 h-3.5 text-slate-400" />
                </button>

                <button
                  type="button"
                  onClick={() => exportCSVReport('finances')}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 transition"
                >
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <span>Financial Transactions (.csv)</span>
                  </span>
                  <Download className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>
            </div>

            {/* Clear All Data */}
            <div className="pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsResetConfirmOpen(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 font-bold text-xs transition"
              >
                <Trash2 className="w-4 h-4 text-rose-400" />
                <span>Reset All Data to Defaults</span>
              </button>
            </div>
          </div>

          {/* Android APK Shortcut card */}
          <div className="rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/40 p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-white text-sm">
                <Smartphone className="w-5 h-5 text-indigo-400" />
                <span>Android APK Cloud Build</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono font-bold px-2 py-0.5 rounded border border-emerald-500/40">
                Ready
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Build your APK using GitHub Actions cloud runners directly from your smartphone. No computer required.
            </p>
            <div className="space-y-2 pt-1">
              <a
                href="/my-life-tracker-source.zip"
                download="my-life-tracker-source.zip"
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-950/40 transition active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Download Source ZIP (3.0 MB)</span>
              </a>
              <button
                type="button"
                onClick={() => setActiveNavTab('apk')}
                className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-300 font-bold text-xs border border-slate-700 transition"
              >
                <span>View Mobile Cloud Build Hub →</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Confirmation */}
      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="Reset All Application Data"
        message="This will reset all your activities, habits, tasks, workouts, sleep, and journals back to default values. Make sure you have exported a JSON backup first!"
        confirmLabel="Reset Everything"
        isDestructive
        onConfirm={async () => {
          await resetAllData();
          setIsResetConfirmOpen(false);
        }}
        onCancel={() => setIsResetConfirmOpen(false)}
      />
    </div>
  );
};
