import React from 'react';
import { Home, Clock, CheckSquare, BarChart3, User, Sparkles } from 'lucide-react';
import { useLifeTracker } from '../context/LifeTrackerContext';

export const BottomNav: React.FC = () => {
  const { activeNavTab, setActiveNavTab, breakdown } = useLifeTracker();

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'daily', label: 'Daily', icon: Clock },
    {
      id: 'habits',
      label: 'Habits',
      icon: CheckSquare,
      badge: breakdown.habitsTotal - breakdown.habitsCompleted > 0 ? `${breakdown.habitsTotal - breakdown.habitsCompleted}` : undefined,
    },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-lg border-t border-slate-800/80 lg:hidden pb-safe">
      <div className="grid grid-cols-5 h-16 max-w-md mx-auto px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeNavTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveNavTab(item.id)}
              className={`relative flex flex-col items-center justify-center gap-1 transition ${
                isActive ? 'text-indigo-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2.5 bg-indigo-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full min-w-4 text-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] font-semibold tracking-tight ${isActive ? 'font-bold' : ''}`}>
                {item.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-5 h-0.5 rounded-full bg-indigo-500 animate-in fade-in" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
