import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  Target,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { useLifeTracker } from '../../context/LifeTrackerContext';
import { calculateDayProductivity } from '../../services/analytics';
import { getTodayDateString } from '../../services/storage';

export const CalendarView: React.FC = () => {
  const { data, selectedDate, setSelectedDate, setActiveNavTab } = useLifeTracker();

  const [calMode, setCalMode] = useState<'month' | 'day'>('month');

  // Month navigation
  const selDateObj = new Date(selectedDate + 'T00:00:00');
  const [navYear, setNavYear] = useState<number>(selDateObj.getFullYear());
  const [navMonth, setNavMonth] = useState<number>(selDateObj.getMonth()); // 0-11

  const firstDay = new Date(navYear, navMonth, 1);
  const totalDays = new Date(navYear, navMonth + 1, 0).getDate();
  const startDayOfWeek = (firstDay.getDay() + 6) % 7; // Monday = 0
  const monthName = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const handlePrevMonth = () => {
    if (navMonth === 0) {
      setNavMonth(11);
      setNavYear((y) => y - 1);
    } else {
      setNavMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (navMonth === 11) {
      setNavMonth(0);
      setNavYear((y) => y + 1);
    } else {
      setNavMonth((m) => m + 1);
    }
  };

  // Inspect records for currently selected date
  const selectedDayBreakdown = calculateDayProductivity(selectedDate, data);
  const dayActivities = data.activities.filter((a) => a.date === selectedDate);
  const dayTasks = data.tasks.filter((t) => t.dueDate === selectedDate);
  const dayJournal = data.journalEntries.find((j) => j.date === selectedDate);

  const activeHabits = data.habits.filter((h) => !h.archived);
  const completedHabitIds = new Set(
    data.habitLogs
      .filter((l) => l.date === selectedDate && l.completed)
      .map((l) => l.habitId)
  );

  const missedHabits = activeHabits.filter((h) => !completedHabitIds.has(h.id));
  const completedHabits = activeHabits.filter((h) => completedHabitIds.has(h.id));

  // Upcoming goals near this date
  const nearGoals = data.goals.filter((g) => g.targetDate >= selectedDate).slice(0, 3);

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Life Calendar System</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2.5 py-0.5 rounded-full font-mono">
              {monthName}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Tap any date to audit past activities, tasks, missed habits, and goals.
          </p>
        </div>

        {/* Month switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              onClick={handlePrevMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-white px-3 font-mono">
              {monthName}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Interactive Calendar Grid */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-4">
          <div className="grid grid-cols-7 gap-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
              <div
                key={day}
                className="text-center text-xs font-bold text-slate-400 py-1.5 uppercase tracking-wider"
              >
                {day}
              </div>
            ))}

            {/* Empty offset padding */}
            {Array.from({ length: startDayOfWeek }).map((_, i) => (
              <div key={`cal-pad-${i}`} className="h-16 rounded-2xl bg-transparent" />
            ))}

            {/* Days in Month */}
            {Array.from({ length: totalDays }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${navYear}-${String(navMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const isSelected = selectedDate === dateStr;
              const isToday = dateStr === getTodayDateString();

              const dayActCount = data.activities.filter((a) => a.date === dateStr).length;
              const dayTaskCount = data.tasks.filter((t) => t.dueDate === dateStr).length;
              const dayHabitDone = data.habitLogs.filter((l) => l.date === dateStr && l.completed).length;

              return (
                <div
                  key={dayNum}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`h-16 sm:h-20 rounded-2xl border p-2 flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.03] ${
                    isSelected
                      ? 'bg-indigo-600/25 border-indigo-500 shadow-lg shadow-indigo-500/20 ring-2 ring-indigo-400'
                      : isToday
                      ? 'bg-slate-950 border-indigo-500/50'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-mono font-bold ${
                        isSelected ? 'text-indigo-300' : isToday ? 'text-cyan-400' : 'text-slate-200'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {isToday && (
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    )}
                  </div>

                  {/* Micro indicators */}
                  <div className="flex items-center gap-1 flex-wrap">
                    {dayActCount > 0 && (
                      <span className="w-2 h-2 rounded-full bg-indigo-500" title={`${dayActCount} activities`} />
                    )}
                    {dayTaskCount > 0 && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400" title={`${dayTaskCount} tasks`} />
                    )}
                    {dayHabitDone > 0 && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400" title={`${dayHabitDone} habits completed`} />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Date Audit Details Panel */}
        <div className="lg:col-span-1 rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-5">
          <div className="pb-3 border-b border-slate-800">
            <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
              Selected Date Audit
            </span>
            <h3 className="text-xl font-extrabold text-white mt-0.5">
              {selectedDate}
            </h3>
            <div className="text-xs text-indigo-400 font-bold mt-1">
              Overall Productivity: {selectedDayBreakdown.score}%
            </div>
          </div>

          {/* Activities on this day */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-indigo-400" />
                Activities ({dayActivities.length})
              </span>
              <button
                onClick={() => setActiveNavTab('daily')}
                className="text-indigo-400 hover:text-indigo-300 text-[11px]"
              >
                Go to Daily →
              </button>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {dayActivities.length === 0 ? (
                <div className="text-slate-500 text-xs py-2">No activities recorded.</div>
              ) : (
                dayActivities.map((act) => (
                  <div
                    key={act.id}
                    className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex items-center justify-between"
                  >
                    <span className="font-semibold text-slate-200 truncate">{act.name}</span>
                    <span className="font-mono text-slate-400 text-[11px] shrink-0">
                      {act.startTime} ({act.durationMinutes}m)
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Tasks due on this day */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Due Tasks ({dayTasks.length})
              </span>
            </div>

            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              {dayTasks.length === 0 ? (
                <div className="text-slate-500 text-xs py-2">No tasks due on this date.</div>
              ) : (
                dayTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex items-center justify-between"
                  >
                    <span className={`font-semibold ${t.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                      {t.title}
                    </span>
                    <span className="text-[10px] font-bold uppercase text-indigo-400">
                      {t.completed ? 'Done' : 'Pending'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Missed / Completed Habits */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Habit Status</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-300">
                <div className="font-bold text-sm">{completedHabits.length}</div>
                <div className="text-[10px] text-emerald-400/80">Completed</div>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-950/20 border border-rose-500/30 text-rose-300">
                <div className="font-bold text-sm">{missedHabits.length}</div>
                <div className="text-[10px] text-rose-400/80">Missed / Pending</div>
              </div>
            </div>
          </div>

          {/* Important Goals */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-purple-400" />
              <span>Upcoming Milestones</span>
            </div>
            <div className="space-y-1.5">
              {nearGoals.map((g) => (
                <div
                  key={g.id}
                  className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex items-center justify-between"
                >
                  <span className="font-semibold text-slate-200 truncate">{g.name}</span>
                  <span className="font-mono text-purple-400 text-[11px] shrink-0">
                    {g.targetDate}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
