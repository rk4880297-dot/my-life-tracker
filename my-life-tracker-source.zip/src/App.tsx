/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LifeTrackerProvider, useLifeTracker } from './context/LifeTrackerContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { ToastContainer } from './components/Common/Toast';
import { OfflineIndicator } from './components/Common/PWAInstallButton';
import { HomeDashboard } from './components/Dashboard/HomeDashboard';
import { DailyTracker } from './components/Daily/DailyTracker';
import { ActivityModal } from './components/Daily/ActivityModal';
import { HabitTracker } from './components/Habits/HabitTracker';
import { HabitModal } from './components/Habits/HabitModal';
import { TaskManager } from './components/Tasks/TaskManager';
import { TaskModal } from './components/Tasks/TaskModal';
import { GoalTracker } from './components/Goals/GoalTracker';
import { SmartAnalytics } from './components/Analytics/SmartAnalytics';
import { TimeManagement } from './components/Analytics/TimeManagement';
import { HealthTracker } from './components/Health/HealthTracker';
import { WaterModal, WorkoutModal, SleepModal } from './components/Health/HealthModals';
import { FinanceTracker } from './components/Finance/FinanceTracker';
import { JournalTracker } from './components/Journal/JournalTracker';
import { CalendarView } from './components/Calendar/CalendarView';
import { AndroidAppHub } from './components/Android/AndroidAppHub';
import { ProfileSettings } from './components/Profile/ProfileSettings';

const MainAppContent: React.FC = () => {
  const { activeNavTab, isLoading } = useLifeTracker();

  // Global modals triggered from Navbar or Dashboard quick actions
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [isHabitModalOpen, setIsHabitModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isWaterModalOpen, setIsWaterModalOpen] = useState(false);
  const [isWorkoutModalOpen, setIsWorkoutModalOpen] = useState(false);
  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300 space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 animate-spin flex items-center justify-center">
          <div className="w-4 h-4 bg-indigo-500 rounded-full" />
        </div>
        <div className="text-sm font-semibold tracking-wider uppercase text-slate-400">
          Loading MY LIFE TRACKER...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col transition-colors">
      {/* Toast Alert Notifications */}
      <ToastContainer />

      {/* Offline PWA Status Badge */}
      <OfflineIndicator />

      {/* Sticky Responsive Header */}
      <Navbar
        onOpenAddActivity={() => setIsActivityModalOpen(true)}
        onOpenQuickAdd={() => setIsTaskModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-5 pb-24 lg:pb-12">
        {activeNavTab === 'home' && (
          <HomeDashboard
            onOpenAddActivity={() => setIsActivityModalOpen(true)}
            onOpenAddHabit={() => setIsHabitModalOpen(true)}
            onOpenAddTask={() => setIsTaskModalOpen(true)}
            onQuickAddWater={() => setIsWaterModalOpen(true)}
            onQuickAddWorkout={() => setIsWorkoutModalOpen(true)}
            onQuickAddSleep={() => setIsSleepModalOpen(true)}
          />
        )}
        {activeNavTab === 'daily' && <DailyTracker />}
        {activeNavTab === 'habits' && <HabitTracker />}
        {activeNavTab === 'tasks' && <TaskManager />}
        {activeNavTab === 'goals' && <GoalTracker />}
        {activeNavTab === 'analytics' && <SmartAnalytics />}
        {activeNavTab === 'time' && <TimeManagement />}
        {activeNavTab === 'health' && <HealthTracker />}
        {activeNavTab === 'finance' && <FinanceTracker />}
        {activeNavTab === 'journal' && <JournalTracker />}
        {activeNavTab === 'calendar' && <CalendarView />}
        {activeNavTab === 'apk' && <AndroidAppHub />}
        {activeNavTab === 'profile' && <ProfileSettings />}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav />

      {/* Global Modals */}
      <ActivityModal
        isOpen={isActivityModalOpen}
        onClose={() => setIsActivityModalOpen(false)}
      />
      <HabitModal
        isOpen={isHabitModalOpen}
        onClose={() => setIsHabitModalOpen(false)}
      />
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
      />
      <WaterModal
        isOpen={isWaterModalOpen}
        onClose={() => setIsWaterModalOpen(false)}
      />
      <WorkoutModal
        isOpen={isWorkoutModalOpen}
        onClose={() => setIsWorkoutModalOpen(false)}
      />
      <SleepModal
        isOpen={isSleepModalOpen}
        onClose={() => setIsSleepModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <LifeTrackerProvider>
      <MainAppContent />
    </LifeTrackerProvider>
  );
}
