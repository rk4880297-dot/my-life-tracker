#!/usr/bin/env python3
import os
import zipfile

def create_project_zip():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    output_public = os.path.join(base_dir, 'public', 'my-life-tracker-source.zip')
    output_root = os.path.join(base_dir, 'my-life-tracker-source.zip')
    
    os.makedirs(os.path.join(base_dir, 'public'), exist_ok=True)

    # Exclusions
    exclude_dirs = {
        'node_modules',
        'dist',
        '.git',
        '.vite',
        'dev-dist',
        '.aistudio',
        'build',
        '.gradle',
        '.idea',
        '__pycache__'
    }
    exclude_files = {
        'my-life-tracker-source.zip',
        '.DS_Store'
    }

    print(f"Creating project zip from {base_dir}...")
    
    for target_zip_path in [output_public, output_root]:
        with zipfile.ZipFile(target_zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(base_dir):
                # Filter directories in-place (exclude .git but keep .github)
                dirs[:] = [d for d in dirs if d not in exclude_dirs and d != '.git' and not d.startswith('.git/')]
                
                for file in sorted(files):
                    if file in exclude_files:
                        continue
                    if file.endswith('.pyc') or file.endswith('.log'):
                        continue
                    
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, base_dir)
                    
                    # Create ZipInfo to preserve permissions (especially gradlew executable bit)
                    zip_info = zipfile.ZipInfo.from_file(full_path, arcname=rel_path)
                    if rel_path in ['android/gradlew', 'gradlew']:
                        # 0o755 permission: rwxr-xr-x
                        zip_info.external_attr = 0o100755 << 16
                    else:
                        zip_info.external_attr = 0o100644 << 16
                        
                    with open(full_path, 'rb') as f:
                        zipf.writestr(zip_info, f.read())
        
        size_mb = os.path.getsize(target_zip_path) / (1024 * 1024)
        print(f"Created {target_zip_path} ({size_mb:.2f} MB)")

if __name__ == '__main__':
    create_project_zip()
